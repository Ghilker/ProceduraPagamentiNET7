using ProcedureNet7.Verifica;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace ProcedureNet7
{
    internal sealed partial class VerificaRaccoltaDati
    {
        private const string IscrizioneCorePopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT
        CAST(t.NumDomanda AS INT) AS NumDomanda,
        t.CodFiscale,
        COALESCE(t.TipoBando,'') AS TipoBando
    FROM {TEMP_TABLE} t
),
ISCR AS
(
    SELECT
        D.NumDomanda,
        D.CodFiscale,
        D.TipoBando,
        i.Cod_corso_laurea,
        TRY_CONVERT(INT, i.Anno_corso) AS Anno_corso,
        i.Cod_facolta,
        i.Cod_sede_studi,
        CONVERT(NVARCHAR(50), i.Cod_tipologia_studi) AS Cod_tipologia_studi,
        TRY_CONVERT(DECIMAL(18,2), i.Crediti_tirocinio) AS Crediti_tirocinio,
        TRY_CONVERT(DECIMAL(18,2), i.Crediti_riconosciuti) AS Crediti_riconosciuti,
        TRY_CONVERT(INT, i.Conferma_semestre_filtro,0) AS Conferma_semestre_filtro,
        COALESCE(NULLIF(cl.comune_sede_studi_status,''), cl.Comune_Sede_studi) AS ComuneSedeStudi,
        ISNULL(c.COD_PROVINCIA,'') AS ProvinciaSedeStudi,
        CAST(ISNULL(cl.Corso_stem,0) AS BIT) AS CorsoStem,
        ROW_NUMBER() OVER (PARTITION BY D.NumDomanda ORDER BY TRY_CONVERT(INT, i.Anno_corso) DESC, COALESCE(i.Cod_corso_laurea,''), COALESCE(i.Cod_facolta,'')) AS rn
    FROM D
    LEFT JOIN vIscrizioni i
           ON i.Anno_accademico = @AA
          AND UPPER(LTRIM(RTRIM(i.Cod_fiscale))) = D.CodFiscale
          AND COALESCE(i.tipo_bando,'') = D.TipoBando
    LEFT JOIN Corsi_laurea cl
           ON i.Cod_corso_laurea     = cl.Cod_corso_laurea
          AND i.Anno_accad_inizio    = cl.Anno_accad_inizio
          AND i.Cod_tipo_ordinamento = cl.Cod_tipo_ordinamento
          AND i.Cod_facolta          = cl.Cod_facolta
          AND i.Cod_sede_studi       = cl.Cod_sede_studi
          AND i.Cod_tipologia_studi  = cl.Cod_tipologia_studi
    LEFT JOIN COMUNI c
           ON c.COD_COMUNE = COALESCE(NULLIF(cl.comune_sede_studi_status,''), cl.Comune_Sede_studi)
)
SELECT
    NumDomanda,
    CodFiscale,
    TipoBando,
    Cod_corso_laurea,
    Anno_corso,
    Cod_facolta,
    Cod_sede_studi,
    Cod_tipologia_studi,
    Crediti_tirocinio,
    Crediti_riconosciuti,
    Conferma_semestre_filtro,
    ComuneSedeStudi,
    ProvinciaSedeStudi,
    CorsoStem
FROM ISCR
WHERE rn = 1;";

        private const string AppartenenzaPopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT
        CAST(t.NumDomanda AS INT) AS NumDomanda,
        t.CodFiscale,
        COALESCE(t.TipoBando,'') AS TipoBando
    FROM {TEMP_TABLE} t
),
APP AS
(
    SELECT
        D.NumDomanda,
        D.CodFiscale,
        D.TipoBando,
        a.Cod_sede_distaccata,
        a.Cod_ente,
        ROW_NUMBER() OVER (PARTITION BY D.NumDomanda ORDER BY COALESCE(a.Cod_sede_distaccata,''), COALESCE(a.Cod_ente,'')) AS rn
    FROM D
    LEFT JOIN vAppartenenza a
           ON a.Anno_accademico = @AA
          AND UPPER(LTRIM(RTRIM(a.Cod_fiscale))) = D.CodFiscale
          AND COALESCE(a.tipo_bando,'') = D.TipoBando
)
SELECT
    NumDomanda,
    CodFiscale,
    TipoBando,
    Cod_sede_distaccata,
    Cod_ente
FROM APP
WHERE rn = 1;";

        private const string MeritoPopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT CAST(t.NumDomanda AS INT) AS NumDomanda
    FROM {TEMP_TABLE} t
),
MER AS
(
    SELECT
        D.NumDomanda,
        TRY_CONVERT(INT, m.Anno_immatricolaz) AS Anno_immatricolaz,
        TRY_CONVERT(INT, m.Numero_esami) AS Numero_esami,
        TRY_CONVERT(DECIMAL(18,2), m.Numero_crediti) AS Numero_crediti,
        TRY_CONVERT(DECIMAL(18,2), m.Somma_voti) AS Somma_voti,
        TRY_CONVERT(INT, m.Utilizzo_bonus,0) AS Utilizzo_bonus,
        TRY_CONVERT(DECIMAL(18,2), m.Crediti_utilizzati) AS Crediti_utilizzati,
        TRY_CONVERT(DECIMAL(18,2), m.Crediti_rimanenti) AS Crediti_rimanenti,
        TRY_CONVERT(DECIMAL(18,2), m.Crediti_riconosciuti_da_rinuncia) AS Crediti_riconosciuti_da_rinuncia,
        CONVERT(NVARCHAR(20), m.AACreditiRiconosciuti) AS AACreditiRiconosciuti,
        ROW_NUMBER() OVER (PARTITION BY D.NumDomanda ORDER BY D.NumDomanda) AS rn
    FROM D
    LEFT JOIN vMerito m
           ON m.Anno_accademico = @AA
          AND CAST(m.Num_domanda AS INT) = D.NumDomanda
)
SELECT
    NumDomanda,
    Anno_immatricolaz,
    Numero_esami,
    Numero_crediti,
    Somma_voti,
    Utilizzo_bonus,
    Crediti_utilizzati,
    Crediti_rimanenti,
    Crediti_riconosciuti_da_rinuncia,
    AACreditiRiconosciuti
FROM MER
WHERE rn = 1;";

        private void LoadIscrizioneCore(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadIscrizioneCore", $"AA={context.AnnoAccademico}");
            using var cmd = CreatePopulationCommand(context, IscrizioneCorePopulationSql, addAa: true);

            ReadAndMergeByKey(cmd, (info, reader) =>
            {
                var iscr = info.InformazioniIscrizione;
                iscr.TipoBando = reader.SafeGetString("TipoBando");
                iscr.AnnoCorso = reader.SafeGetInt("Anno_corso");
                iscr.CodCorsoLaurea = reader.SafeGetString("Cod_corso_laurea");
                iscr.CodFacolta = reader.SafeGetString("Cod_facolta");
                iscr.CodSedeStudi = reader.SafeGetString("Cod_sede_studi");

                string codTipologiaStudi = reader.SafeGetString("Cod_tipologia_studi");
                iscr.TipoCorso = TryParseInt(codTipologiaStudi, out var tipoCorso) ? tipoCorso : 0;

                iscr.CreditiTirocinio = reader.SafeGetDecimal("Crediti_tirocinio");
                iscr.CreditiRiconosciuti = reader.SafeGetDecimal("Crediti_riconosciuti");
                iscr.ConfermaSemestreFiltro = reader.SafeGetInt("Conferma_semestre_filtro");
                iscr.ComuneSedeStudi = reader.SafeGetString("ComuneSedeStudi");
                iscr.ProvinciaSedeStudi = reader.SafeGetString("ProvinciaSedeStudi");
                iscr.CorsoStem = reader.SafeGetBool("CorsoStem");
            });
        }

        private void LoadAppartenenza(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadAppartenenza", $"AA={context.AnnoAccademico}");
            using var cmd = CreatePopulationCommand(context, AppartenenzaPopulationSql, addAa: true);

            ReadAndMergeByKey(cmd, (info, reader) =>
            {
                info.InformazioniIscrizione.CodSedeDistaccata = reader.SafeGetString("Cod_sede_distaccata");
                info.InformazioniIscrizione.CodEnte = reader.SafeGetString("Cod_ente");
            });
        }

        private void LoadMerito(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadMerito", $"AA={context.AnnoAccademico}");
            var studentsByNumDomanda = BuildStudentsByNumDomandaMap(context);

            using var cmd = CreatePopulationCommand(context, MeritoPopulationSql, addAa: true);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                string numDomanda = NormalizeDomanda(
                    reader.SafeGetInt("NumDomanda").ToString(CultureInfo.InvariantCulture));

                if (!studentsByNumDomanda.TryGetValue(numDomanda, out var info))
                    continue;

                var iscr = info.InformazioniIscrizione;
                iscr.AnnoImmatricolazione = reader.SafeGetInt("Anno_immatricolaz");
                iscr.NumeroEsami = reader.SafeGetInt("Numero_esami");
                iscr.NumeroCrediti = reader.SafeGetDecimal("Numero_crediti");
                iscr.SommaVoti = reader.SafeGetDecimal("Somma_voti");
                iscr.UtilizzoBonus = reader.SafeGetInt("Utilizzo_bonus");
                iscr.CreditiUtilizzati = reader.SafeGetDecimal("Crediti_utilizzati");
                iscr.CreditiRimanenti = reader.SafeGetDecimal("Crediti_rimanenti");
                iscr.CreditiRiconosciutiDaRinuncia = reader.SafeGetDecimal("Crediti_riconosciuti_da_rinuncia");
                iscr.AACreditiRiconosciuti = reader.SafeGetString("AACreditiRiconosciuti");
            }
        }
    }
}
