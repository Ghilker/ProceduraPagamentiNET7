using ProcedureNet7.Verifica;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace ProcedureNet7
{
    internal sealed partial class VerificaRaccoltaDati
    {
        private SqlCommand CreatePopulationCommand(VerificaPipelineContext context, string sqlTemplate, bool addAa = false)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            string sql = sqlTemplate.Replace("{TEMP_TABLE}", context.TempPipelineTable);
            var command = new SqlCommand(sql, context.Connection) { CommandTimeout = 999999 };

            if (addAa)
                AddAaParameter(command, context.AnnoAccademico);

            return command;
        }

        private void ReadAndMergeByKey(
            SqlCommand command,
            Action<StudenteInfo, SqlDataReader> merge,
            string cfColumn = "CodFiscale",
            string domandaColumn = "NumDomanda")
        {
            if (command == null)
                throw new ArgumentNullException(nameof(command));
            if (merge == null)
                throw new ArgumentNullException(nameof(merge));

            using var reader = command.ExecuteReader();
            int domandaOrdinal = reader.GetOrdinal(domandaColumn);

            while (reader.Read())
            {
                var key = CreateStudentKey(
                    reader.SafeGetString(cfColumn),
                    ReadDomandaAsString(reader, domandaOrdinal));

                if (!TryGetStudentInfo(key, out var info))
                    continue;

                merge(info, reader);
            }
        }

        private static Dictionary<string, StudenteInfo> BuildStudentsByNumDomandaMap(VerificaPipelineContext context)
        {
            var result = new Dictionary<string, StudenteInfo>(StringComparer.OrdinalIgnoreCase);

            foreach (var pair in context.Students)
                result[pair.Key.NumDomanda] = pair.Value;

            return result;
        }
    }
}
