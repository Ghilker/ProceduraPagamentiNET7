﻿using ProcedureNet7.Verifica;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace ProcedureNet7
{
    internal sealed partial class VerificaRaccoltaDati
    {
        private const string IscrizioneCorePopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT
        CAST(t.NumDomanda AS INT) AS NumDomanda,
        t.CodFiscale,
        COALESCE(t.TipoBando,'') AS TipoBando
    FROM {TEMP_TABLE} t
),
MER AS
(
    SELECT
        D.NumDomanda,
        TRY_CONVERT(INT, m.ANNO_IMMATRICOLAZ) AS Anno_immatricolaz
    FROM D
    LEFT JOIN MERITO m
      ON m.ANNO_ACCADEMICO = @AA
     AND m.NUM_DOMANDA = D.NumDomanda
     AND m.DATA_VALIDITA =
     (
        SELECT MAX(m2.DATA_VALIDITA)
        FROM MERITO m2
        WHERE m2.ANNO_ACCADEMICO = m.ANNO_ACCADEMICO
          AND m2.NUM_DOMANDA = m.NUM_DOMANDA
     )
),
ISCR AS
(
    SELECT
        D.NumDomanda,
        D.CodFiscale,
        D.TipoBando,
        CONVERT(NVARCHAR(50), i.COD_CORSO_LAUREA) AS Cod_corso_laurea,
        CONVERT(NVARCHAR(20), i.COD_TIPO_ORDINAMENTO) AS Cod_tipo_ordinamento,
        TRY_CONVERT(INT, cl.DURATA_LEGALE) AS Durata_legale,
        TRY_CONVERT(INT, i.ANNO_CORSO) AS Anno_corso,
        CONVERT(NVARCHAR(50), cl.COD_FACOLTA) AS Cod_facolta,
        CONVERT(NVARCHAR(20), cl.ANNO_ACCAD_INIZIO) AS Anno_accad_inizio,
        CONVERT(NVARCHAR(50), i.COD_SEDE_STUDI) AS Cod_sede_studi,
        CONVERT(NVARCHAR(50), i.COD_TIPOLOGIA_STUDI) AS Cod_tipologia_studi,
        TRY_CONVERT(DECIMAL(18,2), i.CREDITI_TIROCINIO) AS Crediti_tirocinio,
        TRY_CONVERT(DECIMAL(18,2), i.CREDITI_RICONOSCIUTI) AS Crediti_riconosciuti,
        TRY_CONVERT(INT, i.CONFERMA_SEMESTRE_FILTRO) AS Conferma_semestre_filtro,
        TRY_CONVERT(INT, i.SEMESTRE) AS Semestre,
        TRY_CONVERT(INT, i.RIPETENTE) AS Ripetente,
        CAST(ISNULL(cl.CORSO_STEM,0) AS BIT) AS Stem,
        CAST(CASE WHEN ISNULL(ss.TELEMATICA,0) = 1 OR ISNULL(cl.CORSO_IN_PRESENZA,1) = 0 THEN 1 ELSE 0 END AS BIT) AS AlwaysA,
        CONVERT(NVARCHAR(50), ss.COD_ENTE) AS Cod_ente,
        CASE
            WHEN NULLIF(ISNULL(cl.COD_SEDE_DISTACCATA,''), '') IS NULL THEN '00000'
            ELSE cl.COD_SEDE_DISTACCATA
        END AS Cod_sede_distaccata,
        CASE
            WHEN NULLIF(ISNULL(cl.COD_SEDE_DISTACCATA,''), '') IS NULL
                 OR ISNULL(cl.COD_SEDE_DISTACCATA,'') = '00000'
                THEN CASE
                        WHEN ISNULL(cl.COMUNE_SEDE_STUDI,'') IN ('00000','0000') THEN 'H501'
                        ELSE ISNULL(cl.COMUNE_SEDE_STUDI,'')
                     END
            ELSE ISNULL(sd.COD_COMUNE,'')
        END AS ComuneSedeStudi,
        ROW_NUMBER() OVER (PARTITION BY D.NumDomanda ORDER BY i.DATA_VALIDITA DESC) AS rn
    FROM D
    LEFT JOIN MER m
      ON m.NumDomanda = D.NumDomanda
    LEFT JOIN ISCRIZIONI i
      ON i.COD_FISCALE = D.CodFiscale
     AND i.ANNO_ACCADEMICO = @AA
     AND i.DATA_VALIDITA =
     (
        SELECT MAX(i2.DATA_VALIDITA)
        FROM ISCRIZIONI i2
        WHERE i2.COD_FISCALE = i.COD_FISCALE
          AND i2.ANNO_ACCADEMICO = i.ANNO_ACCADEMICO
          AND (i2.TIPO_BANDO IS NULL OR i2.TIPO_BANDO LIKE 'L%')
     )
    LEFT JOIN CORSI_LAUREA cl
      ON cl.COD_CORSO_LAUREA = i.COD_CORSO_LAUREA
     AND cl.COD_TIPO_ORDINAMENTO = i.COD_TIPO_ORDINAMENTO
     AND cl.COD_FACOLTA = i.COD_FACOLTA
     AND (cl.ANNO_ACCAD_FINE >= CONVERT(NVARCHAR(20), ISNULL(m.Anno_immatricolaz,0)) OR cl.ANNO_ACCAD_FINE IS NULL)
    LEFT JOIN SEDE_STUDI ss
      ON ss.COD_SEDE_STUDI = i.COD_SEDE_STUDI
    LEFT JOIN SEDI_DISTACCATE sd
      ON sd.COD_SEDE_DISTACCATA = cl.COD_SEDE_DISTACCATA
)
SELECT
    I.NumDomanda,
    I.CodFiscale,
    I.TipoBando,
    I.Cod_corso_laurea,
    I.Cod_tipo_ordinamento,
    I.Durata_legale,
    I.Anno_corso,
    I.Cod_facolta,
    I.Anno_accad_inizio,
    I.Cod_sede_studi,
    I.Cod_tipologia_studi,
    I.Crediti_tirocinio,
    I.Crediti_riconosciuti,
    ISNULL(I.Conferma_semestre_filtro, 0) AS Conferma_semestre_filtro,
    ISNULL(I.Semestre, 0) AS Semestre,
    ISNULL(I.Ripetente, 0) AS Ripetente,
    I.Stem,
    I.AlwaysA,
    ISNULL(I.Cod_ente,'') AS Cod_ente,
    ISNULL(I.Cod_sede_distaccata,'00000') AS Cod_sede_distaccata,
    ISNULL(I.ComuneSedeStudi,'') AS ComuneSedeStudi,
    ISNULL(c.COD_PROVINCIA,'') AS ProvinciaSede
FROM ISCR I
LEFT JOIN COMUNI c
  ON c.COD_COMUNE = I.ComuneSedeStudi
WHERE I.rn = 1;";

        private const string AppartenenzaPopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT
    CAST(t.NumDomanda AS INT) AS NumDomanda,
    t.CodFiscale,
    CAST('00000' AS NVARCHAR(50)) AS Cod_sede_distaccata,
    CAST('' AS NVARCHAR(50)) AS Cod_ente
FROM {TEMP_TABLE} t
WHERE 1 = 0;";

        private const string MeritoPopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT CAST(t.NumDomanda AS INT) AS NumDomanda, t.CodFiscale
    FROM {TEMP_TABLE} t
)
SELECT
    D.NumDomanda,
    D.CodFiscale,
    TRY_CONVERT(INT, m.ANNO_IMMATRICOLAZ) AS Anno_immatricolaz,
    TRY_CONVERT(INT, m.NUMERO_ESAMI) AS Numero_esami,
    TRY_CONVERT(DECIMAL(18,2), m.NUMERO_CREDITI) AS Numero_crediti,
    TRY_CONVERT(DECIMAL(18,2), m.SOMMA_VOTI) AS Somma_voti,
    TRY_CONVERT(INT, m.CARRIERA_INTERR) AS Carriera_interr,
    TRY_CONVERT(INT, m.NUM_ANNI_INTERR) AS Num_anni_interr,
    TRY_CONVERT(INT, m.MESE_IMMATRICOLAZ) AS Mese_immatricolaz,
    TRY_CONVERT(DECIMAL(18,2), m.CREDITI_EXTRA_CURRICULARI) AS Crediti_extra_curriculari,
    ISNULL(TRY_CONVERT(INT, m.UTILIZZO_BONUS),0) AS Utilizzo_bonus,
    TRY_CONVERT(DECIMAL(18,2), m.CREDITI_UTILIZZATI) AS Crediti_utilizzati,
    TRY_CONVERT(DECIMAL(18,2), m.CREDITI_RIMANENTI) AS Crediti_rimanenti,
    TRY_CONVERT(DECIMAL(18,2), m.CREDITI_RICONOSCIUTI_DA_RINUNCIA) AS Crediti_riconosciuti_da_rinuncia,
    ISNULL(CONVERT(NVARCHAR(20), m.AACREDITIRICONOSCIUTI), '') AS AACreditiRiconosciuti
FROM D
LEFT JOIN MERITO m
  ON m.ANNO_ACCADEMICO = @AA
 AND m.NUM_DOMANDA = D.NumDomanda
 AND m.DATA_VALIDITA =
 (
    SELECT MAX(m2.DATA_VALIDITA)
    FROM MERITO m2
    WHERE m2.ANNO_ACCADEMICO = m.ANNO_ACCADEMICO
      AND m2.NUM_DOMANDA = m.NUM_DOMANDA
 );
";

        private const string CarrieraPregressaSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT
        CAST(t.NumDomanda AS INT) AS NumDomanda,
        t.CodFiscale,
        COALESCE(t.TipoBando,'') AS TipoBando
    FROM {TEMP_TABLE} t
)
SELECT
    D.NumDomanda,
    D.CodFiscale,
    D.TipoBando,
    CONVERT(NVARCHAR(50), cp.COD_AVVENIMENTO) AS Cod_avvenimento,
    TRY_CONVERT(INT, cp.ANNO_AVVENIMENTO) AS Anno_avvenimento,
    CONVERT(NVARCHAR(250), cp.UNIV_DI_CONSEGUIM) AS Univ_di_conseguim,
    CONVERT(NVARCHAR(250), cp.UNIV_PROVENIENZA) AS Univ_provenienza,
    TRY_CONVERT(INT, cp.PRIMA_IMMATRICOLAZ) AS Prima_immatricolaz,
    CONVERT(NVARCHAR(150), cp.TIPOLOGIA_CORSO) AS Tipologia_corso,
    TRY_CONVERT(INT, cp.DURATA_LEG_TITOLO_CONSEGUITO) AS Durata_leg_titolo_conseguito,
    TRY_CONVERT(INT, cp.PASSAGGIO_CORSO_ESTERO) AS Passaggio_corso_estero,
    CONVERT(NVARCHAR(250), cp.SEDE_ISTITUZIONE_UNIVERSITARIA) AS Sede_istituzione_universitaria,
    CONVERT(NVARCHAR(250), cp.BENEFICI_USUFRUITI) AS benefici_usufruiti,
    CONVERT(NVARCHAR(250), cp.IMPORTI_RESTITUITI) AS importi_restituiti,
    ISNULL(bu.AnniBeneficiUsufruitiLz, '') AS Anni_benefici_usufruiti_LZ,
    ISNULL(ir.AnniImportiRestituitiLz, '') AS Anni_importi_restituiti_LZ,
    TRY_CONVERT(DECIMAL(18,2), cp.NUMERO_CREDITI) AS numero_crediti,
    TRY_CONVERT(INT, cp.ANNO_CORSO) AS anno_corso,
    TRY_CONVERT(INT, cp.RIPETENTE) AS ripetente,
    TRY_CONVERT(INT, cp.ISCRITTO_SEMESTRE_FILTRODI) AS Iscritto_semestre_filtroDI
FROM D
JOIN CARRIERA_PREGRESSA cp
  ON cp.ANNO_ACCADEMICO = @AA
 AND cp.COD_FISCALE = D.CodFiscale
 AND cp.riga_valida = 0
 AND cp.DATA_VALIDITA =
 (
    SELECT MAX(cp2.DATA_VALIDITA)
    FROM CARRIERA_PREGRESSA cp2
    WHERE cp2.COD_FISCALE = cp.COD_FISCALE
      AND cp2.ANNO_ACCADEMICO = cp.ANNO_ACCADEMICO
      AND cp2.COD_AVVENIMENTO = cp.COD_AVVENIMENTO
 )
OUTER APPLY
(
    SELECT
        STUFF
        (
            (
                SELECT '|' + CONVERT(NVARCHAR(10), x.AnnoCarriera)
                FROM
                (
                    SELECT DISTINCT TRY_CONVERT(INT, b.Anno_carriera) AS AnnoCarriera
                    FROM Benefici_usufruiti_LZ b
                    WHERE b.Cod_fiscale = D.CodFiscale
                      AND b.Anno_accademico = @AA
                      AND ISNULL(b.Riga_valida, 0) = 1
                      AND TRY_CONVERT(INT, b.Anno_carriera) IS NOT NULL
                      AND UPPER(ISNULL(cp.COD_AVVENIMENTO, '')) = 'RI'
                      AND ISNULL(TRY_CONVERT(INT, cp.BENEFICI_USUFRUITI), 0) = 1
                ) x
                ORDER BY x.AnnoCarriera
                FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(MAX)'),
            1,
            1,
            ''
        ) AS AnniBeneficiUsufruitiLz
) bu
OUTER APPLY
(
    SELECT
        STUFF
        (
            (
                SELECT '|' + CONVERT(NVARCHAR(10), x.AnnoCarriera)
                FROM
                (
                    SELECT DISTINCT TRY_CONVERT(INT, r.Anno_carriera) AS AnnoCarriera
                    FROM Importi_restituiti_LZ r
                    WHERE r.Cod_fiscale = D.CodFiscale
                      AND r.Anno_accademico = @AA
                      AND ISNULL(r.Riga_valida, 0) = 1
                      AND TRY_CONVERT(INT, r.Anno_carriera) IS NOT NULL
                      AND UPPER(ISNULL(cp.COD_AVVENIMENTO, '')) = 'RI'
                      AND ISNULL(TRY_CONVERT(INT, cp.IMPORTI_RESTITUITI), 0) = 1
                ) x
                ORDER BY x.AnnoCarriera
                FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(MAX)'),
            1,
            1,
            ''
        ) AS AnniImportiRestituitiLz
) ir;
";

        private const string MeritoDurataLegaleCorsoColumn = "Durata_legale";
        private const string MeritoCodTipoOrdinamentoCorsoColumn = "Cod_tipo_ordinamento";

        private static IscrizioneEsitoFactsRaw GetOrCreateIscrizioneEsitoFacts(VerificaPipelineContext context, StudentKey key)
            => context.GetOrCreateIscrizioneEsitoFacts(key);

        private void LoadBaseIscrizione(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadBaseIscrizione", $"AA={context.AnnoAccademico}");
            LoadIscrizioneCore(context);
            LoadMerito(context);
        }

        private void LoadIscrizioneCore(VerificaPipelineContext context)
        {
            using var cmd = CreatePopulationCommand(IscrizioneCorePopulationSql, context);
            ReadAndMergeByStudentKey(cmd, (reader, info) =>
            {
                var iscr = info.InformazioniIscrizione;
                iscr.TipoBando = reader.SafeGetString("TipoBando");
                iscr.AnnoCorso = reader.SafeGetInt("Anno_corso");
                iscr.CodCorsoLaurea = reader.SafeGetString("Cod_corso_laurea");
                iscr.CodTipoOrdinamentoCorso = reader.SafeGetString("Cod_tipo_ordinamento");
                iscr.DurataLegaleCorso = reader.SafeGetInt("Durata_legale");
                iscr.CorsoMedicina = reader.SafeGetInt("Durata_legale") == 6;
                iscr.CodFacolta = reader.SafeGetString("Cod_facolta");
                iscr.AnnoAccadInizioCorso = reader.SafeGetString("Anno_accad_inizio");
                iscr.CodSedeStudi = reader.SafeGetString("Cod_sede_studi");
                iscr.CodEnte = reader.SafeGetString("Cod_ente");
                iscr.CodSedeDistaccata = reader.SafeGetString("Cod_sede_distaccata");
                iscr.ComuneSedeStudi = reader.SafeGetString("ComuneSedeStudi").Trim();
                iscr.ProvinciaSedeStudi = reader.SafeGetString("ProvinciaSede").Trim().ToUpperInvariant();
                iscr.CorsoStem = reader.SafeGetBool("Stem");
                info.InformazioniSede.AlwaysA = reader.SafeGetBool("AlwaysA");
                iscr.CreditiTirocinio = reader.SafeGetDecimal("Crediti_tirocinio");
                iscr.CreditiRiconosciuti = reader.SafeGetDecimal("Crediti_riconosciuti");
                iscr.ConfermaSemestreFiltro = reader.SafeGetInt("Conferma_semestre_filtro");

                var key = CreateStudentKey(info.InformazioniPersonali.CodFiscale, info.InformazioniPersonali.NumDomanda);
                var facts = GetOrCreateIscrizioneEsitoFacts(context, key);
                facts.Semestre = reader.SafeGetInt("Semestre");
                facts.IscrittoRipetente = reader.SafeGetInt("Ripetente") != 0;

                if (TryParseInt(reader.SafeGetString("Cod_tipologia_studi"), out var tipoCorso))
                    iscr.TipoCorso = tipoCorso;
            });
        }

        private void LoadMerito(VerificaPipelineContext context)
        {
            using var cmd = CreatePopulationCommand(MeritoPopulationSql, context);
            ReadAndMergeByStudentKey(cmd, (reader, info) =>
            {
                var iscr = info.InformazioniIscrizione;
                iscr.AnnoImmatricolazione = reader.SafeGetInt("Anno_immatricolaz");
                iscr.NumeroEsami = reader.SafeGetInt("Numero_esami");
                iscr.NumeroCrediti = reader.SafeGetDecimal("Numero_crediti");
                iscr.SommaVoti = reader.SafeGetDecimal("Somma_voti");
                iscr.UtilizzoBonus = reader.SafeGetInt("Utilizzo_bonus");
                iscr.CreditiUtilizzati = reader.SafeGetDecimal("Crediti_utilizzati");
                iscr.CreditiRimanenti = reader.SafeGetDecimal("Crediti_rimanenti");
                iscr.CreditiRiconosciutiDaRinuncia = reader.SafeGetDecimal("Crediti_riconosciuti_da_rinuncia");
                iscr.AACreditiRiconosciuti = reader.SafeGetString("AACreditiRiconosciuti");

                var key = CreateStudentKey(info.InformazioniPersonali.CodFiscale, info.InformazioniPersonali.NumDomanda);
                var facts = GetOrCreateIscrizioneEsitoFacts(context, key);
                facts.CarrieraInterrotta = reader.SafeGetInt("Carriera_interr") != 0;
                facts.NumAnniInterruzione = reader.SafeGetInt("Num_anni_interr");
                facts.MeseImmatricolazione = reader.SafeGetInt("Mese_immatricolaz");
                facts.CreditiExtraCurriculari = reader.SafeGetDecimal("Crediti_extra_curriculari");
            });
        }


        private void LoadCarrieraPregressa(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadCarrieraPregressa", $"AA={context.AnnoAccademico}");
            using var cmd = CreatePopulationCommand(CarrieraPregressaSql, context);
            ReadAndMergeByStudentKey(cmd, (reader, info) =>
            {
                string codAvvenimento = reader.SafeGetString("Cod_avvenimento");
                string beneficiUsufruiti = reader.SafeGetString("benefici_usufruiti");
                string importiRestituiti = reader.SafeGetString("importi_restituiti");

                info.InformazioniIscrizione.CarrierePregresse.Add(new InformazioniCarrieraPregressa
                {
                    CodAvvenimento = codAvvenimento,
                    AnnoAvvenimento = reader.SafeGetInt("Anno_avvenimento"),
                    UnivDiConseguim = reader.SafeGetString("Univ_di_conseguim"),
                    UnivProvenienza = reader.SafeGetString("Univ_provenienza"),
                    PrimaImmatricolaz = reader.SafeGetInt("Prima_immatricolaz"),
                    TipologiaCorso = reader.SafeGetString("Tipologia_corso"),
                    DurataLegTitoloConseguito = reader.SafeGetInt("Durata_leg_titolo_conseguito"),
                    PassaggioCorsoEstero = reader.SafeGetInt("Passaggio_corso_estero"),
                    SedeIstituzioneUniversitaria = reader.SafeGetString("Sede_istituzione_universitaria"),
                    BeneficiUsufruiti = beneficiUsufruiti,
                    ImportiRestituiti = importiRestituiti,
                    NumeroCrediti = reader.SafeGetDecimal("numero_crediti"),
                    AnnoCorso = reader.SafeGetInt("anno_corso"),
                    Ripetente = reader.SafeGetInt("ripetente"),
                    ConfermaSemestreFiltroDi = reader.SafeGetInt("Iscritto_semestre_filtroDI")
                });

                if (string.Equals((codAvvenimento ?? string.Empty).Trim(), "RI", StringComparison.OrdinalIgnoreCase))
                {
                    var key = CreateStudentKey(info.InformazioniPersonali.CodFiscale, info.InformazioniPersonali.NumDomanda);
                    var items = context.GetOrCreateCarrieraPregressaBeneficiRi(key);

                    items.Add(new CarrieraPregressaBeneficiRiRaw
                    {
                        CodAvvenimento = codAvvenimento,
                        BeneficiUsufruiti = beneficiUsufruiti,
                        ImportiRestituiti = importiRestituiti,
                        AnniBeneficiUsufruitiLz = reader.SafeGetString("Anni_benefici_usufruiti_LZ"),
                        AnniImportiRestituitiLz = reader.SafeGetString("Anni_importi_restituiti_LZ"),
                        SedeIstituzioneUniversitaria = reader.SafeGetString("Sede_istituzione_universitaria"),
                        TipologiaCorso = reader.SafeGetString("Tipologia_corso"),
                        DurataLegTitoloConseguito = reader.SafeGetInt("Durata_leg_titolo_conseguito"),
                        AnnoAvvenimento = reader.SafeGetInt("Anno_avvenimento")
                    });
                }
            });
        }

        private static void BuildCarrieraPregressaAggregate(VerificaPipelineContext context)
        {
            foreach (var info in context.Students.Values)
            {
                var iscr = info.InformazioniIscrizione;
                var items = iscr.CarrierePregresse;

                int count = 0;
                int? lastYear = null;
                decimal totalCredits = 0m;
                int hasPassaggioEstero = 0;
                int hasRipetenza = 0;
                var codici = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                foreach (var item in items)
                {
                    count++;

                    if (item.AnnoAvvenimento.HasValue && (!lastYear.HasValue || item.AnnoAvvenimento.Value > lastYear.Value))
                        lastYear = item.AnnoAvvenimento.Value;

                    totalCredits += item.NumeroCrediti ?? 0m;

                    if (item.PassaggioCorsoEstero != 0)
                        hasPassaggioEstero = 1;

                    if (item.Ripetente != 0)
                        hasRipetenza = 1;

                    if (!string.IsNullOrWhiteSpace(item.CodAvvenimento))
                        codici.Add(item.CodAvvenimento);
                }

                iscr.NumeroEventiCarrieraPregressa = count;
                iscr.UltimoAnnoAvvenimentoCarrieraPregressa = count == 0 ? null : lastYear;
                iscr.TotaleCreditiCarrieraPregressa = totalCredits;
                iscr.HaPassaggioCorsoEsteroCarrieraPregressa = hasPassaggioEstero;
                iscr.HaRipetenzaCarrieraPregressa = hasRipetenza;
                iscr.CodiciAvvenimentoCarrieraPregressa = string.Join("|", codici);

                var key = CreateStudentKey(info.InformazioniPersonali.CodFiscale, info.InformazioniPersonali.NumDomanda);
                var facts = GetOrCreateIscrizioneEsitoFacts(context, key);
                InformazioniCarrieraPregressa? bestTs = null;
                int bestTsYear = int.MinValue;

                foreach (var item in items)
                {
                    if (!string.Equals((item.CodAvvenimento ?? string.Empty).Trim(), "TS", StringComparison.OrdinalIgnoreCase))
                        continue;

                    int year = item.AnnoAvvenimento ?? int.MinValue;
                    if (bestTs == null || year > bestTsYear)
                    {
                        bestTs = item;
                        bestTsYear = year;
                    }
                }

                facts.PassaggioTrasferimento = bestTs != null;
                facts.RipetenteDaPassaggio = bestTs != null && bestTs.Ripetente != 0;
                facts.PrimaImmatricolazTs = bestTs?.PrimaImmatricolaz;
                facts.AaTrasferimento = bestTs?.AnnoAvvenimento;
            }
        }


        private static void ApplyCreditiMeritoDerivati(VerificaPipelineContext context)
        {
            foreach (var pair in context.Students)
            {
                var info = pair.Value;
                var iscr = info.InformazioniIscrizione;
                var facts = GetOrCreateIscrizioneEsitoFacts(context, pair.Key);

                if (facts.CreditiMeritoNormalizzati)
                    continue;

                decimal rawCrediti = iscr.NumeroCrediti ?? 0m;
                iscr.NumeroCreditiRaw = rawCrediti;
                if (rawCrediti == 0m)
                {
                    facts.CreditiMeritoNormalizzati = true;
                    continue;
                }

                bool passaggio = facts.PassaggioTrasferimento == true;
                bool ripetenteDaPassaggio = facts.RipetenteDaPassaggio == true;
                if (!passaggio || ripetenteDaPassaggio)
                {
                    decimal creditiDaRinuncia = iscr.CreditiRiconosciutiDaRinuncia ?? 0m;
                    decimal creditiExtra = facts.CreditiExtraCurriculari ?? 0m;
                    iscr.NumeroCrediti = rawCrediti - creditiDaRinuncia - creditiExtra;
                }

                facts.CreditiMeritoNormalizzati = true;
            }
        }

        private const string EsamiCatalogSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT
    CONVERT(NVARCHAR(50), e.COD_CORSO_LAUREA) AS Cod_corso_laurea,
    CONVERT(NVARCHAR(20), e.COD_TIPO_ORDINAMENTO) AS Cod_tipo_ordinamento,
    CONVERT(NVARCHAR(20), e.Anno_Accad_Inizio) AS Anno_accad_inizio,
    TRY_CONVERT(INT, e.ANNO_CORSO) AS Anno_corso,
    SUM(TRY_CONVERT(DECIMAL(18,2), e.NUM_ESAMI)) AS Numero_esami
FROM ESAMI e
WHERE e.ANNO_ACCADEMICO = @AA
GROUP BY
    CONVERT(NVARCHAR(50), e.COD_CORSO_LAUREA),
    CONVERT(NVARCHAR(20), e.COD_TIPO_ORDINAMENTO),
    CONVERT(NVARCHAR(20), e.Anno_Accad_Inizio),
    TRY_CONVERT(INT, e.ANNO_CORSO);";

        private const string CreditiRichiestiCatalogSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT
    TRY_CONVERT(INT, cr.Tipologia_corso) AS Tipologia_corso,
    TRY_CONVERT(INT, cr.Anno_corso) AS Anno_corso,
    CONVERT(NVARCHAR(50), ISNULL(cr.Cod_corso_laurea, '')) AS Cod_corso_laurea,
    TRY_CONVERT(DECIMAL(18,2), cr.Crediti_richiesti) AS Crediti_richiesti,
    CAST(CASE WHEN TRY_CONVERT(INT, cr.Disabile) = 1 THEN 1 ELSE 0 END AS BIT) AS Disabile,
    TRY_CONVERT(INT, cr.Id_Crediti_richiesti) AS Id_Crediti_richiesti
FROM Crediti_richiesti cr
WHERE cr.Anno_accademico = @AA;";

        private void LoadEsamiCatalog(VerificaPipelineContext context)
        {
            context.EsamiCatalog.Clear();

            if (!ObjectExists(context.Connection, "ESAMI"))
                return;

            using var cmd = new SqlCommand(EsamiCatalogSql, context.Connection)
            {
                CommandType = CommandType.Text,
                CommandTimeout = 9999999
            };
            cmd.Parameters.Add("@AA", SqlDbType.Char, 8).Value = context.AnnoAccademico;

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                context.EsamiCatalog.Add(
                    reader.SafeGetString("Cod_corso_laurea"),
                    reader.SafeGetString("Cod_tipo_ordinamento"),
                    reader.SafeGetString("Anno_accad_inizio"),
                    reader.SafeGetInt("Anno_corso"),
                    reader.SafeGetDecimal("Numero_esami"));
            }
        }

        private void LoadCreditiRichiestiCatalog(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadCreditiRichiestiCatalog", $"AA={context.AnnoAccademico}");

            context.CreditiRichiestiCatalog.Clear();

            if (!ObjectExists(context.Connection, "Crediti_richiesti"))
                return;

            using var cmd = new SqlCommand(CreditiRichiestiCatalogSql, context.Connection)
            {
                CommandType = CommandType.Text,
                CommandTimeout = 9999999
            };
            cmd.Parameters.Add("@AA", SqlDbType.Char, 8).Value = context.AnnoAccademico;

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                context.CreditiRichiestiCatalog.Add(
                    reader.SafeGetInt("Tipologia_corso"),
                    reader.SafeGetInt("Anno_corso"),
                    reader.SafeGetString("Cod_corso_laurea"),
                    reader.SafeGetDecimal("Crediti_richiesti"),
                    reader.SafeGetBool("Disabile"),
                    reader.SafeGetInt("Id_Crediti_richiesti"));
            }
        }

        private static bool TryParseInt(string? value, out int parsed)
            => int.TryParse((value ?? string.Empty).Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed);
    }
}
