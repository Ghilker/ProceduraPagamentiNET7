using ProcedureNet7.Verifica;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace ProcedureNet7
{
    internal sealed partial class VerificaRaccoltaDati
    {
        private const string CarrieraPregressaSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT
        CAST(t.NumDomanda AS INT) AS NumDomanda,
        t.CodFiscale AS CodFiscale,
        COALESCE(t.TipoBando,'') AS TipoBando
    FROM {TEMP_TABLE} t
)
SELECT
    D.NumDomanda,
    D.CodFiscale,
    D.TipoBando,
    CONVERT(NVARCHAR(50), cp.Cod_avvenimento) AS Cod_avvenimento,
    TRY_CONVERT(INT, cp.Anno_avvenimento) AS Anno_avvenimento,
    CONVERT(NVARCHAR(250), cp.Univ_di_conseguim) AS Univ_di_conseguim,
    CONVERT(NVARCHAR(250), cp.Univ_provenienza) AS Univ_provenienza,
    TRY_CONVERT(INT, cp.Prima_immatricolaz) AS Prima_immatricolaz,
    CONVERT(NVARCHAR(150), cp.Tipologia_corso) AS Tipologia_corso,
    TRY_CONVERT(INT, cp.Durata_leg_titolo_conseguito) AS Durata_leg_titolo_conseguito,
    TRY_CONVERT(INT, cp.Passaggio_corso_estero,0) AS Passaggio_corso_estero,
    CONVERT(NVARCHAR(250), cp.Sede_istituzione_universitaria) AS Sede_istituzione_universitaria,
    CONVERT(NVARCHAR(250), cp.benefici_usufruiti) AS benefici_usufruiti,
    CONVERT(NVARCHAR(250), cp.importi_restituiti) AS importi_restituiti,
    TRY_CONVERT(DECIMAL(18,2), cp.numero_crediti) AS numero_crediti,
    TRY_CONVERT(INT, cp.anno_corso) AS anno_corso,
    TRY_CONVERT(INT, cp.ripetente,0) AS ripetente,
    CONVERT(NVARCHAR(250), cp.Ateneo) AS Ateneo,
    CONVERT(NVARCHAR(50), cp.CodComune_Ateneo) AS CodComune_Ateneo,
    CONVERT(NVARCHAR(50), cp.CodAteneo) AS CodAteneo,
    TRY_CONVERT(INT, cp.Iscritto_semestre_filtroDI,0) AS Iscritto_semestre_filtroDI
FROM D
JOIN vCARRIERA_PREGRESSA cp
  ON cp.Anno_accademico = @AA
 AND cp.Cod_fiscale = D.CodFiscale
;";

        private static void ResetIscrizioneState(VerificaPipelineContext context)
        {
            foreach (var info in context.Students.Values)
            {
                var iscr = info.InformazioniIscrizione;
                iscr.TipoBando = string.Empty;
                iscr.AnnoCorso = 0;
                iscr.TipoCorso = 0;
                iscr.CodCorsoLaurea = string.Empty;
                iscr.CodFacolta = string.Empty;
                iscr.CodSedeStudi = string.Empty;
                iscr.ComuneSedeStudi = string.Empty;
                iscr.ProvinciaSedeStudi = string.Empty;
                iscr.CorsoStem = false;
                iscr.CodEnte = string.Empty;
                iscr.CodSedeDistaccata = string.Empty;
                iscr.CreditiTirocinio = null;
                iscr.CreditiRiconosciuti = null;
                iscr.ConfermaSemestreFiltro = 0;
                iscr.AnnoImmatricolazione = null;
                iscr.NumeroEsami = null;
                iscr.NumeroCrediti = null;
                iscr.SommaVoti = null;
                iscr.UtilizzoBonus = 0;
                iscr.CreditiUtilizzati = null;
                iscr.CreditiRimanenti = null;
                iscr.CreditiRiconosciutiDaRinuncia = null;
                iscr.AACreditiRiconosciuti = string.Empty;
                iscr.NumeroEventiCarrieraPregressa = 0;
                iscr.UltimoAnnoAvvenimentoCarrieraPregressa = null;
                iscr.TotaleCreditiCarrieraPregressa = 0m;
                iscr.HaPassaggioCorsoEsteroCarrieraPregressa = 0;
                iscr.HaRipetenzaCarrieraPregressa = 0;
                iscr.CodiciAvvenimentoCarrieraPregressa = string.Empty;
                iscr.CarrierePregresse.Clear();
            }
        }

        private void LoadBaseIscrizione(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadBaseIscrizione", $"AA={context.AnnoAccademico}");
            LoadIscrizioneCore(context);
            LoadAppartenenza(context);
            LoadMerito(context);
        }

        private void LoadCarrieraPregressa(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadCarrieraPregressa", $"AA={context.AnnoAccademico}");
            using var cmd = CreatePopulationCommand(context, CarrieraPregressaSql, addAa: true);

            ReadAndMergeByKey(cmd, (info, reader) =>
            {
                info.InformazioniIscrizione.CarrierePregresse.Add(new InformazioniCarrieraPregressa
                {
                    CodAvvenimento = reader.SafeGetString("Cod_avvenimento"),
                    AnnoAvvenimento = reader.SafeGetInt("Anno_avvenimento"),
                    UnivDiConseguim = reader.SafeGetString("Univ_di_conseguim"),
                    UnivProvenienza = reader.SafeGetString("Univ_provenienza"),
                    PrimaImmatricolaz = reader.SafeGetInt("Prima_immatricolaz"),
                    TipologiaCorso = reader.SafeGetString("Tipologia_corso"),
                    DurataLegTitoloConseguito = reader.SafeGetInt("Durata_leg_titolo_conseguito"),
                    PassaggioCorsoEstero = reader.SafeGetInt("Passaggio_corso_estero"),
                    SedeIstituzioneUniversitaria = reader.SafeGetString("Sede_istituzione_universitaria"),
                    BeneficiUsufruiti = reader.SafeGetString("benefici_usufruiti"),
                    ImportiRestituiti = reader.SafeGetString("importi_restituiti"),
                    NumeroCrediti = reader.SafeGetDecimal("numero_crediti"),
                    AnnoCorso = reader.SafeGetInt("anno_corso"),
                    Ripetente = reader.SafeGetInt("ripetente"),
                    Ateneo = reader.SafeGetString("Ateneo"),
                    CodComuneAteneo = reader.SafeGetString("CodComune_Ateneo"),
                    CodAteneo = reader.SafeGetString("CodAteneo"),
                    ConfermaSemestreFiltroDi = reader.SafeGetInt("Iscritto_semestre_filtroDI")
                });
            });
        }

        private static void BuildCarrieraPregressaAggregate(VerificaPipelineContext context)
        {
            foreach (var info in context.Students.Values)
            {
                var iscr = info.InformazioniIscrizione;
                var items = iscr.CarrierePregresse;

                int count = 0;
                int? lastYear = null;
                decimal totalCredits = 0m;
                int hasPassaggioEstero = 0;
                int hasRipetenza = 0;
                var codici = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                foreach (var item in items)
                {
                    count++;

                    if (item.AnnoAvvenimento.HasValue && (!lastYear.HasValue || item.AnnoAvvenimento.Value > lastYear.Value))
                        lastYear = item.AnnoAvvenimento.Value;

                    totalCredits += item.NumeroCrediti ?? 0m;

                    if (item.PassaggioCorsoEstero != 0)
                        hasPassaggioEstero = 1;

                    if (item.Ripetente != 0)
                        hasRipetenza = 1;

                    if (!string.IsNullOrWhiteSpace(item.CodAvvenimento))
                        codici.Add(item.CodAvvenimento);
                }

                iscr.NumeroEventiCarrieraPregressa = count;
                iscr.UltimoAnnoAvvenimentoCarrieraPregressa = count == 0 ? null : lastYear;
                iscr.TotaleCreditiCarrieraPregressa = totalCredits;
                iscr.HaPassaggioCorsoEsteroCarrieraPregressa = hasPassaggioEstero;
                iscr.HaRipetenzaCarrieraPregressa = hasRipetenza;
                iscr.CodiciAvvenimentoCarrieraPregressa = string.Join("|", codici);
            }
        }

        private static bool TryParseInt(string? value, out int parsed)
        {
            return int.TryParse((value ?? string.Empty).Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed);
        }
    }
}
