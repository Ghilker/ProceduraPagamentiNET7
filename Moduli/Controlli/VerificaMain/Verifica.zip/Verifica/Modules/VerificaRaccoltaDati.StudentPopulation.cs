using ProcedureNet7.Verifica;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace ProcedureNet7
{
    internal sealed partial class VerificaRaccoltaDati
    {
        private const string EsitoBsPopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT
    CAST(t.NumDomanda AS INT) AS NumDomanda,
    t.CodFiscale,
    CAST(ISNULL(t.CodTipoEsitoBS,0) AS INT) AS CodTipoEsitoBS,
    CAST(ISNULL(t.ImportoAssegnato,0) AS DECIMAL(18,2)) AS ImportoAssegnato
FROM {TEMP_TABLE} t;";

        private const string StatusCompilazionePopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT
    CAST(t.NumDomanda AS INT) AS NumDomanda,
    t.CodFiscale,
    CAST(ISNULL(t.StatusCompilazione,0) AS INT) AS StatusCompilazione
FROM {TEMP_TABLE} t;";

        private const string DatiPersonaliPopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT CAST(t.NumDomanda AS INT) AS NumDomanda, t.CodFiscale
    FROM {TEMP_TABLE} t
)
SELECT
    D.NumDomanda,
    D.CodFiscale,
    ISNULL(s.Sesso,'') AS StudenteSesso,
    CAST(CASE WHEN ISNULL(dg.Rifug_politico,0) = 1 THEN 1 ELSE 0 END AS BIT) AS RifugiatoPolitico,
    CAST(CASE WHEN ISNULL(dg.Invalido,0) = 1 THEN 1 ELSE 0 END AS BIT) AS Invalido
FROM D
LEFT JOIN Studente s
       ON UPPER(LTRIM(RTRIM(s.Cod_Fiscale))) = D.CodFiscale
LEFT JOIN vDATIGENERALI_dom dg
       ON dg.Anno_accademico = @AA
      AND CAST(dg.Num_domanda AS INT) = D.NumDomanda;";

        private const string MonetizzazionePopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT CAST(t.NumDomanda AS INT) AS NumDomanda, t.CodFiscale
    FROM {TEMP_TABLE} t
)
SELECT
    D.NumDomanda,
    D.CodFiscale,
    CAST(CASE WHEN ISNULL(mm.Concessa_monetizzazione,0) = 1 THEN 1 ELSE 0 END AS BIT) AS ConcessaMonetizzazione
FROM D
LEFT JOIN vMonetizzazione_Mensa mm
       ON mm.Num_Domanda = D.NumDomanda;";

        private const string NucleoFamiliareStatusPopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT CAST(t.NumDomanda AS INT) AS NumDomanda, t.CodFiscale
    FROM {TEMP_TABLE} t
)
SELECT
    D.NumDomanda,
    D.CodFiscale,
    CAST(ISNULL(n.Num_componenti,0) AS INT) AS NumComponenti,
    CAST(ISNULL(n.Numero_conviventi_estero,0) AS INT) AS NumConvEstero
FROM D
LEFT JOIN VNUCLEO_FAMILIARE n
       ON n.Anno_accademico = @AA
      AND CAST(n.Num_domanda AS INT) = D.NumDomanda;";

        private const string ResidenzaPopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT CAST(t.NumDomanda AS INT) AS NumDomanda, t.CodFiscale
    FROM {TEMP_TABLE} t
)
SELECT
    D.NumDomanda,
    D.CodFiscale,
    ISNULL(r.Cod_comune,'') AS ComuneResidenza,
    UPPER(ISNULL(r.provincia_residenza,'')) AS ProvinciaResidenza
FROM D
LEFT JOIN vResidenza r
       ON r.Anno_accademico = @AA
      AND UPPER(LTRIM(RTRIM(r.Cod_fiscale))) = D.CodFiscale;";

        private const string StatusSedeBasePopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT
        CAST(t.NumDomanda AS INT) AS NumDomanda,
        t.CodFiscale,
        COALESCE(t.TipoBando,'') AS TipoBando
    FROM {TEMP_TABLE} t
),
VV AS
(
    SELECT CAST(v.Num_domanda AS INT) AS NumDomanda, ISNULL(v.Status_sede,'') AS StatusSedeAttuale
    FROM vValori_calcolati v
    JOIN D ON D.NumDomanda = CAST(v.Num_domanda AS INT)
    WHERE v.Anno_accademico = @AA
),
Forzature AS
(
    SELECT
        UPPER(LTRIM(RTRIM(f.Cod_Fiscale))) AS CodFiscale,
        UPPER(LTRIM(RTRIM(f.Status_sede))) AS ForcedStatus
    FROM Forzature_StatusSede f
    JOIN D ON D.CodFiscale = UPPER(LTRIM(RTRIM(f.Cod_Fiscale)))
    WHERE f.Anno_Accademico = @AA
      AND f.Data_fine_validita IS NULL
      AND f.Status_sede IN ('A','B','C','D')
),
ISCR AS
(
    SELECT
        D.NumDomanda,
        i.Cod_sede_studi AS CodSedeStudi,
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(cl.Cod_sede_distaccata,''))), '') IS NULL THEN '00000'
            ELSE LTRIM(RTRIM(cl.Cod_sede_distaccata))
        END AS CodSedeDistaccata,
        COALESCE(NULLIF(cl.comune_sede_studi_status,''), cl.Comune_Sede_studi) AS ComuneSedeStudi,
        CAST(
            CASE
                WHEN ISNULL(ss.Telematica,0) = 1 OR ISNULL(cl.corso_in_presenza,1) = 0 THEN 1
                ELSE 0
            END
        AS BIT) AS AlwaysA,
        ROW_NUMBER() OVER
        (
            PARTITION BY D.NumDomanda
            ORDER BY TRY_CONVERT(INT, i.Anno_corso) DESC, COALESCE(i.Cod_corso_laurea,''), COALESCE(i.Cod_facolta,'')
        ) AS rn
    FROM D
    LEFT JOIN vIscrizioni i
           ON i.Anno_accademico = @AA
          AND UPPER(LTRIM(RTRIM(i.Cod_fiscale))) = D.CodFiscale
          AND COALESCE(i.Tipo_bando,'') = COALESCE(D.TipoBando,'')
    LEFT JOIN Corsi_laurea cl
           ON i.Cod_corso_laurea     = cl.Cod_corso_laurea
          AND i.Anno_accad_inizio    = cl.Anno_accad_inizio
          AND i.Cod_tipo_ordinamento = cl.Cod_tipo_ordinamento
          AND i.Cod_facolta          = cl.Cod_facolta
          AND i.Cod_sede_studi       = cl.Cod_sede_studi
          AND i.Cod_tipologia_studi  = cl.Cod_tipologia_studi
    LEFT JOIN Sede_studi ss
           ON ss.Cod_sede_studi = i.Cod_sede_studi
),
ISCR1 AS
(
    SELECT NumDomanda, CodSedeStudi, CodSedeDistaccata, ComuneSedeStudi, AlwaysA
    FROM ISCR
    WHERE rn = 1
),
RES AS
(
    SELECT
        D.NumDomanda,
        ISNULL(r.Cod_comune,'') AS ComuneResidenza
    FROM D
    LEFT JOIN vResidenza r
           ON r.Anno_accademico = @AA
          AND UPPER(LTRIM(RTRIM(r.Cod_fiscale))) = D.CodFiscale
),
PA_LAST AS
(
    SELECT
        CAST(ec.Num_domanda AS INT) AS NumDomanda,
        CAST(ec.Cod_tipo_esito AS INT) AS CodTipoEsito,
        ROW_NUMBER() OVER (PARTITION BY CAST(ec.Num_domanda AS INT) ORDER BY ec.Data_validita DESC) AS rn
    FROM ESITI_CONCORSI ec
    JOIN D ON D.NumDomanda = CAST(ec.Num_domanda AS INT)
    JOIN vBenefici_richiesti vb
      ON D.NumDomanda = CAST(vb.Num_domanda AS INT)
     AND ec.Cod_beneficio = vb.Cod_beneficio
     AND vb.Anno_accademico = ec.Anno_accademico
    WHERE ec.Anno_accademico = @AA
      AND UPPER(ec.Cod_beneficio) = 'PA'
),
PA_FLAG AS
(
    SELECT
        NumDomanda,
        CAST(CASE WHEN CodTipoEsito IN (1,2) THEN 1 ELSE 0 END AS BIT) AS HasAlloggio12
    FROM PA_LAST
    WHERE rn = 1
)
SELECT
    D.NumDomanda,
    D.CodFiscale,
    ISNULL(vv.StatusSedeAttuale,'') AS StatusSedeAttuale,
    ISNULL(f.ForcedStatus,'') AS ForcedStatus,
    ISNULL(i.AlwaysA, CAST(0 AS BIT)) AS AlwaysA,
    CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM COMUNI_INSEDE ci
            WHERE ci.riga_valida = 1
              AND ci.cod_comune = r.ComuneResidenza
              AND ci.cod_sede_studi = i.CodSedeStudi
              AND ISNULL(ci.cod_sede_distaccata,'00000') = ISNULL(i.CodSedeDistaccata,'00000')
        )
        THEN 1 ELSE 0 END
    AS BIT) AS InSedeList,
    CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM COMUNI_PENDOLARI cp
            WHERE cp.cod_sede_studi = i.CodSedeStudi
              AND cp.cod_comune = r.ComuneResidenza
              AND ISNULL(cp.cod_sede_distaccata,'00000') = ISNULL(i.CodSedeDistaccata,'00000')
        )
        THEN 1 ELSE 0 END
    AS BIT) AS PendolareList,
    CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM COMUNI_FUORISEDE cf
            WHERE cf.cod_comune = r.ComuneResidenza
              AND cf.cod_sede_studi = i.CodSedeStudi
              AND ISNULL(cf.cod_sede_distaccata,'00000') = ISNULL(i.CodSedeDistaccata,'00000')
        )
        THEN 1 ELSE 0 END
    AS BIT) AS FuoriSedeList,
    ISNULL(pf.HasAlloggio12, CAST(0 AS BIT)) AS HasAlloggio12,
    CAST(10 AS INT) AS MinMesiDomicilioFuoriSede
FROM D
LEFT JOIN VV vv ON vv.NumDomanda = D.NumDomanda
LEFT JOIN Forzature f ON f.CodFiscale = D.CodFiscale
LEFT JOIN ISCR1 i ON i.NumDomanda = D.NumDomanda
LEFT JOIN RES r ON r.NumDomanda = D.NumDomanda
LEFT JOIN PA_FLAG pf ON pf.NumDomanda = D.NumDomanda;";

        private const string DomicilioCorrentePopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT t.CodFiscale
    FROM {TEMP_TABLE} t
),
DOM_LRS AS
(
    SELECT
        UPPER(LTRIM(RTRIM(lrs.COD_FISCALE))) AS CodFiscale,
        ISNULL(lrs.COD_COMUNE,'') AS ComuneDomicilio,
        CAST(ISNULL(lrs.TITOLO_ONEROSO,0) AS BIT) AS TitoloOneroso,
        CAST(ISNULL(lrs.TIPO_CONTRATTO_TITOLO_ONEROSO,0) AS BIT) AS ContrattoEnte,
        ISNULL(lrs.TIPO_ENTE,'') AS TipoEnte,
        ISNULL(lrs.N_SERIE_CONTRATTO,'') AS SerieContratto,
        ISNULL(lrs.DATA_REG_CONTRATTO,'') AS DataRegistrazione,
        ISNULL(lrs.DATA_DECORRENZA,'') AS DataDecorrenza,
        ISNULL(lrs.DATA_SCADENZA,'') AS DataScadenza,
        ISNULL(lrs.DURATA_CONTRATTO,0) AS DurataContratto,
        CAST(ISNULL(lrs.PROROGA,0) AS BIT) AS Prorogato,
        ISNULL(lrs.DURATA_PROROGA,0) AS DurataProroga,
        ISNULL(lrs.ESTREMI_PROROGA,'') AS SerieProroga,
        ISNULL(lrs.DENOM_ENTE,'') AS DenomEnte,
        ISNULL(lrs.IMPORTO_RATA,0) AS ImportoRataEnte,
        ROW_NUMBER() OVER (PARTITION BY UPPER(LTRIM(RTRIM(lrs.COD_FISCALE))) ORDER BY lrs.DATA_VALIDITA DESC) AS rn
    FROM LUOGO_REPERIBILITA_STUDENTE lrs
    JOIN D ON D.CodFiscale = UPPER(LTRIM(RTRIM(lrs.COD_FISCALE)))
    WHERE lrs.ANNO_ACCADEMICO = @AA
      AND lrs.TIPO_LUOGO = 'DOM'
)
SELECT
    CodFiscale,
    ComuneDomicilio,
    TitoloOneroso,
    ContrattoEnte,
    TipoEnte,
    SerieContratto,
    DataRegistrazione,
    DataDecorrenza,
    DataScadenza,
    DurataContratto,
    Prorogato,
    DurataProroga,
    SerieProroga,
    DenomEnte,
    ImportoRataEnte
FROM DOM_LRS
WHERE rn = 1;";

        private const string IstanzaDomicilioApertaPopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT
        CAST(t.NumDomanda AS INT) AS NumDomanda,
        t.CodFiscale
    FROM {TEMP_TABLE} t
),
IST_OPEN AS
(
    SELECT
        UPPER(LTRIM(RTRIM(idg.Cod_fiscale))) AS CodFiscale,
        CAST(idg.Num_domanda AS INT) AS NumDomanda,
        CAST(idg.Num_istanza AS INT) AS NumIstanza,
        ISNULL(CONVERT(NVARCHAR(32), idg.Cod_tipo_istanza), '') AS CodTipoIstanza,
        ISNULL(icl.COD_COMUNE,'') AS ComuneDomicilio,
        CAST(ISNULL(icl.TITOLO_ONEROSO,0) AS BIT) AS TitoloOneroso,
        CAST(ISNULL(icl.TIPO_CONTRATTO_TITOLO_ONEROSO,0) AS BIT) AS ContrattoEnte,
        ISNULL(icl.TIPO_ENTE,'') AS TipoEnte,
        ISNULL(icl.N_SERIE_CONTRATTO,'') AS SerieContratto,
        ISNULL(icl.DATA_REG_CONTRATTO,'') AS DataRegistrazione,
        ISNULL(icl.DATA_DECORRENZA,'') AS DataDecorrenza,
        ISNULL(icl.DATA_SCADENZA,'') AS DataScadenza,
        ISNULL(icl.DURATA_CONTRATTO,0) AS DurataContratto,
        CAST(ISNULL(icl.PROROGA,0) AS BIT) AS Prorogato,
        ISNULL(icl.DURATA_PROROGA,0) AS DurataProroga,
        ISNULL(icl.ESTREMI_PROROGA,'') AS SerieProroga,
        ISNULL(icl.DENOM_ENTE,'') AS DenomEnte,
        ISNULL(icl.IMPORTO_RATA,0) AS ImportoRataEnte,
        ROW_NUMBER() OVER
        (
            PARTITION BY UPPER(LTRIM(RTRIM(idg.Cod_fiscale)))
            ORDER BY idg.Data_validita DESC, idg.Num_istanza DESC
        ) AS rn
    FROM Istanza_dati_generali idg
    JOIN D
      ON D.CodFiscale = UPPER(LTRIM(RTRIM(idg.Cod_fiscale)))
     AND D.NumDomanda = CAST(idg.Num_domanda AS INT)
    JOIN Istanza_status iis
      ON iis.Num_istanza = idg.Num_istanza
     AND iis.data_fine_validita IS NULL
    JOIN Istanza_Contratto_locazione icl
      ON icl.Num_istanza = idg.Num_istanza
     AND icl.data_fine_validita IS NULL
    WHERE idg.Anno_accademico = @AA
      AND idg.Data_fine_validita IS NULL
      AND idg.Esito_istanza IS NULL
)
SELECT
    CodFiscale,
    NumDomanda,
    NumIstanza,
    CodTipoIstanza,
    ComuneDomicilio,
    TitoloOneroso,
    ContrattoEnte,
    TipoEnte,
    SerieContratto,
    DataRegistrazione,
    DataDecorrenza,
    DataScadenza,
    DurataContratto,
    Prorogato,
    DurataProroga,
    SerieProroga,
    DenomEnte,
    ImportoRataEnte
FROM IST_OPEN
WHERE rn = 1;";

        private const string UltimaIstanzaChiusaDomicilioPopulationSql = @"
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

;WITH D AS
(
    SELECT
        CAST(t.NumDomanda AS INT) AS NumDomanda,
        t.CodFiscale
    FROM {TEMP_TABLE} t
),
IST_CLOSED_LAST AS
(
    SELECT
        UPPER(LTRIM(RTRIM(idg.Cod_fiscale))) AS CodFiscale,
        CAST(idg.Num_domanda AS INT) AS NumDomanda,
        CAST(idg.Num_istanza AS INT) AS NumIstanza,
        ISNULL(CONVERT(NVARCHAR(32), idg.Cod_tipo_istanza), '') AS CodTipoIstanza,
        ISNULL(CONVERT(NVARCHAR(64), idg.Esito_istanza), '') AS EsitoIstanza,
        ISNULL(CONVERT(NVARCHAR(256), iis.UTENTE_PRESA_CARICO), '') AS UtentePresaCarico,
        ROW_NUMBER() OVER
        (
            PARTITION BY UPPER(LTRIM(RTRIM(idg.Cod_fiscale)))
            ORDER BY idg.Data_validita DESC, idg.Num_istanza DESC
        ) AS rn
    FROM Istanza_dati_generali idg
    JOIN D
      ON D.CodFiscale = UPPER(LTRIM(RTRIM(idg.Cod_fiscale)))
     AND D.NumDomanda = CAST(idg.Num_domanda AS INT)
    JOIN Istanza_status iis
      ON iis.Num_istanza = idg.Num_istanza
     AND iis.data_fine_validita IS NOT NULL
    JOIN Istanza_Contratto_locazione icl
      ON icl.Num_istanza = idg.Num_istanza
    WHERE idg.Anno_accademico = @AA
      AND idg.Data_fine_validita IS NOT NULL
      AND idg.Esito_istanza IS NOT NULL
)
SELECT
    CodFiscale,
    NumDomanda,
    NumIstanza,
    CodTipoIstanza,
    EsitoIstanza,
    UtentePresaCarico
FROM IST_CLOSED_LAST
WHERE rn = 1;";

        private void LoadEsitoBs(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadEsitoBs", $"AA={context.AnnoAccademico}");
            string sql = EsitoBsPopulationSql.Replace("{TEMP_TABLE}", context.TempPipelineTable);

            using var cmd = new SqlCommand(sql, context.Connection) { CommandTimeout = 999999 };
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var key = CreateStudentKey(reader.SafeGetString("CodFiscale"), ReadDomandaAsString(reader, reader.GetOrdinal("NumDomanda")));
                if (!context.Students.TryGetValue(key, out var info))
                    continue;

                info.InformazioniEconomiche.Raw.CodTipoEsitoBS = reader.SafeGetInt("CodTipoEsitoBS");
                info.InformazioniEconomiche.Raw.ImportoAssegnato = Convert.ToDouble(GetDecimalOrZero(reader, reader.GetOrdinal("ImportoAssegnato")), CultureInfo.InvariantCulture);
            }
        }

        private void LoadStatusCompilazione(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadStatusCompilazione", $"AA={context.AnnoAccademico}");
            string sql = StatusCompilazionePopulationSql.Replace("{TEMP_TABLE}", context.TempPipelineTable);

            using var cmd = new SqlCommand(sql, context.Connection) { CommandTimeout = 999999 };
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var key = CreateStudentKey(reader.SafeGetString("CodFiscale"), ReadDomandaAsString(reader, reader.GetOrdinal("NumDomanda")));
                if (!context.Students.TryGetValue(key, out var info))
                    continue;

                info.StatusCompilazione = reader.SafeGetInt("StatusCompilazione");
            }
        }

        private void LoadDatiPersonali(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadDatiPersonali", $"AA={context.AnnoAccademico}");
            string sql = DatiPersonaliPopulationSql.Replace("{TEMP_TABLE}", context.TempPipelineTable);

            using var cmd = new SqlCommand(sql, context.Connection) { CommandTimeout = 999999 };
            cmd.Parameters.Add("@AA", SqlDbType.Char, 8).Value = context.AnnoAccademico;

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var key = CreateStudentKey(reader.SafeGetString("CodFiscale"), ReadDomandaAsString(reader, reader.GetOrdinal("NumDomanda")));
                if (!context.Students.TryGetValue(key, out var info))
                    continue;

                info.InformazioniPersonali.Sesso = reader.SafeGetString("StudenteSesso").Trim().ToUpperInvariant();
                info.InformazioniPersonali.Rifugiato = reader.SafeGetBool("RifugiatoPolitico");
                info.InformazioniPersonali.Disabile = reader.SafeGetBool("Invalido");
            }
        }

        private void LoadMonetizzazioneMensa(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadMonetizzazioneMensa", $"AA={context.AnnoAccademico}");
            string sql = MonetizzazionePopulationSql.Replace("{TEMP_TABLE}", context.TempPipelineTable);

            using var cmd = new SqlCommand(sql, context.Connection) { CommandTimeout = 999999 };
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var key = CreateStudentKey(reader.SafeGetString("CodFiscale"), ReadDomandaAsString(reader, reader.GetOrdinal("NumDomanda")));
                if (!context.Students.TryGetValue(key, out var info))
                    continue;

                info.InformazioniBeneficio.ConcessaMonetizzazioneMensa = reader.SafeGetBool("ConcessaMonetizzazione");
            }
        }

        private void LoadNucleoFamiliarePerStatusSede(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadNucleoFamiliarePerStatusSede", $"AA={context.AnnoAccademico}");
            string sql = NucleoFamiliareStatusPopulationSql.Replace("{TEMP_TABLE}", context.TempPipelineTable);

            using var cmd = new SqlCommand(sql, context.Connection) { CommandTimeout = 999999 };
            cmd.Parameters.Add("@AA", SqlDbType.Char, 8).Value = context.AnnoAccademico;

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var key = CreateStudentKey(reader.SafeGetString("CodFiscale"), ReadDomandaAsString(reader, reader.GetOrdinal("NumDomanda")));
                if (!context.Students.TryGetValue(key, out var info))
                    continue;

                info.SetNucleoFamiliare(reader.SafeGetInt("NumComponenti"), reader.SafeGetInt("NumConvEstero"));
            }
        }

        private void LoadResidenza(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadResidenza", $"AA={context.AnnoAccademico}");
            string sql = ResidenzaPopulationSql.Replace("{TEMP_TABLE}", context.TempPipelineTable);

            using var cmd = new SqlCommand(sql, context.Connection) { CommandTimeout = 999999 };
            cmd.Parameters.Add("@AA", SqlDbType.Char, 8).Value = context.AnnoAccademico;

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var key = CreateStudentKey(reader.SafeGetString("CodFiscale"), ReadDomandaAsString(reader, reader.GetOrdinal("NumDomanda")));
                if (!context.Students.TryGetValue(key, out var info))
                    continue;

                string comuneResidenza = reader.SafeGetString("ComuneResidenza").Trim();
                string provinciaResidenza = reader.SafeGetString("ProvinciaResidenza").Trim().ToUpperInvariant();
                info.SetResidenza(string.Empty, comuneResidenza, provinciaResidenza, string.Empty, comuneResidenza);
            }
        }

        private void LoadStatusSedeBase(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadStatusSedeBase", $"AA={context.AnnoAccademico}");
            string sql = StatusSedeBasePopulationSql.Replace("{TEMP_TABLE}", context.TempPipelineTable);

            using var cmd = new SqlCommand(sql, context.Connection) { CommandTimeout = 999999 };
            cmd.Parameters.Add("@AA", SqlDbType.Char, 8).Value = context.AnnoAccademico;

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var key = CreateStudentKey(reader.SafeGetString("CodFiscale"), ReadDomandaAsString(reader, reader.GetOrdinal("NumDomanda")));
                if (!context.Students.TryGetValue(key, out var info))
                    continue;

                info.InformazioniSede.StatusSede = reader.SafeGetString("StatusSedeAttuale").Trim().ToUpperInvariant();
                info.InformazioniSede.ForzaturaStatusSede = reader.SafeGetString("ForcedStatus").Trim().ToUpperInvariant();
                info.InformazioniSede.AlwaysA = reader.SafeGetBool("AlwaysA");
                info.InformazioniSede.InSedeList = reader.SafeGetBool("InSedeList");
                info.InformazioniSede.PendolareList = reader.SafeGetBool("PendolareList");
                info.InformazioniSede.FuoriSedeList = reader.SafeGetBool("FuoriSedeList");
                info.InformazioniSede.HasAlloggio12 = reader.SafeGetBool("HasAlloggio12");
                info.InformazioniSede.MinMesiDomicilioFuoriSede = reader.SafeGetInt("MinMesiDomicilioFuoriSede");
            }
        }

        private void LoadDomicilioCorrente(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadDomicilioCorrente", $"AA={context.AnnoAccademico}");
            string sql = DomicilioCorrentePopulationSql.Replace("{TEMP_TABLE}", context.TempPipelineTable);

            var studentsByCf = new Dictionary<string, List<StudenteInfo>>(StringComparer.OrdinalIgnoreCase);
            foreach (var pair in context.Students)
            {
                if (!studentsByCf.TryGetValue(pair.Key.CodFiscale, out var bucket))
                {
                    bucket = new List<StudenteInfo>();
                    studentsByCf[pair.Key.CodFiscale] = bucket;
                }

                bucket.Add(pair.Value);
            }

            using var cmd = new SqlCommand(sql, context.Connection) { CommandTimeout = 999999 };
            cmd.Parameters.Add("@AA", SqlDbType.Char, 8).Value = context.AnnoAccademico;

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string cf = NormalizeCf(reader.SafeGetString("CodFiscale"));
                if (!studentsByCf.TryGetValue(cf, out var matches) || matches.Count == 0)
                    continue;

                string comuneDomicilio = reader.SafeGetString("ComuneDomicilio").Trim();
                bool titoloOneroso = reader.SafeGetBool("TitoloOneroso");
                bool contrattoEnte = reader.SafeGetBool("ContrattoEnte");
                string tipoEnte = reader.SafeGetString("TipoEnte").Trim().ToUpperInvariant();
                string serieContratto = reader.SafeGetString("SerieContratto").Trim();
                DateTime dataRegistrazione = reader.SafeGetDateTime("DataRegistrazione");
                DateTime dataDecorrenza = reader.SafeGetDateTime("DataDecorrenza");
                DateTime dataScadenza = reader.SafeGetDateTime("DataScadenza");
                int durataContratto = reader.SafeGetInt("DurataContratto");
                bool prorogato = reader.SafeGetBool("Prorogato");
                int durataProroga = reader.SafeGetInt("DurataProroga");
                string serieProroga = reader.SafeGetString("SerieProroga").Trim();
                string denomEnte = reader.SafeGetString("DenomEnte").Trim();
                double importoRataEnte = reader.SafeGetDouble("ImportoRataEnte");

                foreach (var info in matches)
                {
                    info.InformazioniSede.Domicilio.codComuneDomicilio = comuneDomicilio;
                    info.InformazioniSede.Domicilio.titoloOneroso = titoloOneroso;
                    info.InformazioniSede.Domicilio.contrEnte = contrattoEnte;
                    info.InformazioniSede.Domicilio.TipoEnte = tipoEnte;
                    info.InformazioniSede.Domicilio.codiceSerieLocazione = serieContratto;
                    info.InformazioniSede.Domicilio.dataRegistrazioneLocazione = dataRegistrazione;
                    info.InformazioniSede.Domicilio.dataDecorrenzaLocazione = dataDecorrenza;
                    info.InformazioniSede.Domicilio.dataScadenzaLocazione = dataScadenza;
                    info.InformazioniSede.Domicilio.durataMesiLocazione = durataContratto;
                    info.InformazioniSede.Domicilio.prorogatoLocazione = prorogato;
                    info.InformazioniSede.Domicilio.durataMesiProrogaLocazione = durataProroga;
                    info.InformazioniSede.Domicilio.codiceSerieProrogaLocazione = serieProroga;
                    info.InformazioniSede.ContrattoEnte = contrattoEnte;
                    info.InformazioniSede.Domicilio.denominazioneIstituto = denomEnte;
                    info.InformazioniSede.Domicilio.importoMensileRataIstituto = importoRataEnte;
                }
            }
        }

        private void LoadIstanzaDomicilioAperta(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadIstanzaDomicilioAperta", $"AA={context.AnnoAccademico}");
            string sql = IstanzaDomicilioApertaPopulationSql.Replace("{TEMP_TABLE}", context.TempPipelineTable);

            using var cmd = new SqlCommand(sql, context.Connection) { CommandTimeout = 999999 };
            cmd.Parameters.Add("@AA", SqlDbType.Char, 8).Value = context.AnnoAccademico;

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var key = CreateStudentKey(reader.SafeGetString("CodFiscale"), ReadDomandaAsString(reader, reader.GetOrdinal("NumDomanda")));
                if (!context.Students.TryGetValue(key, out var info))
                    continue;

                info.InformazioniSede.HasIstanzaDomicilio = true;
                info.InformazioniSede.CodTipoIstanzaDomicilio = reader.SafeGetString("CodTipoIstanza").Trim();
                info.InformazioniSede.NumIstanzaDomicilio = reader.SafeGetInt("NumIstanza");
                info.InformazioniSede.IstanzaDomicilio = new DomicilioSnapshot
                {
                    ComuneDomicilio = reader.SafeGetString("ComuneDomicilio").Trim(),
                    TitoloOneroso = reader.SafeGetBool("TitoloOneroso"),
                    ContrattoEnte = reader.SafeGetBool("ContrattoEnte"),
                    TipoEnte = reader.SafeGetString("TipoEnte").Trim().ToUpperInvariant(),
                    SerieContratto = reader.SafeGetString("SerieContratto").Trim(),
                    DataRegistrazione = reader.SafeGetDateTime("DataRegistrazione"),
                    DataDecorrenza = reader.SafeGetDateTime("DataDecorrenza"),
                    DataScadenza = reader.SafeGetDateTime("DataScadenza"),
                    DurataContratto = reader.SafeGetInt("DurataContratto"),
                    Prorogato = reader.SafeGetBool("Prorogato"),
                    DurataProroga = reader.SafeGetInt("DurataProroga"),
                    SerieProroga = reader.SafeGetString("SerieProroga").Trim(),
                    DenomEnte = reader.SafeGetString("DenomEnte").Trim(),
                    ImportoRataEnte = reader.SafeGetDouble("ImportoRataEnte")
                };
            }
        }

        private void LoadUltimaIstanzaChiusaDomicilio(VerificaPipelineContext context)
        {
            using var scope = MeasureCollectionStep("VerificaRaccoltaDati.LoadUltimaIstanzaChiusaDomicilio", $"AA={context.AnnoAccademico}");
            using var cmd = CreatePopulationCommand(context, UltimaIstanzaChiusaDomicilioPopulationSql, addAa: true);

            ReadAndMergeByKey(cmd, (info, reader) =>
            {
                info.InformazioniSede.HasUltimaIstanzaChiusaDomicilio = true;
                info.InformazioniSede.CodTipoUltimaIstanzaChiusaDomicilio = reader.SafeGetString("CodTipoIstanza").Trim();
                info.InformazioniSede.NumUltimaIstanzaChiusaDomicilio = reader.SafeGetInt("NumIstanza");
                info.InformazioniSede.EsitoUltimaIstanzaChiusaDomicilio = reader.SafeGetString("EsitoIstanza").Trim();
                info.InformazioniSede.UtentePresaCaricoUltimaIstanzaChiusaDomicilio = reader.SafeGetString("UtentePresaCarico").Trim();
            });
        }
    }
}
