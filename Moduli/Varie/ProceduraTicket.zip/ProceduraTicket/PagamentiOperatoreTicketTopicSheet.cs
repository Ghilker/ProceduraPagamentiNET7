using System;
using System.Collections.Generic;
using System.Data;

namespace ProcedureNet7
{
    internal sealed class PagamentiOperatoreTicketTopicSheet : TicketTopicSheetBase
    {
        public override int Order => 30;
        public override string SheetName => "Pagamenti";

        protected override bool Matches(DataRow row) =>
            PrimaryOrSecondaryIs(
                row,
                PrimaryTopic.PAGAMENTI_E_TASSE,
                Topic.PAGAMENTI,
                Topic.TASSE,
                Topic.RIMBORSO_TASSA,
                Topic.DEBITORIA,
                Topic.SALDO);

        public override DataTable BuildSheet(TicketTopicSheetContext context)
        {
            Logger.LogInfo(null, "Avvio costruzione foglio Pagamenti a riga unica per ticket");
            DataTable result = base.BuildSheet(context);

            AddOfficeColumn(result, "AA_RECORD_OPERATIVO");
            AddOfficeColumn(result, "CRITERIO_SELEZIONE_RECORD");
            AddOfficeColumn(result, "NUM_DOMANDA");
            AddOfficeColumn(result, "STATUS_COMPILAZIONE", typeof(int));
            AddOfficeColumn(result, "ESITO_BS");
            AddOfficeColumn(result, "IMPORTO_ASSEGNATO", typeof(decimal));
            AddOfficeColumn(result, "IMPORTO_SPECIFICHE_IMPEGNI", typeof(decimal));
            AddOfficeColumn(result, "IMPORTO_PAGATO_BS_VALIDO", typeof(decimal));
            AddOfficeColumn(result, "IMPORTO_PRIMA_RATA_BS", typeof(decimal));
            AddOfficeColumn(result, "IMPORTO_SALDO_BS", typeof(decimal));
            AddOfficeColumn(result, "IMPORTO_INTEGRAZIONI_BS", typeof(decimal));
            AddOfficeColumn(result, "IMPORTO_PAGAMENTI_BS_STORNATI", typeof(decimal));
            AddOfficeColumn(result, "CODICI_PAGAMENTI_BS_STORNATI");
            AddOfficeColumn(result, "MANDATI_BS_STORNATI");
            AddOfficeColumn(result, "IMPORTO_BS_CODICI_NON_CLASSIFICATI", typeof(decimal));
            AddOfficeColumn(result, "CODICI_BS_NON_CLASSIFICATI");
            AddOfficeColumn(result, "IMPORTO_REVERSALI_BS", typeof(decimal));
            AddOfficeColumn(result, "IMPORTO_DETRAZIONI", typeof(decimal));
            AddOfficeColumn(result, "RESIDUO_BS_STIMATO", typeof(decimal));
            AddOfficeColumn(result, "TIPI_PAGAMENTO_BS");
            AddOfficeColumn(result, "MANDATI_BS");
            AddOfficeColumn(result, "MANDATI_PRIMA_RATA_BS");
            AddOfficeColumn(result, "MANDATI_SALDO_BS");
            AddOfficeColumn(result, "MANDATI_INTEGRAZIONI_BS");
            AddOfficeColumn(result, "MODALITA_PAGAMENTO");
            AddOfficeColumn(result, "IBAN");
            AddOfficeColumn(result, "SWIFT");
            AddOfficeColumn(result, "BONIFICO_ESTERO");
            AddOfficeColumn(result, "BLOCCHI");
            AddOfficeColumn(result, "INDICAZIONE_OPERATORE");

            foreach (DataRow row in result.Rows)
            {
                TicketRecordSelection selection = ResolveOperationalSelection(context, row);
                TicketOfficeRecord? record = selection.Record;
                row["CRITERIO_SELEZIONE_RECORD"] = selection.Criterion;
                row["AA_RECORD_OPERATIVO"] = record == null
                    ? string.Empty
                    : FormatAcademicYear(record.AcademicYear);

                if (record == null)
                {
                    row["INDICAZIONE_OPERATORE"] =
                        "Nessuna domanda trovata: verificare codice fiscale e identità dello studente.";
                    continue;
                }

                decimal assignedAmount = record.SpecificheAmount > 0m
                    ? record.SpecificheAmount
                    : record.BenefitAmount;
                decimal firstInstallment =
                    record.BsFirstInstallmentOriginalAmount +
                    record.BsFirstInstallmentReissueAmount;
                decimal balance =
                    record.BsBalanceOriginalAmount +
                    record.BsBalanceReissueAmount;
                decimal integration =
                    record.BsIntegrationFirstInstallmentOriginalAmount +
                    record.BsIntegrationFirstInstallmentReissueAmount +
                    record.BsIntegrationBalanceOriginalAmount +
                    record.BsIntegrationBalanceReissueAmount;
                decimal residual = Math.Max(
                    0m,
                    assignedAmount -
                    record.BsPaidAmount +
                    record.BsReversalAmount -
                    record.DeductionAmount);

                row["AA_RECORD_OPERATIVO"] = FormatAcademicYear(record.AcademicYear);
                row["NUM_DOMANDA"] = record.ApplicationNumber;
                row["STATUS_COMPILAZIONE"] = record.CompilationStatus;
                row["ESITO_BS"] = FormatOutcome(record.BsOutcome);
                row["IMPORTO_ASSEGNATO"] = record.BenefitAmount;
                row["IMPORTO_SPECIFICHE_IMPEGNI"] = record.SpecificheAmount;
                row["IMPORTO_PAGATO_BS_VALIDO"] = record.BsPaidAmount;
                row["IMPORTO_PRIMA_RATA_BS"] = firstInstallment;
                row["IMPORTO_SALDO_BS"] = balance;
                row["IMPORTO_INTEGRAZIONI_BS"] = integration;
                row["IMPORTO_PAGAMENTI_BS_STORNATI"] = record.BsStornedAmount;
                row["CODICI_PAGAMENTI_BS_STORNATI"] = record.BsStornedPaymentTypes;
                row["MANDATI_BS_STORNATI"] = record.BsStornedMandates;
                row["IMPORTO_BS_CODICI_NON_CLASSIFICATI"] = record.BsUnclassifiedAmount;
                row["CODICI_BS_NON_CLASSIFICATI"] = record.BsUnclassifiedPaymentTypes;
                row["IMPORTO_REVERSALI_BS"] = record.BsReversalAmount;
                row["IMPORTO_DETRAZIONI"] = record.DeductionAmount;
                row["RESIDUO_BS_STIMATO"] = residual;
                row["TIPI_PAGAMENTO_BS"] = record.BsPaymentTypes;
                row["MANDATI_BS"] = record.BsMandates;
                row["MANDATI_PRIMA_RATA_BS"] = record.BsFirstInstallmentMandates;
                row["MANDATI_SALDO_BS"] = record.BsBalanceMandates;
                row["MANDATI_INTEGRAZIONI_BS"] = record.BsIntegrationMandates;
                row["MODALITA_PAGAMENTO"] = record.PaymentMethod;
                row["IBAN"] = record.Iban;
                row["SWIFT"] = record.Swift;
                row["BONIFICO_ESTERO"] = record.ForeignTransfer ? "SI" : "";
                row["BLOCCHI"] = record.Blocks;
                row["INDICAZIONE_OPERATORE"] = Evaluate(record, residual);
            }

            Logger.LogInfo(
                null,
                $"Foglio Pagamenti completato. Ticket: {result.Rows.Count}; righe: {result.Rows.Count}");
            return result;
        }

        private static string Evaluate(
            TicketOfficeRecord record,
            decimal residual)
        {
            var indications = new List<string>();

            if (record.CompilationStatus > 0 && record.CompilationStatus < 90)
                indications.Add("domanda non trasmessa/completa");
            if (record.BsOutcome == "0")
                indications.Add("studente escluso dalla borsa");
            if (string.IsNullOrWhiteSpace(record.BsOutcome))
                indications.Add("esito BS assente");
            if (!string.IsNullOrWhiteSpace(record.Blocks))
                indications.Add("blocco potenzialmente rilevante per il pagamento BS");
            if (string.IsNullOrWhiteSpace(record.Iban))
                indications.Add("IBAN assente");
            if (record.HasBsStornedPayments)
                indications.Add($"pagamenti BS stornati/non accreditati {record.BsStornedAmount:0.00}");
            if (record.HasUnclassifiedBsPaymentCodes)
                indications.Add($"codici BS non classificati: {record.BsUnclassifiedPaymentTypes}");
            if (record.BenefitAmount > 0m &&
                record.SpecificheAmount > 0m &&
                Math.Abs(record.BenefitAmount - record.SpecificheAmount) >= 0.01m)
            {
                indications.Add("importo esito diverso dalle specifiche impegni");
            }
            if (record.BenefitAmount > 0m && residual <= 0.01m)
                indications.Add("pagamento BS completato");
            else if (record.BsPaidAmount > 0m)
                indications.Add($"pagamento BS parziale; residuo BS stimato {residual:0.00}");
            else if (record.BsOutcome == "2")
                indications.Add("vincitore senza pagamenti BS registrati");

            return indications.Count == 0
                ? "Verificare la richiesta rispetto ai dati contabili riportati."
                : string.Join("; ", indications);
        }

        internal static string FormatOutcome(string outcome) => outcome switch
        {
            "0" => "Escluso",
            "1" => "Idoneo",
            "2" => "Vincitore",
            _ => outcome
        };
    }
}
