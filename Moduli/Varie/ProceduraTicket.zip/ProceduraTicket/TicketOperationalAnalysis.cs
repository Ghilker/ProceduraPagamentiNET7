using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace ProcedureNet7
{
    internal enum TicketIntent
    {
        INFORMAZIONE,
        STATO_PRATICA,
        SOLLECITO,
        CONTESTAZIONE,
        ERRORE_TECNICO,
        INVIO_DOCUMENTO,
        AGGIORNAMENTO_DATI,
        RINUNCIA_O_RECESSO,
        PRE_DOMANDA,
        ALTRO_DA_VERIFICARE
    }

    internal enum ApplicationState
    {
        SCONOSCIUTO,
        INCOMPLETA_O_NON_TRASMESSA,
        TRASMESSA_O_COMPLETA
    }

    internal enum PaymentRequestKind
    {
        GENERICO,
        PRIMA_RATA,
        SALDO,
        INTEGRAZIONE
    }

    internal enum BlockCategory
    {
        DOCUMENTI_E_PERMESSI,
        REDDITI_E_ISEE,
        ISCRIZIONE_E_CARRIERA,
        PAGAMENTI_E_TASSE,
        ALLOGGIO_E_DOMICILIO,
        PORTALE_E_TECNICO,
        ALTRO
    }

    internal sealed class TicketIntentAssessment
    {
        public TicketIntent Intent { get; init; }
        public string Confidence { get; init; } = "BASSA";
        public string Signals { get; init; } = string.Empty;
    }

    internal sealed class TicketResolutionScope
    {
        public bool ScholarshipPayments { get; init; }
        public bool ResidencePermitDocuments { get; init; }
        public bool ApplicationBlocks { get; init; }
        public string Signals { get; init; } = string.Empty;

        public bool HasConditions =>
            ScholarshipPayments ||
            ResidencePermitDocuments ||
            ApplicationBlocks;
    }

    internal sealed class BlockAssessment
    {
        public string RelevantBlocks { get; init; } = string.Empty;
        public string NonRelevantBlocks { get; init; } = string.Empty;
        public IReadOnlyCollection<BlockCategory> RelevantCategories { get; init; } = Array.Empty<BlockCategory>();
        public bool HasRelevantBlocks => RelevantCategories.Count > 0;
    }

    internal static class TicketOperationalAnalysis
    {
        private static readonly string[] ContestationTokens =
        {
            "contest", "ricorso", "errato", "sbagliat", "non corretto", "ingiusto", "reclamo",
            "differenza", "importo inferiore", "meno del previsto", "pagamento in eccesso",
            "trattenuta", "rimborso", "restituzione", "riaccredito", "stornato"
        };

        private static readonly string[] TechnicalTokens =
        {
            "errore", "accesso", "login", "password", "portale", "schermata", "non riesco", "bloccato il sito"
        };

        private static readonly string[] DocumentTokens =
        {
            "allego", "allegato", "caricato", "caricare", "upload", "inviato", "inviare documento", "documentazione", "documento", "documenti"
        };

        private static readonly string[] UpdateTokens =
        {
            "aggiorn", "modific", "cambiare", "cambio", "variazione", "nuovo iban"
        };

        private static readonly string[] WithdrawalTokens =
        {
            "rinunci", "rinuncia", "recesso", "reced", "check out", "check-out", "disdet", "cessaz", "restituzione chiavi"
        };

        private static readonly string[] SolicitationTokens =
        {
            "sollecito", "non ricevuto", "non accreditato", "ritardo", "attendo", "quando verrà", "quando sara", "quando sarà"
        };

        private static readonly string[] StatusTokens =
        {
            "stato", "esito", "graduatoria", "risultato", "pratica", "domanda"
        };

        private static readonly string[] PreApplicationTokens =
        {
            "requisiti", "come fare", "come si fa", "posso presentare", "posso fare domanda", "bando", "informazioni generali"
        };

        private static readonly string[] InformationTokens =
        {
            "informazione", "informazioni", "chiarimento", "vorrei sapere", "potrei sapere", "dubbio"
        };

        // Questi segnali identificano richieste informative: non devono trasformarsi in
        // una proposta di chiusura soltanto perché esiste un dato operativo favorevole.
        private static readonly string[] InformationalOnlyTokens =
        {
            "quanto", "quali sono", "come funziona", "come fare", "come si fa",
            "quali documenti", "quale documento", "devo caricare", "devo inserire",
            "dove caricare", "come caricare", "come inserire", "what documents",
            "how to upload", "where to upload",
            "requisiti", "informazioni", "chiarimento", "vorrei sapere", "potrei sapere", "dubbio"
        };

        private static readonly string[] BlockReferenceTokens =
        {
            "blocco", "blocchi", "blocc", "sblocc", "rimozione blocco", "rimuovere il blocco",
            "sospes", "sospension", "fermo pratica", "pratica ferma",
            "block", "blocked", "unblock"
        };

        private static readonly string[] BlockRemovalTokens =
        {
            "rimozione blocco", "rimuovere il blocco", "rimuovere blocco", "togliere il blocco",
            "togliere blocco", "sblocco", "sbloccare", "domanda bloccata", "blocco domanda",
            "remove the block", "block has not", "remaining block", "blocked application"
        };

        // Segnali volutamente più stretti per l'autochiusura. Espressioni generiche come
        // "sbloccare la posizione" o "sblocco" non identificano con sufficiente certezza un
        // blocco amministrativo della domanda e restano quindi fuori dal perimetro P1.
        private static readonly string[] AdministrativeBlockRemovalTokens =
        {
            "rimozione blocco", "rimuovere il blocco", "rimuovere blocco", "togliere il blocco",
            "togliere blocco", "domanda bloccata", "blocco domanda", "sblocco domanda",
            "sbloccare domanda", "sblocco pratica", "sbloccare pratica", "blocchi pratica",
            "remove the block", "blocked application", "application block"
        };

        private static readonly string[] ApplicationBlockContextTokens =
        {
            "domanda", "pratica", "documentazione definitiva", "titolo di soggiorno",
            "permesso", "documenti", "application", "documents", "residence permit"
        };

        // Un errore, un accesso negato o una schermata bloccata è un problema tecnico anche
        // quando nel testo compare la parola "blocco". Non deve diventare una chiusura P1.
        private static readonly string[] TechnicalBlockTokens =
        {
            "errore", "error", "accesso", "login", "password", "schermata", "sistema",
            "piattaforma", "portale", "caricamento infinito", "bug", "non riesco"
        };

        private static readonly string[] FinancialInstrumentBlockTokens =
        {
            "carta bloccata", "conto bloccato", "banca ha bloccato", "iban bloccato",
            "pagamento bloccato dalla banca", "sito bloccato", "portale bloccato",
            "bank blocked", "card blocked", "account blocked", "website blocked"
        };

        private static readonly string[] ResidencePermitTokens =
        {
            "permesso di soggiorno", "permesso soggiorno", "permesso", "documenti del permesso",
            "documenti permesso", "allegati permesso", "ricevuta della questura",
            "ricevuta questura", "kit postale", "questura", "titolo di soggiorno", "residence permit"
        };

        // Per il permesso l'esistenza di un documento in stato 05 non basta: il ticket deve
        // segnalare che un documento già inviato/caricato o il relativo blocco è ancora aperto.
        private static readonly string[] ResidencePermitStateRequestTokens =
        {
            "ho caricato", "ho inserito", "ho inviato", "ho allegato", "gia caricato",
            "gia inserito", "risulta gia caricato", "risulta gia inserito", "documento caricato",
            "documenti caricati", "documenti inseriti", "documenti inviati", "caricando",
            "uploaded", "already uploaded", "submitted", "already submitted", "stato 05",
            "verificare il documento", "titolo di soggiorno caricato", "rimozione del blocco",
            "rimuovere il blocco", "blocco sul pagamento"
        };

        private static readonly string[] ScholarshipPaymentStrongTokens =
        {
            "pagamento borsa", "pagamento della borsa", "pagamento del beneficio",
            "accredito borsa", "accredito della borsa", "erogazione borsa",
            "erogazione della borsa", "liquidazione borsa", "mandato di pagamento",
            "bonifico della borsa", "saldo della borsa", "saldo borsa",
            "rata della borsa", "riaccredito della borsa",
            "scholarship payment", "scholarship bank transfer"
        };

        private static readonly string[] ScholarshipPaymentActionTokens =
        {
            "accredit", "erog", "liquid", "mandato", "bonifico", "rata", "saldo",
            "pagamento non ricevuto", "non ho ricevuto", "quando arriva il pagamento",
            "quando verra pagata", "quando sara pagata",
            "installment", "payment not received", "when will"
        };

        private static readonly string[] ScholarshipInstallmentTokens =
        {
            "prima rata", "seconda rata", "saldo", "rate rimanenti", "rata rimanente",
            "first installment", "second installment", "balance"
        };

        private static readonly string[] IncomingPaymentTokens =
        {
            "non ricevut", "non ho ricevuto", "non ho ricevuta", "not received",
            "non accredit", "mancato accredito", "quando arriva", "attendo", "in attesa", "ritardo",
            "quando ricevero", "quando potro ricevere", "banca ha bloccato il pagamento",
            "restituito l'importo al mittente", "riaccredito", "pagamento in entrata"
        };

        // Richieste di ricevuta, attestazione o certificato non chiedono se il pagamento sia
        // avvenuto: richiedono un documento. Non sono chiudibili come pagamento già effettuato.
        private static readonly string[] PaymentEvidenceRequestTokens =
        {
            "ricevuta di pagamento", "attestazione", "certificato", "dichiarazione",
            "documento ufficiale", "prova dei mezzi", "ricevuta del pagamento"
        };

        private static readonly string[] ScholarshipContextTokens =
        {
            "borsa", "beneficio", "contributo", "scholarship", "grant"
        };

        private static readonly string[] StudentPaidTaxTokens =
        {
            "tassa regionale", "tassa universitaria", "tassa di iscrizione",
            "retta universitaria", "pagopa", "iuv", "ricevuta della tassa"
        };

        private static readonly string[] FirstInstallmentTokens =
        {
            "prima rata", "1 rata", "1a rata", "primo pagamento", "acconto"
        };

        private static readonly string[] BalanceTokens =
        {
            "saldo", "seconda rata", "2 rata", "2a rata", "rata finale"
        };

        private static readonly string[] IntegrationTokens =
        {
            "integrazione", "integrazione prima rata", "integrazione saldo"
        };

        public static TicketIntentAssessment AnalyzeIntent(string subject, string message, string topicCode)
        {
            string text = Normalize(subject + " " + message);
            if (string.IsNullOrWhiteSpace(text))
                return NewAssessment(TicketIntent.ALTRO_DA_VERIFICARE, "BASSA", "testo assente");

            if (ContainsAny(text, ContestationTokens))
                return NewAssessment(TicketIntent.CONTESTAZIONE, "ALTA", "contestazione/importo o esito contestato");
            if (ContainsAny(text, WithdrawalTokens))
                return NewAssessment(TicketIntent.RINUNCIA_O_RECESSO, "ALTA", "rinuncia/recesso/check-out");

            // Il solo topic PORTALE_E_ACCESSO non dimostra un errore tecnico. Un ticket può
            // citare il portale mentre richiede la rimozione di un blocco amministrativo.
            if (ContainsAny(text, TechnicalTokens) && !ContainsAny(text, BlockRemovalTokens))
                return NewAssessment(TicketIntent.ERRORE_TECNICO, "ALTA", "errore tecnico/accesso al portale");
            if (ContainsAny(text, DocumentTokens))
                return NewAssessment(TicketIntent.INVIO_DOCUMENTO, "MEDIA", "invio o caricamento documenti");
            if (ContainsAny(text, UpdateTokens) ||
                string.Equals(topicCode, "IBAN", StringComparison.OrdinalIgnoreCase))
                return NewAssessment(TicketIntent.AGGIORNAMENTO_DATI, "MEDIA", "aggiornamento dati o coordinate di pagamento");
            if (ContainsAny(text, SolicitationTokens))
                return NewAssessment(TicketIntent.SOLLECITO, "MEDIA", "sollecito o mancata ricezione");
            if (ContainsAny(text, PreApplicationTokens))
                return NewAssessment(TicketIntent.PRE_DOMANDA, "MEDIA", "richiesta generale o pre-domanda");
            if (ContainsAny(text, StatusTokens))
                return NewAssessment(TicketIntent.STATO_PRATICA, "MEDIA", "richiesta di stato o esito");
            if (ContainsAny(text, InformationTokens))
                return NewAssessment(TicketIntent.INFORMAZIONE, "MEDIA", "richiesta informativa");

            return NewAssessment(TicketIntent.ALTRO_DA_VERIFICARE, "BASSA", "nessun segnale di intento univoco");
        }

        public static bool TicketMentionsBlocks(string subject, string message)
        {
            return ContainsAny(Normalize(subject + " " + message), BlockReferenceTokens);
        }

        /// <summary>
        /// La selezione di un solo AA estratto non è sufficiente quando il testo cita più anni:
        /// in quel caso non è possibile attribuire automaticamente la condizione risolta al
        /// corretto anno senza una lettura operatore.
        /// </summary>
        public static bool HasMultipleAcademicYears(string subject, string message)
        {
            string text = Normalize(subject + " " + message);
            var years = new HashSet<string>(StringComparer.Ordinal);
            for (int index = 0; index <= text.Length - 9; index++)
            {
                if (!char.IsDigit(text[index]) || !char.IsDigit(text[index + 1]) ||
                    !char.IsDigit(text[index + 2]) || !char.IsDigit(text[index + 3]) ||
                    (text[index + 4] != '/' && text[index + 4] != '-') ||
                    !char.IsDigit(text[index + 5]) || !char.IsDigit(text[index + 6]) ||
                    !char.IsDigit(text[index + 7]) || !char.IsDigit(text[index + 8]))
                    continue;

                string start = text.Substring(index, 4);
                string end = text.Substring(index + 5, 4);
                if (int.TryParse(start, out int startYear) &&
                    int.TryParse(end, out int endYear) &&
                    endYear == startYear + 1)
                    years.Add($"{startYear:D4}/{endYear:D4}");
            }
            return years.Count > 1;
        }

        public static bool TicketRequestsBlockRemoval(string subject, string message)
        {
            return AnalyzeResolutionScope(subject, message).ApplicationBlocks;
        }

        public static TicketResolutionScope AnalyzeResolutionScope(
            string subject,
            string message,
            string primaryTopicCode = "",
            string secondaryTopicCode = "",
            bool referredToBlocks = false)
        {
            string text = Normalize(subject + " " + message);
            if (string.IsNullOrWhiteSpace(text))
                return new TicketResolutionScope();

            bool primaryPayments = string.Equals(
                primaryTopicCode,
                "PAGAMENTI_E_TASSE",
                StringComparison.OrdinalIgnoreCase);
            bool primaryBenefits = string.Equals(
                primaryTopicCode,
                "BENEFICI_E_IMPORTI",
                StringComparison.OrdinalIgnoreCase);
            bool primaryDocuments = string.Equals(
                primaryTopicCode,
                "DOCUMENTI_E_PERMESSI",
                StringComparison.OrdinalIgnoreCase);
            bool secondaryPayments = TopicContainsAny(
                secondaryTopicCode,
                "PAGAMENTI",
                "SALDO");
            bool secondaryPermit = TopicContainsAny(secondaryTopicCode, "PERMESSO");

            bool informationalOnly = ContainsAny(text, InformationalOnlyTokens) ||
                                     (ContainsAny(text, PreApplicationTokens) && !ContainsAny(text, IncomingPaymentTokens));

            bool residencePermitMentioned =
                ContainsAny(text, ResidencePermitTokens) ||
                secondaryPermit;
            bool residencePermit =
                residencePermitMentioned &&
                (ContainsAny(text, ResidencePermitStateRequestTokens) ||
                 (secondaryPermit && ContainsAny(text, DocumentTokens))) &&
                !informationalOnly;

            bool technicalOrFinancialBlock =
                ContainsAny(text, FinancialInstrumentBlockTokens) ||
                ContainsAny(text, TechnicalBlockTokens);
            bool topicSuggestsApplicationBlock =
                referredToBlocks ||
                TopicContainsAny(secondaryTopicCode, "BLOCCHI") ||
                secondaryPermit ||
                primaryDocuments;
            bool applicationBlocks =
                !technicalOrFinancialBlock &&
                (
                    (ContainsAny(text, AdministrativeBlockRemovalTokens) &&
                     (ContainsAny(text, ApplicationBlockContextTokens) || topicSuggestsApplicationBlock)) ||
                    (topicSuggestsApplicationBlock &&
                     ContainsAny(text, BlockRemovalTokens) &&
                     ContainsAny(text, BlockReferenceTokens))
                ) &&
                !informationalOnly;

            bool strongScholarshipPayment = ContainsAny(text, ScholarshipPaymentStrongTokens);
            bool contextualScholarshipPayment =
                ContainsAny(text, ScholarshipPaymentActionTokens) &&
                (ContainsAny(text, ScholarshipContextTokens) ||
                 secondaryPayments ||
                 primaryPayments ||
                 primaryBenefits);
            bool incomingInstallment =
                ContainsAny(text, ScholarshipInstallmentTokens) &&
                ContainsAny(text, IncomingPaymentTokens);
            bool onlyStudentPaidTax =
                ContainsAny(text, StudentPaidTaxTokens) &&
                !strongScholarshipPayment &&
                !ContainsAny(text, "accredito", "erogazione", "liquidazione", "rata della borsa", "saldo della borsa");
            bool scholarshipPayments =
                !onlyStudentPaidTax &&
                (strongScholarshipPayment || contextualScholarshipPayment || incomingInstallment) &&
                ContainsAny(text, IncomingPaymentTokens) &&
                !ContainsAny(text, PaymentEvidenceRequestTokens) &&
                !informationalOnly;

            var signals = new List<string>();
            if (scholarshipPayments)
                signals.Add("EROGAZIONE_BORSA");
            if (residencePermit)
                signals.Add("PERMESSO_SOGGIORNO");
            if (applicationBlocks)
                signals.Add("BLOCCHI_PRATICA");

            return new TicketResolutionScope
            {
                ScholarshipPayments = scholarshipPayments,
                ResidencePermitDocuments = residencePermit,
                ApplicationBlocks = applicationBlocks,
                Signals = string.Join(" + ", signals)
            };
        }

        public static PaymentRequestKind ClassifyPaymentRequest(
            string subject,
            string message,
            string secondaryTopicCode = "")
        {
            string text = Normalize(subject + " " + message);
            if (ContainsAny(text, IntegrationTokens))
                return PaymentRequestKind.INTEGRAZIONE;
            if (ContainsAny(text, BalanceTokens) ||
                TopicContainsAny(secondaryTopicCode, "SALDO"))
                return PaymentRequestKind.SALDO;
            if (ContainsAny(text, FirstInstallmentTokens))
                return PaymentRequestKind.PRIMA_RATA;
            return PaymentRequestKind.GENERICO;
        }

        public static string FormatPaymentRequestKind(PaymentRequestKind kind) => kind switch
        {
            PaymentRequestKind.PRIMA_RATA => "PRIMA_RATA",
            PaymentRequestKind.SALDO => "SALDO",
            PaymentRequestKind.INTEGRAZIONE => "INTEGRAZIONE",
            _ => "PAGAMENTO_GENERICO"
        };

        public static bool AreResidencePermitDocumentsWorked(string rawDocuments)
        {
            if (string.IsNullOrWhiteSpace(rawDocuments))
                return false;

            var statuses = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (string part in rawDocuments.Split('|', StringSplitOptions.RemoveEmptyEntries))
            {
                string[] values = part.Trim().Split(':', 2, StringSplitOptions.TrimEntries);
                if (values.Length == 2 && !string.IsNullOrWhiteSpace(values[0]))
                    statuses[values[0]] = values[1];
            }

            return statuses.TryGetValue("01", out string? document01) && document01 == "05" &&
                   statuses.TryGetValue("02", out string? document02) && document02 == "05" &&
                   statuses.TryGetValue("03", out string? document03) && document03 == "05";
        }

        public static ApplicationState ClassifyApplicationState(int status)
        {
            if (status <= 0)
                return ApplicationState.SCONOSCIUTO;
            if (status < 90)
                return ApplicationState.INCOMPLETA_O_NON_TRASMESSA;
            return ApplicationState.TRASMESSA_O_COMPLETA;
        }

        public static string GetApplicationStateLabel(ApplicationState state) => state switch
        {
            ApplicationState.SCONOSCIUTO => "SCONOSCIUTO",
            ApplicationState.INCOMPLETA_O_NON_TRASMESSA => "INCOMPLETA_O_NON_TRASMESSA",
            _ => "TRASMESSA_O_COMPLETA"
        };

        public static BlockAssessment AnalyzeBlocks(string rawBlocks, string topicCode)
        {
            if (string.IsNullOrWhiteSpace(rawBlocks))
                return new BlockAssessment();

            var relevant = new List<string>();
            var notRelevant = new List<string>();
            var relevantCategories = new HashSet<BlockCategory>();

            foreach (string block in SplitBlocks(rawBlocks))
            {
                BlockCategory category = ClassifyBlock(block);
                if (IsRelevant(category, topicCode))
                {
                    relevant.Add(block);
                    relevantCategories.Add(category);
                }
                else
                {
                    notRelevant.Add(block);
                }
            }

            return new BlockAssessment
            {
                RelevantBlocks = string.Join(" | ", relevant),
                NonRelevantBlocks = string.Join(" | ", notRelevant),
                RelevantCategories = relevantCategories.ToArray()
            };
        }

        public static IReadOnlyList<string> FindContradictions(
            TicketIntentAssessment intent,
            TicketOfficeRecord? record,
            string topicCode)
        {
            var findings = new List<string>();
            if (record == null)
                return findings;

            if (intent.Intent == TicketIntent.INVIO_DOCUMENTO &&
                string.Equals(topicCode, "DOCUMENTI_E_PERMESSI", StringComparison.OrdinalIgnoreCase) &&
                string.IsNullOrWhiteSpace(record.ResidencePermitDocuments))
            {
                findings.Add("Il ticket dichiara l'invio di documenti ma non risultano documenti del permesso nei dati estratti.");
            }

            if (intent.Intent == TicketIntent.AGGIORNAMENTO_DATI &&
                string.Equals(topicCode, "IBAN", StringComparison.OrdinalIgnoreCase) &&
                !string.IsNullOrWhiteSpace(record.Iban))
            {
                findings.Add("L'IBAN è presente: la richiesta può riguardare una variazione, non l'assenza del dato.");
            }

            if (intent.Intent == TicketIntent.CONTESTAZIONE)
                findings.Add("Il ticket contiene una contestazione: l'esito operativo non è sufficiente per una chiusura automatica.");

            return findings;
        }

        public static bool IsClosureCompatible(TicketIntent intent) =>
            intent == TicketIntent.SOLLECITO ||
            intent == TicketIntent.STATO_PRATICA ||
            intent == TicketIntent.INVIO_DOCUMENTO;

        public static string FormatIntent(TicketIntent intent) => intent switch
        {
            TicketIntent.INFORMAZIONE => "INFORMAZIONE",
            TicketIntent.STATO_PRATICA => "STATO_PRATICA",
            TicketIntent.SOLLECITO => "SOLLECITO",
            TicketIntent.CONTESTAZIONE => "CONTESTAZIONE",
            TicketIntent.ERRORE_TECNICO => "ERRORE_TECNICO",
            TicketIntent.INVIO_DOCUMENTO => "INVIO_DOCUMENTO",
            TicketIntent.AGGIORNAMENTO_DATI => "AGGIORNAMENTO_DATI",
            TicketIntent.RINUNCIA_O_RECESSO => "RINUNCIA_O_RECESSO",
            TicketIntent.PRE_DOMANDA => "PRE_DOMANDA",
            _ => "ALTRO_DA_VERIFICARE"
        };

        private static TicketIntentAssessment NewAssessment(TicketIntent intent, string confidence, string signals) => new()
        {
            Intent = intent,
            Confidence = confidence,
            Signals = signals
        };

        private static IEnumerable<string> SplitBlocks(string rawBlocks)
        {
            return rawBlocks
                .Split(new[] { '|', '/', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(value => value.Trim())
                .Where(value => !string.IsNullOrWhiteSpace(value));
        }

        private static BlockCategory ClassifyBlock(string block)
        {
            string normalized = Normalize(block);
            if (ContainsAny(normalized, "permesso", "document", "allegat"))
                return BlockCategory.DOCUMENTI_E_PERMESSI;
            if (ContainsAny(normalized, "isee", "dsu", "redditi", "caf", "ispe"))
                return BlockCategory.REDDITI_E_ISEE;
            if (ContainsAny(normalized, "iscrizion", "carriera", "merito", "credit", "immatricol"))
                return BlockCategory.ISCRIZIONE_E_CARRIERA;
            if (ContainsAny(normalized, "pagament", "mandato", "iban", "tassa", "detraz", "reversal", "contabil"))
                return BlockCategory.PAGAMENTI_E_TASSE;
            if (ContainsAny(normalized, "alloggi", "domicilio", "contratto", "residenza"))
                return BlockCategory.ALLOGGIO_E_DOMICILIO;
            if (ContainsAny(normalized, "portale", "accesso", "tecnic", "login"))
                return BlockCategory.PORTALE_E_TECNICO;
            return BlockCategory.ALTRO;
        }

        private static bool IsRelevant(BlockCategory category, string topicCode)
        {
            string topic = topicCode?.Trim().ToUpperInvariant() ?? string.Empty;
            return topic switch
            {
                "PAGAMENTI_E_TASSE" or "BENEFICI_E_IMPORTI" or "IBAN" =>
                    category == BlockCategory.PAGAMENTI_E_TASSE,
                "DOCUMENTI_E_PERMESSI" =>
                    category == BlockCategory.DOCUMENTI_E_PERMESSI || category == BlockCategory.REDDITI_E_ISEE,
                "ISCRIZIONE_E_CARRIERA" =>
                    category == BlockCategory.ISCRIZIONE_E_CARRIERA,
                "ALLOGGIO" =>
                    category == BlockCategory.ALLOGGIO_E_DOMICILIO,
                "PORTALE_E_ACCESSO" =>
                    category == BlockCategory.PORTALE_E_TECNICO,
                "MOBILITA" =>
                    category == BlockCategory.DOCUMENTI_E_PERMESSI || category == BlockCategory.ISCRIZIONE_E_CARRIERA,
                "GRADUATORIE" =>
                    category == BlockCategory.DOCUMENTI_E_PERMESSI || category == BlockCategory.REDDITI_E_ISEE,
                _ => false
            };
        }

        private static bool ContainsAny(string text, params string[] tokens)
        {
            return tokens.Any(token => text.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private static bool TopicContainsAny(string topicText, params string[] topics)
        {
            if (string.IsNullOrWhiteSpace(topicText))
                return false;

            string[] values = topicText
                .Split('|', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            foreach (string value in values)
            {
                foreach (string topic in topics)
                {
                    if (string.Equals(value, topic, StringComparison.OrdinalIgnoreCase))
                        return true;
                }
            }

            return false;
        }

        private static string Normalize(string value)
        {
            var builder = new StringBuilder();
            foreach (char character in (value ?? string.Empty).Normalize(NormalizationForm.FormD))
            {
                if (CharUnicodeInfo.GetUnicodeCategory(character) != UnicodeCategory.NonSpacingMark)
                    builder.Append(char.ToLowerInvariant(character));
            }

            return builder.ToString();
        }
    }
}
