using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;

namespace ProcedureNet7
{
    /// <summary>
    /// Costruisce la coda operativa dopo il riepilogo originario.
    /// La coda mette in testa i ticket per cui i dati attestano che la situazione
    /// richiesta dallo studente è già stata risolta.
    /// </summary>
    internal static class TicketOperationalWorkbook
    {
        private const string CloseResolved = "CHIUDIBILE_SITUAZIONE_GIA_RISOLTA";
        private const string CloseStandard = "CHIUDIBILE_CON_RISPOSTA_STANDARD";
        private const string ClosePersonalized = "FUORI_PERIMETRO_RISCONTRO_ASSISTITO";
        private const string ActionRequired = "NON_CHIUDIBILE_AZIONE_OPERATIVA_NECESSARIA";
        private const string DataMissing = "NON_CHIUDIBILE_DOCUMENTO_O_DATO_MANCANTE";
        private const string Verify = "DA_VERIFICARE_DATI_INSUFFICIENTI";

        private static readonly CultureInfo ItalianCulture = CultureInfo.GetCultureInfo("it-IT");
        private static readonly Lazy<IReadOnlyDictionary<string, string>> ResponseTexts = new(() =>
            BuildRulesAndResponseCodes()
                .AsEnumerable()
                .ToDictionary(
                    row => ReadString(row, "CODICE_RISPOSTA"),
                    row => ReadString(row, "RISCONTRO_BASE"),
                    StringComparer.OrdinalIgnoreCase));

        public static DataTable BuildOperationalQueue(TicketTopicSheetContext context)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            DataTable result = CreateQueueTable();
            List<QueueItem> items = GetDistinctTicketRows(context.Tickets)
                .Select(item => BuildQueueItem(context, item.Row, item.Index))
                .OrderBy(item => item.PriorityOrder)
                .ThenByDescending(item => item.DaysOpen ?? -1)
                .ThenBy(item => item.TicketId, StringComparer.OrdinalIgnoreCase)
                .ToList();

            foreach (QueueItem item in items)
            {
                DataRow row = result.NewRow();
                row["CHIUDIBILE"] = item.Closable;
                row["STATO_CHIUDIBILITA"] = item.ClosureStatus;
                row["OGGETTO_RICHIESTO"] = item.RequestedObject;
                row["AA_COERENZA"] = item.AcademicYearConsistency;
                row["MOTIVO_NON_CHIUSURA"] = item.NonClosureReason;
                row["AMBITI_RICHIESTI"] = item.RequestedScopes;
                row["ESITO_CONTROLLI_CHIUSURA"] = item.ClosureChecks;
                row["CONDIZIONE_RISOLTA"] = item.ResolvedCondition;
                row["PRIORITA"] = item.Priority;
                row["MOTIVO_PRIORITA"] = item.PriorityReason;
                row["DECISIONE_PROPOSTA"] = item.Decision;
                row["AZIONE_RICHIESTA"] = item.RequiredAction;
                row["MOTIVO_DECISIONE"] = item.Reason;
                row["CODICE_RISPOSTA"] = item.ResponseCode;
                row["TESTO_RISCONTRO_BASE"] = item.ResponseText;
                row["EVIDENZE_CHIAVE"] = item.Evidence;
                row["TICKET_RIGUARDA_BLOCCHI"] = item.TicketMentionsBlocks ? "SI" : "NO";
                row["STUDENTE_HA_BLOCCHI"] = item.StudentHasBlocks ? "SI" : "NO";
                row["BLOCCHI_RILEVANTI"] = item.RelevantBlocks;
                row["BLOCCHI_NON_PERTINENTI"] = item.NonRelevantBlocks;
                row["CONTRADDIZIONI_RILEVATE"] = item.Contradictions;
                row["FOGLIO_DETTAGLIO"] = item.DetailSheet;
                row["ID_TICKET"] = item.TicketId;
                row["ETA_TICKET_GIORNI"] = item.DaysOpen.HasValue
                    ? (object)item.DaysOpen.Value
                    : DBNull.Value;
                row["DATA_APERTURA"] = item.CreationDate.HasValue
                    ? (object)item.CreationDate.Value
                    : DBNull.Value;
                row["DATA_ULTIMO_MESSAGGIO"] = item.LastMessageDate.HasValue
                    ? (object)item.LastMessageDate.Value
                    : DBNull.Value;
                row["ARGOMENTO"] = item.Topic;
                row["ARGOMENTI_SECONDARI"] = item.SecondaryTopics;
                row["INTENTO_RICHIESTA"] = item.Intent;
                row["SEGNALI_INTENTO"] = item.IntentSignals;
                row["AA_DICHIARATO_TICKET"] = item.DeclaredAcademicYear;
                row["CATEGORIA_DOMANDE_STUDENTE"] = item.StudentApplicationCategory;
                row["ANNI_DOMANDE_RILEVATI"] = item.ParticipatedAcademicYears;
                row["AA_RECORD_OPERATIVO"] = item.OperationalAcademicYear;
                row["CRITERIO_SELEZIONE_RECORD"] = item.RecordSelectionCriterion;
                row["STATO_DOMANDA_INTERPRETATO"] = item.ApplicationState;
                row["CONFIDENZA_ARGOMENTO"] = item.TopicConfidence;
                row["CONFIDENZA_INTENTO"] = item.IntentConfidence;
                row["CONFIDENZA_DATI_OPERATIVI"] = item.OperationalDataConfidence;
                row["CONFIDENZA_DECISIONE"] = item.DecisionConfidence;
                row["CODFISC"] = item.FiscalCode;
                row["CODSTUD"] = item.StudentCode;
                row["OGGETTO"] = item.Subject;
                row["PRIMO_MSG_STUDENTE"] = item.StudentMessage;
                row["STATO_LAVORAZIONE"] = "DA_LAVORARE";
                row["DECISIONE_OPERATORE"] = string.Empty;
                row["ASSEGNATARIO"] = string.Empty;
                row["NOTA_OPERATORE"] = string.Empty;
                row["DATA_LAVORAZIONE"] = DBNull.Value;
                row["ESITO_INVIATO"] = string.Empty;
                result.Rows.Add(row);
            }

            Logger.LogInfo(null, $"Coda operativa costruita. Ticket univoci: {result.Rows.Count}");
            return result;
        }

        public static DataTable BuildDashboard(DataTable queue)
        {
            if (queue == null)
                throw new ArgumentNullException(nameof(queue));

            var result = new DataTable();
            result.Columns.Add("SEZIONE", typeof(string));
            result.Columns.Add("INDICATORE", typeof(string));
            result.Columns.Add("VALORE", typeof(int));

            AddMetric(result, "Generale", "Ticket totali", queue.Rows.Count);
            AddMetric(result, "Chiusura", "Chiudibili - situazione già risolta", CountByPrefix(queue, "DECISIONE_PROPOSTA", CloseResolved));
            AddMetric(result, "Decisione", "Chiudibili con risposta standard", CountByPrefix(queue, "DECISIONE_PROPOSTA", CloseStandard));
            AddMetric(result, "Decisione", "Riscontro assistito fuori perimetro", CountByPrefix(queue, "DECISIONE_PROPOSTA", ClosePersonalized));
            AddMetric(result, "Decisione", "Non chiudibili - azione operativa", CountByPrefix(queue, "DECISIONE_PROPOSTA", ActionRequired));
            AddMetric(result, "Decisione", "Non chiudibili - documento o dato mancante", CountByPrefix(queue, "DECISIONE_PROPOSTA", DataMissing));
            AddMetric(result, "Decisione", "Da verificare", CountByPrefix(queue, "DECISIONE_PROPOSTA", Verify));
            AddMetric(result, "Priorità chiusura", "P1 - chiusura proposta", CountExact(queue, "PRIORITA", "P1"));
            AddMetric(result, "Priorità chiusura", "P2 - controllo rapido", CountExact(queue, "PRIORITA", "P2"));
            AddMetric(result, "Priorità chiusura", "P3 - attività necessaria", CountExact(queue, "PRIORITA", "P3"));
            AddMetric(result, "Priorità chiusura", "P4 - verifica manuale", CountExact(queue, "PRIORITA", "P4"));
            AddMetric(result, "Ambiti richiesti", "Erogazione borsa", CountContains(queue, "AMBITI_RICHIESTI", "EROGAZIONE_BORSA"));
            AddMetric(result, "Ambiti richiesti", "Permesso di soggiorno", CountContains(queue, "AMBITI_RICHIESTI", "PERMESSO_SOGGIORNO"));
            AddMetric(result, "Ambiti richiesti", "Blocchi pratica", CountContains(queue, "AMBITI_RICHIESTI", "BLOCCHI_PRATICA"));
            AddMetric(result, "Situazioni risolte", "Blocco non più presente", CountExact(queue, "CONDIZIONE_RISOLTA", "BLOCCO_AMMINISTRATIVO_NON_PIU_PRESENTE_STESSO_AA"));
            AddMetric(result, "Situazioni risolte", "Pagamento borsa completato", CountPaymentResolved(queue));
            AddMetric(result, "Situazioni risolte", "Documenti permesso lavorati - status 05", CountExact(queue, "CONDIZIONE_RISOLTA", "DOCUMENTI_PERMESSO_LAVORATI_STATUS_05_STESSO_AA"));
            AddMetric(result, "Situazioni risolte", "Permesso lavorato e blocchi rimossi", CountExact(queue, "CONDIZIONE_RISOLTA", "PERMESSO_LAVORATO_E_BLOCCO_RIMOSSO_STESSO_AA"));
            AddMetric(result, "Situazioni risolte", "Condizioni multiple tutte risolte", CountExact(queue, "CONDIZIONE_RISOLTA", "TUTTE_LE_CONDIZIONI_RICHIESTE_RISOLTE_STESSO_AA"));
            AddMetric(result, "Qualità", "Contraddizioni rilevate", CountNotEmpty(queue, "CONTRADDIZIONI_RILEVATE"));
            AddMetric(result, "Qualità", "Decisioni a confidenza bassa", CountExact(queue, "CONFIDENZA_DECISIONE", "BASSA"));
            AddMetric(result, "Blocchi", "Ticket che riguardano blocchi", CountExact(queue, "TICKET_RIGUARDA_BLOCCHI", "SI"));
            AddMetric(result, "Blocchi", "Ticket con studente che ha blocchi", CountExact(queue, "STUDENTE_HA_BLOCCHI", "SI"));
            AddMetric(result, "Lavorazione", "Da lavorare", CountExact(queue, "STATO_LAVORAZIONE", "DA_LAVORARE"));
            AddMetric(result, "Lavorazione", "In lavorazione", CountExact(queue, "STATO_LAVORAZIONE", "IN_LAVORAZIONE"));
            AddMetric(result, "Lavorazione", "In attesa studente", CountExact(queue, "STATO_LAVORAZIONE", "IN_ATTESA_STUDENTE"));
            AddMetric(result, "Lavorazione", "In attesa ufficio", CountExact(queue, "STATO_LAVORAZIONE", "IN_ATTESA_UFFICIO"));
            AddMetric(result, "Lavorazione", "Chiusi", CountExact(queue, "STATO_LAVORAZIONE", "CHIUSO"));

            foreach (IGrouping<string, DataRow> group in queue.AsEnumerable()
                .GroupBy(row => ReadString(row, "CATEGORIA_DOMANDE_STUDENTE"), StringComparer.OrdinalIgnoreCase)
                .OrderBy(group => group.Key, StringComparer.OrdinalIgnoreCase))
            {
                int students = group
                    .Select(row =>
                    {
                        string fiscalCode = ReadString(row, "CODFISC");
                        return string.IsNullOrWhiteSpace(fiscalCode)
                            ? ReadString(row, "ID_TICKET")
                            : fiscalCode;
                    })
                    .Where(key => !string.IsNullOrWhiteSpace(key))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .Count();

                AddMetric(
                    result,
                    "Studenti per categoria domanda",
                    string.IsNullOrWhiteSpace(group.Key) ? "Non classificabile" : group.Key,
                    students);
            }

            foreach (IGrouping<string, DataRow> group in queue.AsEnumerable()
                .GroupBy(row => ReadString(row, "ARGOMENTO"), StringComparer.OrdinalIgnoreCase)
                .OrderByDescending(group => group.Count())
                .ThenBy(group => group.Key, StringComparer.OrdinalIgnoreCase))
            {
                AddMetric(result, "Argomento", string.IsNullOrWhiteSpace(group.Key) ? "Non classificato" : group.Key, group.Count());
            }

            return result;
        }

        public static DataTable BuildTicketsToVerify(DataTable queue)
        {
            if (queue == null)
                throw new ArgumentNullException(nameof(queue));

            DataTable result = queue.Clone();
            foreach (DataRow row in queue.Rows)
            {
                string decision = ReadString(row, "DECISIONE_PROPOSTA");
                bool closable = string.Equals(ReadString(row, "CHIUDIBILE"), "SI", StringComparison.OrdinalIgnoreCase) ||
                                string.Equals(ReadString(row, "CHIUDIBILE"), "PROBABILE", StringComparison.OrdinalIgnoreCase);
                bool include = decision.StartsWith(Verify, StringComparison.OrdinalIgnoreCase) ||
                               (!closable &&
                                (!string.IsNullOrWhiteSpace(ReadString(row, "CONTRADDIZIONI_RILEVATE")) ||
                                 string.Equals(ReadString(row, "CONFIDENZA_DECISIONE"), "BASSA", StringComparison.OrdinalIgnoreCase)));
                if (include)
                    result.ImportRow(row);
            }

            return result;
        }

        public static DataTable BuildStudentCategorySummary(
            DataTable queue,
            string categoryLabel)
        {
            if (queue == null)
                throw new ArgumentNullException(nameof(queue));
            if (string.IsNullOrWhiteSpace(categoryLabel))
                throw new ArgumentException("La categoria domanda non è valida.", nameof(categoryLabel));

            DataTable result = CreateStudentCategorySummaryTable();
            IEnumerable<IGrouping<string, DataRow>> students = queue.AsEnumerable()
                .Where(row => string.Equals(
                    ReadString(row, "CATEGORIA_DOMANDE_STUDENTE"),
                    categoryLabel,
                    StringComparison.OrdinalIgnoreCase))
                .GroupBy(row =>
                {
                    string fiscalCode = ReadString(row, "CODFISC");
                    return string.IsNullOrWhiteSpace(fiscalCode)
                        ? $"__TICKET__{ReadString(row, "ID_TICKET")}" 
                        : fiscalCode;
                }, StringComparer.OrdinalIgnoreCase)
                .OrderBy(group => group.Key, StringComparer.OrdinalIgnoreCase);

            foreach (IGrouping<string, DataRow> student in students)
            {
                List<DataRow> tickets = student
                    .OrderBy(row => GetPriorityOrder(ReadString(row, "PRIORITA")))
                    .ThenByDescending(row => ReadNullableInt(row, "ETA_TICKET_GIORNI") ?? -1)
                    .ThenBy(row => ReadString(row, "ID_TICKET"), StringComparer.OrdinalIgnoreCase)
                    .ToList();
                DataRow primaryTicket = tickets.First();

                DataRow row = result.NewRow();
                row["CATEGORIA_DOMANDE_STUDENTE"] = categoryLabel;
                row["CODFISC"] = ReadString(primaryTicket, "CODFISC");
                row["CODSTUD"] = ReadString(primaryTicket, "CODSTUD");
                row["ANNI_DOMANDE_RILEVATI"] = ReadString(primaryTicket, "ANNI_DOMANDE_RILEVATI");
                row["NUMERO_TICKET"] = tickets.Count;
                row["TICKET_P1"] = tickets.Count(ticket => string.Equals(ReadString(ticket, "PRIORITA"), "P1", StringComparison.OrdinalIgnoreCase));
                row["TICKET_CHIUDIBILI"] = tickets.Count(ticket =>
                    string.Equals(ReadString(ticket, "CHIUDIBILE"), "SI", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(ReadString(ticket, "CHIUDIBILE"), "PROBABILE", StringComparison.OrdinalIgnoreCase));
                row["TICKET_DA_VERIFICARE"] = tickets.Count(ticket => ReadString(ticket, "DECISIONE_PROPOSTA").StartsWith(Verify, StringComparison.OrdinalIgnoreCase));
                row["TICKET_AZIONE_OPERATIVA"] = tickets.Count(ticket =>
                    ReadString(ticket, "DECISIONE_PROPOSTA").StartsWith(ActionRequired, StringComparison.OrdinalIgnoreCase) ||
                    ReadString(ticket, "DECISIONE_PROPOSTA").StartsWith(DataMissing, StringComparison.OrdinalIgnoreCase));
                row["ALMENO_UN_TICKET_RIGUARDA_BLOCCHI"] = tickets.Any(ticket =>
                    string.Equals(ReadString(ticket, "TICKET_RIGUARDA_BLOCCHI"), "SI", StringComparison.OrdinalIgnoreCase)) ? "SI" : "NO";
                row["STUDENTE_HA_BLOCCHI"] = tickets.Any(ticket =>
                    string.Equals(ReadString(ticket, "STUDENTE_HA_BLOCCHI"), "SI", StringComparison.OrdinalIgnoreCase)) ? "SI" : "NO";
                row["PRIORITA_MASSIMA"] = ReadString(primaryTicket, "PRIORITA");
                row["ID_TICKET_PRIORITARIO"] = ReadString(primaryTicket, "ID_TICKET");
                row["OGGETTO_TICKET_PRIORITARIO"] = ReadString(primaryTicket, "OGGETTO");
                row["DECISIONE_PROPOSTA_TICKET_PRIORITARIO"] = ReadString(primaryTicket, "DECISIONE_PROPOSTA");
                row["FOGLIO_DETTAGLIO"] = ReadString(primaryTicket, "FOGLIO_DETTAGLIO");
                DateTime? oldestCreationDate = tickets
                    .Select(ticket => ReadNullableDate(ticket, "DATA_APERTURA"))
                    .Where(date => date.HasValue)
                    .OrderBy(date => date.Value)
                    .FirstOrDefault();
                row["DATA_APERTURA_PIU_VECCHIA"] = oldestCreationDate.HasValue
                    ? (object)oldestCreationDate.Value
                    : DBNull.Value;
                result.Rows.Add(row);
            }

            return result;
        }

        public static DataTable BuildRulesAndResponseCodes()
        {
            var result = new DataTable();
            result.Columns.Add("CODICE_RISPOSTA", typeof(string));
            result.Columns.Add("CASO", typeof(string));
            result.Columns.Add("DECISIONE_PROPOSTA", typeof(string));
            result.Columns.Add("AZIONE_RICHIESTA", typeof(string));
            result.Columns.Add("RISCONTRO_BASE", typeof(string));

            AddRule(result, "GEN_01", "Nessuna domanda operativa", Verify,
                "Verificare codice fiscale, identità studente e presenza di una domanda.",
                "Non risultano dati operativi associabili con sufficiente certezza. È necessaria una verifica anagrafica e della domanda.");
            AddRule(result, "GEN_02", "Argomento classificato con confidenza insufficiente", Verify,
                "Leggere messaggio e oggetto; correggere l'argomento prima della chiusura.",
                "Il contenuto del ticket richiede una verifica manuale dell'argomento prima di predisporre il riscontro.");
            AddRule(result, "GEN_03", "Richiesta informativa o pre-domanda", ClosePersonalized,
                "Gestire nel flusso di riscontro assistito: non proporre la chiusura automatica.",
                "La richiesta è informativa. Può essere trattata con riscontro assistito, ma non è una situazione già risolta da chiudere automaticamente.");
            AddRule(result, "GEN_04", "Contestazione, rinuncia o caso non automatizzabile", Verify,
                "Confrontare il testo del ticket con i dati disponibili e applicare la procedura dedicata.",
                "La richiesta richiede una valutazione manuale; i dati operativi non consentono una chiusura automatica.");
            AddRule(result, "GEN_05", "Contraddizione fra ticket e dati", Verify,
                "Verificare la discordanza indicata prima di predisporre o inviare il riscontro.",
                "Il testo del ticket e i dati operativi non sono pienamente coerenti. È necessaria una verifica puntuale.");
            AddRule(result, "GEN_06", "Anno accademico non identificato o non allineato", Verify,
                "Individuare nel ticket l'anno accademico e selezionare il record dello stesso anno prima di valutare la chiusura.",
                "La chiusura automatica richiede una corrispondenza esatta fra anno accademico del ticket e anno del record operativo.");
            AddRule(result, "GEN_07", "Più condizioni richieste, almeno una non risolta", ActionRequired,
                "Verificare separatamente tutti gli ambiti citati nel ticket e non chiudere finché ciascuno non risulta risolto.",
                "Il ticket contiene più richieste e almeno una condizione non risulta ancora risolta.");
            AddRule(result, "GEN_08", "Tutte le condizioni multiple risultano risolte", CloseResolved,
                "Confermare le evidenze dei singoli ambiti e chiudere il ticket.",
                "Tutti gli ambiti citati nel ticket risultano risolti. Il ticket può essere chiuso.");
            AddRule(result, "BLO_01", "Blocco pertinente all'argomento", ActionRequired,
                "Individuare e gestire la causa del blocco pertinente al ticket.",
                "La pratica presenta un blocco rilevante per l'argomento trattato. Il ticket non è chiudibile finché la causa non è verificata o risolta.");
            AddRule(result, "BLO_02", "Richiesta di rimozione blocco già risolta", CloseResolved,
                "Confermare che non risulti alcun blocco sulla domanda dello stesso anno e chiudere il ticket.",
                "Non risultano blocchi presenti sulla pratica per lo stesso anno accademico. La richiesta può essere chiusa.");
            AddRule(result, "DOM_01", "Domanda incompleta o stato sconosciuto", ActionRequired,
                "Verificare compilazione, trasmissione e stato effettivo della domanda.",
                "Lo stato disponibile della domanda non consente una chiusura automatica.");
            AddRule(result, "PAG_01", "Pagamento completo della borsa", CloseResolved,
                "Confermare mandato, importo, anno accademico e assenza di storni; poi chiudere il ticket.",
                "Per lo stesso anno accademico indicato nel ticket, l'importo BS risulta interamente pagato e associato a mandati validi. Il ticket può essere chiuso.");
            AddRule(result, "PAG_02", "Prima rata della borsa pagata", CloseResolved,
                "Confermare mandato della prima rata, anno accademico e assenza di storni; poi chiudere il ticket.",
                "Per lo stesso anno accademico indicato nel ticket, la prima rata BS risulta pagata e associata a un mandato valido. Il ticket può essere chiuso.");
            AddRule(result, "PAG_03", "Saldo della borsa pagato", CloseResolved,
                "Confermare mandato del saldo, anno accademico e assenza di storni; poi chiudere il ticket.",
                "Per lo stesso anno accademico indicato nel ticket, il saldo BS risulta pagato e associato a un mandato valido. Il ticket può essere chiuso.");
            AddRule(result, "PAG_12", "Integrazione della borsa pagata", CloseResolved,
                "Confermare mandato dell'integrazione, anno accademico e assenza di storni; poi chiudere il ticket.",
                "Per lo stesso anno accademico indicato nel ticket, l'integrazione BS risulta pagata e associata a un mandato valido. Il ticket può essere chiuso.");
            AddRule(result, "PAG_15", "Pagamento completo della borsa non risolto", ActionRequired,
                "Verificare importo assegnato, pagamenti validi, residuo e mandati.",
                "I pagamenti della borsa citati nel ticket non risultano tutti completati. Il ticket non è chiudibile.");
            AddRule(result, "PAG_17", "Prima rata non riscontrata", ActionRequired,
                "Verificare la prima rata, i mandati, gli storni e l'anno accademico richiesto.",
                "Per l'anno accademico indicato nel ticket non risulta una prima rata BS valida con mandato. Il ticket non è chiudibile.");
            AddRule(result, "PAG_18", "Saldo non riscontrato", ActionRequired,
                "Verificare il saldo, i mandati, gli storni e l'anno accademico richiesto.",
                "Per l'anno accademico indicato nel ticket non risulta un saldo BS valido con mandato. Il ticket non è chiudibile.");
            AddRule(result, "PAG_19", "Integrazione non riscontrata", ActionRequired,
                "Verificare l'integrazione, i mandati, gli storni e l'anno accademico richiesto.",
                "Per l'anno accademico indicato nel ticket non risulta un'integrazione BS valida con mandato. Il ticket non è chiudibile.");
            AddRule(result, "PAG_16", "Classificazione pagamenti senza richiesta di erogazione", Verify,
                "Rileggere il ticket e distinguere erogazioni della borsa da tasse o pagamenti effettuati dallo studente.",
                "Il ticket è classificato nell'area pagamenti, ma il testo non contiene una richiesta di erogazione della borsa.");
            AddRule(result, "PAG_04", "IBAN assente", DataMissing,
                "Richiedere o verificare l'IBAN e la modalità di pagamento.",
                "Per procedere è necessario verificare o aggiornare l'IBAN associato alla domanda.");
            AddRule(result, "PAG_05", "Vincitore senza pagamenti", ActionRequired,
                "Verificare iter contabile, impegni e mandati.",
                "La domanda risulta vincitrice ma non emergono pagamenti BS. È necessaria una verifica contabile.");
            AddRule(result, "PAG_06", "Pagamento parziale", ActionRequired,
                "Verificare rate, residuo, reversali e detrazioni.",
                "Dai dati disponibili risulta un pagamento BS parziale. Occorre verificare il residuo e l'iter della rata successiva.");
            AddRule(result, "PAG_07", "Studente escluso", ClosePersonalized,
                "Predisporre riscontro con l'esito disponibile.",
                "La domanda risulta esclusa. Predisporre un riscontro coerente con l'esito e le informazioni disponibili.");
            AddRule(result, "PAG_08", "Dati contabili non conclusivi", Verify,
                "Confrontare richiesta, esito, importi, pagamenti e mandati disponibili.",
                "I dati contabili disponibili richiedono una verifica puntuale prima di predisporre il riscontro.");
            AddRule(result, "PAG_09", "Sollecito con pagamento già disposto", Verify,
                "Verificare data del mandato, canale di accredito e causale prima della chiusura.",
                "Risultano un pagamento BS e un mandato, ma il ticket segnala una mancata ricezione. È necessaria una verifica puntuale.");
            AddRule(result, "PAG_10", "Pagamento BS stornato", ActionRequired,
                "Verificare causa dello storno ed eventuale riemissione del pagamento.",
                "Il movimento risulta ritirato dall'azienda: è stornato e non deve essere considerato accreditato allo studente.");
            AddRule(result, "PAG_11", "Codice pagamento BS non classificato", Verify,
                "Verificare il significato del codice BS prima di calcolare importi, residui o chiusure.",
                "Sono presenti codici BS non inclusi nella mappa dei pagamenti. I relativi importi non sono inclusi nelle somme automatiche.");
            AddRule(result, "BEN_01", "Esito o importo beneficio disponibile", ClosePersonalized,
                "Confrontare testo del ticket con esito e importi estratti.",
                "Gli esiti e gli importi risultano disponibili. Predisporre un riscontro aderente alla richiesta dello studente.");
            AddRule(result, "BEN_02", "Importo esito diverso dalle specifiche", ActionRequired,
                "Verificare coerenza tra esito e impegni contabili.",
                "Risulta una differenza tra l'importo dell'esito e le specifiche degli impegni. È necessaria una verifica contabile.");
            AddRule(result, "ALL_01", "Istanza domicilio aperta", ActionRequired,
                "Verificare lavorazione dell'istanza di domicilio.",
                "L'istanza di domicilio risulta aperta. Il ticket richiede verifica prima della chiusura.");
            AddRule(result, "ALL_02", "Contratto domicilio non presente", DataMissing,
                "Verificare presenza, validità o integrazione del contratto.",
                "Non risulta un contratto di domicilio associato alla domanda. Occorre verificare la documentazione.");
            AddRule(result, "ALL_03", "Esclusione alloggio", ClosePersonalized,
                "Predisporre riscontro con esito alloggio disponibile.",
                "La domanda risulta esclusa dal posto alloggio. Predisporre un riscontro coerente con l'esito.");
            AddRule(result, "ALL_04", "Dati alloggio disponibili", ClosePersonalized,
                "Confrontare richiesta, esito alloggio e dati di domicilio.",
                "I dati di alloggio e domicilio risultano disponibili. Predisporre un riscontro aderente alla richiesta.");
            AddRule(result, "ALL_05", "Rinuncia o check-out", ActionRequired,
                "Applicare la procedura di rinuncia, cessazione o check-out.",
                "La richiesta riguarda una rinuncia o un check-out e richiede una lavorazione amministrativa dedicata.");
            AddRule(result, "ALL_06", "Istanza di domicilio già lavorata", CloseResolved,
                "Confermare che non risultino istanze ancora aperte e chiudere il ticket.",
                "L'istanza di domicilio risulta lavorata e non risultano istanze ancora aperte. Il ticket può essere chiuso.");
            AddRule(result, "MEN_01", "Monetizzazione mensa", ClosePersonalized,
                "Confrontare richiesta con monetizzazione e pagamenti BS disponibili.",
                "La monetizzazione mensa risulta concessa. Verificare l'importo e l'eventuale pagamento prima della chiusura.");
            AddRule(result, "MEN_02", "Monetizzazione mensa non concessa", ClosePersonalized,
                "Predisporre riscontro sulla monetizzazione non concessa.",
                "La monetizzazione mensa non risulta concessa per la domanda selezionata.");
            AddRule(result, "DOC_01", "Documenti permesso non trovati", DataMissing,
                "Verificare allegati e richiedere eventuale integrazione.",
                "Non risultano documenti del permesso di soggiorno nei dati disponibili. È necessaria una verifica documentale.");
            AddRule(result, "DOC_02", "ISEE non valorizzato", DataMissing,
                "Verificare DSU, acquisizione ISEE e possibili integrazioni.",
                "L'ISEE DSU non risulta valorizzato. È necessaria una verifica dei dati economici.");
            AddRule(result, "DOC_03", "Documenti e dati economici disponibili", ClosePersonalized,
                "Controllare stato dei documenti e dati economici dichiarati.",
                "I documenti e i dati economici risultano disponibili. Predisporre un riscontro aderente alla richiesta.");
            AddRule(result, "DOC_04", "Documenti permesso lavorati con status 05", CloseResolved,
                "Confermare lo stato 05 dei documenti richiesti e chiudere il ticket.",
                "I documenti del permesso di soggiorno risultano inseriti e lavorati con status 05. Il ticket può essere chiuso.");
            AddRule(result, "DOC_05", "Documenti permesso non tutti lavorati con status 05", ActionRequired,
                "Verificare i documenti 01, 02 e 03 e attendere che risultino tutti in status 05.",
                "I documenti del permesso di soggiorno non risultano tutti lavorati con status 05. Il ticket non è chiudibile.");
            AddRule(result, "DOC_BLO_01", "Permesso lavorato e blocchi rimossi", CloseResolved,
                "Confermare documenti in status 05 e assenza di blocchi, quindi chiudere il ticket.",
                "I documenti del permesso risultano lavorati e non risultano blocchi presenti. Il ticket può essere chiuso.");
            AddRule(result, "IBAN_01", "IBAN presente", ClosePersonalized,
                "Verificare eventuali blocchi e mandati prima dell'invio.",
                "L'IBAN risulta presente. Predisporre un riscontro in base alla richiesta e ai mandati disponibili.");
            AddRule(result, "IBAN_02", "Aggiornamento IBAN richiesto", ActionRequired,
                "Verificare l'autorizzazione alla variazione e i dati bancari aggiornati.",
                "La richiesta riguarda una modifica delle coordinate di pagamento e richiede una lavorazione dedicata.");
            AddRule(result, "GRA_01", "Graduatoria definitiva disponibile", ClosePersonalized,
                "Confrontare beneficio richiesto, esito e graduatoria definitiva.",
                "La graduatoria definitiva risulta disponibile. Predisporre il riscontro con l'esito pertinente.");
            AddRule(result, "GRA_02", "Graduatoria definitiva non disponibile", ActionRequired,
                "Verificare pubblicazione, caricamento o stato del procedimento.",
                "Non risulta una graduatoria definitiva nei dati disponibili. È necessaria una verifica dell'iter.");
            AddRule(result, "MOB_01", "Contributo mobilità non richiesto", ClosePersonalized,
                "Confrontare richiesta dello studente con i benefici registrati.",
                "Il contributo di mobilità non risulta tra i benefici richiesti per la domanda selezionata.");
            AddRule(result, "MOB_02", "Contributo mobilità da verificare", Verify,
                "Verificare richiesta, esito CI e documentazione collegata.",
                "I dati disponibili non consentono di chiudere automaticamente la verifica del contributo mobilità.");
            AddRule(result, "MOB_03", "Contributo mobilità con dati disponibili", ClosePersonalized,
                "Confrontare esito e importo CI con quanto dichiarato nel ticket.",
                "Sono disponibili dati sul contributo mobilità richiesto. Predisporre un riscontro aderente alla richiesta.");
            AddRule(result, "POR_01", "Portale o accesso", Verify,
                "Verificare il problema tecnico descritto e lo stato della domanda.",
                "Il problema di accesso richiede verifica del messaggio e, se necessario, intervento tecnico o istruzioni mirate.");
            AddRule(result, "CAR_01", "Carriera o iscrizione", Verify,
                "Verificare carriera, anno di corso, crediti e precedenti partecipazioni.",
                "La richiesta richiede una verifica puntuale della carriera e non è chiudibile automaticamente.");
            AddRule(result, "ALT_01", "Argomento non classificato", Verify,
                "Leggere il ticket e assegnare l'ufficio o argomento corretto.",
                "Il ticket non è classificato in modo affidabile. È necessaria una valutazione manuale.");

            return result;
        }

        public static void EnrichTopicSheet(DataTable topicData, DataTable queue)
        {
            if (topicData == null)
                throw new ArgumentNullException(nameof(topicData));
            if (queue == null || !topicData.Columns.Contains("ID_TICKET"))
                return;

            string[] columns =
            {
                "CHIUDIBILE",
                "STATO_CHIUDIBILITA",
                "OGGETTO_RICHIESTO",
                "AA_COERENZA",
                "MOTIVO_NON_CHIUSURA",
                "AMBITI_RICHIESTI",
                "ESITO_CONTROLLI_CHIUSURA",
                "CONDIZIONE_RISOLTA",
                "PRIORITA",
                "DECISIONE_PROPOSTA",
                "AZIONE_RICHIESTA",
                "CODICE_RISPOSTA",
                "EVIDENZE_CHIAVE",
                "TICKET_RIGUARDA_BLOCCHI",
                "STUDENTE_HA_BLOCCHI",
                "INTENTO_RICHIESTA",
                "CONFIDENZA_DECISIONE",
                "CONTRADDIZIONI_RILEVATE",
                "BLOCCHI_RILEVANTI"
            };

            foreach (string column in columns)
            {
                if (!topicData.Columns.Contains(column))
                    topicData.Columns.Add(column, typeof(string));
            }

            var queueById = queue.AsEnumerable()
                .Where(row => !string.IsNullOrWhiteSpace(ReadString(row, "ID_TICKET")))
                .GroupBy(row => ReadString(row, "ID_TICKET"), StringComparer.OrdinalIgnoreCase)
                .ToDictionary(group => group.Key, group => group.First(), StringComparer.OrdinalIgnoreCase);

            foreach (DataRow row in topicData.Rows)
            {
                string ticketId = ReadString(row, "ID_TICKET");
                if (string.IsNullOrWhiteSpace(ticketId) || !queueById.TryGetValue(ticketId, out DataRow? queueRow))
                    continue;

                foreach (string column in columns)
                    row[column] = ReadString(queueRow, column);
            }
        }

        private static QueueItem BuildQueueItem(TicketTopicSheetContext context, DataRow source, int sourceIndex)
        {
            string fiscalCode = ReadString(source, "CODFISC");
            string topicCode = ReadString(source, "ARGOMENTO_PRIMARIO");
            string secondaryTopicCode = ReadString(source, "ARGOMENTO_SECONDARIO");
            string ticketId = ReadString(source, "ID_TICKET");
            string subject = ReadString(source, "OGGETTO");
            string studentMessage = ReadString(source, "PRIMO_MSG_STUDENTE");
            string declaredAcademicYear = ReadString(source, "ANNO_ACCADEMICO_RICHIESTA");
            TicketRecordSelection selection = context.ResolveOperationalRecord(fiscalCode, declaredAcademicYear);
            TicketOfficeRecord? record = selection.Record;
            TicketResolutionScope resolutionScope = TicketOperationalAnalysis.AnalyzeResolutionScope(
                subject,
                studentMessage,
                topicCode,
                secondaryTopicCode,
                IsYes(source, "RIFERITO_A_BLOCCHI"));
            bool ticketMentionsBlocks = resolutionScope.ApplicationBlocks;
            bool studentHasBlocks = record != null && !string.IsNullOrWhiteSpace(record.Blocks);
            TicketIntentAssessment intent = TicketOperationalAnalysis.AnalyzeIntent(
                subject,
                studentMessage,
                topicCode);
            PaymentRequestKind paymentRequest = TicketOperationalAnalysis.ClassifyPaymentRequest(
                subject,
                studentMessage,
                secondaryTopicCode);
            ApplicationState applicationState = record == null
                ? ApplicationState.SCONOSCIUTO
                : TicketOperationalAnalysis.ClassifyApplicationState(record.CompilationStatus);
            BlockAssessment blockAssessment = TicketOperationalAnalysis.AnalyzeBlocks(record?.Blocks ?? string.Empty, topicCode);
            IReadOnlyList<string> contradictions = TicketOperationalAnalysis.FindContradictions(intent, record, topicCode);
            DateTime? creationDate = ReadDate(source, "DATA_CREAZIONE", "DATA_APERTURA");
            DateTime? lastMessageDate = ReadDate(source, "DATA_ULTIMO_MESSAGGIO", "DATA_ULTIMO_MSG", "DATA_ULTIMA_MODIFICA");
            int? daysOpen = creationDate.HasValue ? Math.Max(0, (DateTime.Today - creationDate.Value.Date).Days) : null;

            bool exactSingleAcademicYear =
                selection.IsExactAcademicYear &&
                !TicketOperationalAnalysis.HasMultipleAcademicYears(subject, studentMessage);
            ResolutionAssessment resolution = EvaluateResolvedCondition(
                record,
                intent,
                resolutionScope,
                exactSingleAcademicYear,
                paymentRequest);
            OperationalDecision decision = EvaluateDecision(
                source,
                selection,
                topicCode,
                intent,
                applicationState,
                blockAssessment,
                contradictions,
                resolution);

            string priority = GetPriority(decision);
            string studentApplicationCategory = context.GetStudentApplicationCategoryLabel(fiscalCode);
            string participatedAcademicYears = context.GetParticipatedAcademicYears(fiscalCode);
            string operationalAcademicYear = record == null ? string.Empty : FormatAcademicYear(record.AcademicYear);
            string topicConfidence = GetTopicConfidence(source, topicCode);
            string operationalDataConfidence = GetOperationalDataConfidence(selection, applicationState);
            string decisionConfidence = GetDecisionConfidence(
                decision,
                topicConfidence,
                intent.Confidence,
                operationalDataConfidence,
                contradictions,
                blockAssessment,
                resolution);

            return new QueueItem
            {
                TicketId = string.IsNullOrWhiteSpace(ticketId) ? $"__ROW__{sourceIndex}" : ticketId,
                FiscalCode = fiscalCode,
                StudentCode = ReadString(source, "CODSTUD"),
                Subject = subject,
                StudentMessage = studentMessage,
                Topic = GetTopicLabel(topicCode),
                SecondaryTopics = secondaryTopicCode,
                Intent = TicketOperationalAnalysis.FormatIntent(intent.Intent),
                IntentSignals = JoinEvidence(
                    intent.Signals,
                    resolutionScope.ScholarshipPayments
                        ? TicketOperationalAnalysis.FormatPaymentRequestKind(paymentRequest)
                        : string.Empty),
                RequestedScopes = resolutionScope.Signals,
                ClosureChecks = resolution.CheckSummary,
                DeclaredAcademicYear = declaredAcademicYear,
                StudentApplicationCategory = studentApplicationCategory,
                ParticipatedAcademicYears = participatedAcademicYears,
                OperationalAcademicYear = operationalAcademicYear,
                RecordSelectionCriterion = selection.Criterion,
                ApplicationState = TicketOperationalAnalysis.GetApplicationStateLabel(applicationState),
                TopicConfidence = topicConfidence,
                IntentConfidence = intent.Confidence,
                OperationalDataConfidence = operationalDataConfidence,
                DecisionConfidence = decisionConfidence,
                CreationDate = creationDate,
                LastMessageDate = lastMessageDate,
                DaysOpen = daysOpen,
                Closable = GetClosableLabel(decision),
                ClosureStatus = GetClosureStatus(decision, resolution, selection),
                RequestedObject = GetRequestedObject(resolutionScope, paymentRequest),
                AcademicYearConsistency = GetAcademicYearConsistency(selection),
                NonClosureReason = GetNonClosureReason(decision, resolution),
                ResolvedCondition = resolution.Condition,
                Priority = priority,
                PriorityOrder = GetPriorityOrder(priority),
                PriorityReason = GetPriorityReason(decision, resolution),
                Decision = decision.Decision,
                RequiredAction = decision.RequiredAction,
                Reason = decision.Reason,
                ResponseCode = decision.ResponseCode,
                ResponseText = decision.ResponseText,
                Evidence = JoinEvidence(resolution.Evidence, BuildEvidence(record, topicCode, operationalAcademicYear)),
                TicketMentionsBlocks = ticketMentionsBlocks,
                StudentHasBlocks = studentHasBlocks,
                RelevantBlocks = blockAssessment.RelevantBlocks,
                NonRelevantBlocks = blockAssessment.NonRelevantBlocks,
                Contradictions = string.Join(" | ", contradictions),
                DetailSheet = GetDetailSheet(topicCode, secondaryTopicCode, resolutionScope)
            };
        }

        private static ResolutionAssessment EvaluateResolvedCondition(
            TicketOfficeRecord? record,
            TicketIntentAssessment intent,
            TicketResolutionScope scope,
            bool recordSelectionIsReliable,
            PaymentRequestKind paymentRequest)
        {
            if (!scope.HasConditions)
                return ResolutionAssessment.None;

            if (record == null)
            {
                return PendingResolution(
                    scope,
                    "DATI OPERATIVI: NON DISPONIBILI",
                    "GEN_01",
                    "Verificare codice fiscale, identità studente e domanda prima di valutare le condizioni richieste.");
            }

            // Nessun fallback (anno corrente o ultima domanda) è ammesso per una chiusura automatica.
            if (!recordSelectionIsReliable)
            {
                return PendingResolution(
                    scope,
                    "ANNO ACCADEMICO: NON IDENTIFICATO, NON ALLINEATO O MULTIPLO",
                    "GEN_06",
                    "Non chiudere automaticamente: il ticket deve riferirsi a un solo anno accademico, coincidente con il record selezionato.");
            }

            if (!IsResolutionCompatible(intent.Intent))
            {
                return PendingResolution(
                    scope,
                    "CONTENUTO: RICHIESTA NON COMPATIBILE CON CHIUSURA AUTOMATICA",
                    "GEN_04",
                    "La richiesta è informativa, tecnica, contestata o comunque non chiudibile automaticamente.");
            }

            var checks = new List<string>();
            var unresolved = new List<string>();
            var evidence = new List<string>();

            if (scope.ScholarshipPayments)
            {
                PaymentResolution payment = EvaluatePaymentResolution(record, paymentRequest);
                checks.Add(payment.CheckSummary);
                if (payment.IsResolved)
                    evidence.Add(payment.Evidence);
                else
                    unresolved.Add(payment.UnresolvedReason);
            }

            if (scope.ResidencePermitDocuments)
            {
                bool documentsWorked =
                    TicketOperationalAnalysis.AreResidencePermitDocumentsWorked(record.ResidencePermitDocuments);
                checks.Add(documentsWorked
                    ? "PERMESSO: RISOLTO - documenti 01/02/03 in status 05"
                    : $"PERMESSO: NON RISOLTO - {FormatPermitDocumentState(record.ResidencePermitDocuments)}");
                if (documentsWorked)
                    evidence.Add($"Documenti permesso in status 05: {record.ResidencePermitDocuments}");
                else
                    unresolved.Add("documenti del permesso non tutti lavorati in status 05");
            }

            if (scope.ApplicationBlocks)
            {
                bool blocksRemoved = string.IsNullOrWhiteSpace(record.Blocks);
                checks.Add(blocksRemoved
                    ? "BLOCCHI: RISOLTO - nessun blocco amministrativo presente"
                    : $"BLOCCHI: NON RISOLTO - {record.Blocks}");
                if (blocksRemoved)
                    evidence.Add("Nessun blocco amministrativo presente sulla domanda dello stesso anno");
                else
                    unresolved.Add("uno o più blocchi amministrativi risultano ancora presenti");
            }

            string checkSummary = string.Join(" | ", checks);
            if (unresolved.Count > 0)
            {
                string responseCode = GetPendingResolutionCode(scope, paymentRequest);
                return new ResolutionAssessment
                {
                    HasRequestedConditions = true,
                    RequestedScopes = scope.Signals,
                    CheckSummary = checkSummary,
                    UnresolvedConditions = string.Join("; ", unresolved),
                    ResponseCode = responseCode,
                    RequiredAction = $"Non chiudere: {string.Join("; ", unresolved)}.",
                    Reason = "La condizione richiesta per lo stesso anno accademico non risulta soddisfatta.",
                    Evidence = string.Join(" | ", evidence)
                };
            }

            string condition = GetResolvedCondition(scope, paymentRequest);
            string resolvedResponseCode = GetResolvedResponseCode(scope, paymentRequest);
            return new ResolutionAssessment
            {
                HasRequestedConditions = true,
                IsResolved = true,
                RequestedScopes = scope.Signals,
                CheckSummary = checkSummary,
                Condition = condition,
                ResponseCode = resolvedResponseCode,
                RequiredAction = "Confermare l'evidenza riferita allo stesso anno accademico e chiudere il ticket.",
                Reason = "La condizione specifica richiesta dal ticket risulta già soddisfatta sul record dello stesso anno accademico.",
                Evidence = string.Join(" | ", evidence)
            };
        }

        private static PaymentResolution EvaluatePaymentResolution(
            TicketOfficeRecord record,
            PaymentRequestKind request)
        {
            bool hasBlockingPaymentEvidence = record.HasUnclassifiedBsPaymentCodes || record.HasBsStornedPayments;
            decimal assignedAmount = record.SpecificheAmount > 0m
                ? record.SpecificheAmount
                : record.BenefitAmount;
            decimal residual = CalculateResidual(record, assignedAmount);
            decimal firstInstallment = record.BsFirstInstallmentOriginalAmount + record.BsFirstInstallmentReissueAmount;
            decimal balance = record.BsBalanceOriginalAmount + record.BsBalanceReissueAmount;
            decimal integration =
                record.BsIntegrationFirstInstallmentOriginalAmount +
                record.BsIntegrationFirstInstallmentReissueAmount +
                record.BsIntegrationBalanceOriginalAmount +
                record.BsIntegrationBalanceReissueAmount;

            return request switch
            {
                PaymentRequestKind.PRIMA_RATA => BuildPaymentResolution(
                    firstInstallment > 0m &&
                    !string.IsNullOrWhiteSpace(record.BsFirstInstallmentMandates) &&
                    !hasBlockingPaymentEvidence,
                    "PRIMA_RATA",
                    firstInstallment,
                    record.BsFirstInstallmentMandates,
                    hasBlockingPaymentEvidence),
                PaymentRequestKind.SALDO => BuildPaymentResolution(
                    balance > 0m &&
                    !string.IsNullOrWhiteSpace(record.BsBalanceMandates) &&
                    !hasBlockingPaymentEvidence,
                    "SALDO",
                    balance,
                    record.BsBalanceMandates,
                    hasBlockingPaymentEvidence),
                PaymentRequestKind.INTEGRAZIONE => BuildPaymentResolution(
                    integration > 0m &&
                    !string.IsNullOrWhiteSpace(record.BsIntegrationMandates) &&
                    !hasBlockingPaymentEvidence,
                    "INTEGRAZIONE",
                    integration,
                    record.BsIntegrationMandates,
                    hasBlockingPaymentEvidence),
                _ => BuildFullPaymentResolution(
                    assignedAmount,
                    record.BsPaidAmount,
                    residual,
                    record.BsMandates,
                    hasBlockingPaymentEvidence)
            };
        }

        private static PaymentResolution BuildFullPaymentResolution(
            decimal assignedAmount,
            decimal paidAmount,
            decimal residual,
            string mandates,
            bool hasBlockingPaymentEvidence)
        {
            bool resolved = assignedAmount > 0m &&
                            paidAmount > 0m &&
                            residual <= 0.01m &&
                            !string.IsNullOrWhiteSpace(mandates) &&
                            !hasBlockingPaymentEvidence;
            string check = resolved
                ? $"PAGAMENTO COMPLETO: RISOLTO - assegnato {FormatAmount(assignedAmount)}, pagato {FormatAmount(paidAmount)}, residuo {FormatAmount(residual)}"
                : $"PAGAMENTO COMPLETO: NON RISOLTO - assegnato {FormatAmount(assignedAmount)}, pagato {FormatAmount(paidAmount)}, residuo {FormatAmount(residual)}";
            return new PaymentResolution
            {
                IsResolved = resolved,
                CheckSummary = check,
                Evidence = resolved ? $"Mandati BS validi: {mandates}" : string.Empty,
                UnresolvedReason = hasBlockingPaymentEvidence
                    ? "pagamento BS con storni o codici non classificati"
                    : "pagamento completo della borsa non risulta effettuato con mandato valido"
            };
        }

        private static PaymentResolution BuildPaymentResolution(
            bool resolved,
            string component,
            decimal amount,
            string mandates,
            bool hasBlockingPaymentEvidence)
        {
            return new PaymentResolution
            {
                IsResolved = resolved,
                CheckSummary = resolved
                    ? $"{component}: RISOLTO - pagato {FormatAmount(amount)} con mandato {mandates}"
                    : $"{component}: NON RISOLTO - pagato {FormatAmount(amount)}, mandati {mandates}",
                Evidence = resolved ? $"Mandati {component.ToLowerInvariant()} BS validi: {mandates}" : string.Empty,
                UnresolvedReason = hasBlockingPaymentEvidence
                    ? $"{component.ToLowerInvariant()} con storni o codici non classificati"
                    : $"{component.ToLowerInvariant()} non risulta effettuato con mandato valido"
            };
        }

        private static bool IsResolutionCompatible(TicketIntent intent) =>
            intent != TicketIntent.CONTESTAZIONE &&
            intent != TicketIntent.RINUNCIA_O_RECESSO &&
            intent != TicketIntent.ERRORE_TECNICO;

        private static ResolutionAssessment PendingResolution(
            TicketResolutionScope scope,
            string checkSummary,
            string responseCode,
            string action) => new()
        {
            HasRequestedConditions = true,
            RequestedScopes = scope.Signals,
            CheckSummary = checkSummary,
            ResponseCode = responseCode,
            RequiredAction = action,
            Reason = "Le condizioni richieste dal ticket non possono essere considerate risolte automaticamente."
        };

        private static string GetResolvedCondition(
            TicketResolutionScope scope,
            PaymentRequestKind paymentRequest)
        {
            if (scope.ScholarshipPayments && !scope.ResidencePermitDocuments && !scope.ApplicationBlocks)
            {
                return paymentRequest switch
                {
                    PaymentRequestKind.PRIMA_RATA => "PRIMA_RATA_BORSA_PAGATA",
                    PaymentRequestKind.SALDO => "SALDO_BORSA_PAGATO",
                    PaymentRequestKind.INTEGRAZIONE => "INTEGRAZIONE_BORSA_PAGATA",
                    _ => "PAGAMENTO_COMPLETO_STESSO_AA"
                };
            }
            if (!scope.ScholarshipPayments && scope.ResidencePermitDocuments && !scope.ApplicationBlocks)
                return "DOCUMENTI_PERMESSO_LAVORATI_STATUS_05_STESSO_AA";
            if (!scope.ScholarshipPayments && !scope.ResidencePermitDocuments && scope.ApplicationBlocks)
                return "BLOCCO_AMMINISTRATIVO_NON_PIU_PRESENTE_STESSO_AA";
            if (!scope.ScholarshipPayments && scope.ResidencePermitDocuments && scope.ApplicationBlocks)
                return "PERMESSO_LAVORATO_E_BLOCCO_RIMOSSO_STESSO_AA";
            return "TUTTE_LE_CONDIZIONI_RICHIESTE_RISOLTE_STESSO_AA";
        }

        private static string GetResolvedResponseCode(
            TicketResolutionScope scope,
            PaymentRequestKind paymentRequest)
        {
            if (scope.ScholarshipPayments && !scope.ResidencePermitDocuments && !scope.ApplicationBlocks)
            {
                return paymentRequest switch
                {
                    PaymentRequestKind.PRIMA_RATA => "PAG_02",
                    PaymentRequestKind.SALDO => "PAG_03",
                    PaymentRequestKind.INTEGRAZIONE => "PAG_12",
                    _ => "PAG_01"
                };
            }
            if (!scope.ScholarshipPayments && scope.ResidencePermitDocuments && !scope.ApplicationBlocks)
                return "DOC_04";
            if (!scope.ScholarshipPayments && !scope.ResidencePermitDocuments && scope.ApplicationBlocks)
                return "BLO_02";
            if (!scope.ScholarshipPayments && scope.ResidencePermitDocuments && scope.ApplicationBlocks)
                return "DOC_BLO_01";
            return "GEN_08";
        }

        private static string GetPendingResolutionCode(
            TicketResolutionScope scope,
            PaymentRequestKind paymentRequest)
        {
            int count =
                (scope.ScholarshipPayments ? 1 : 0) +
                (scope.ResidencePermitDocuments ? 1 : 0) +
                (scope.ApplicationBlocks ? 1 : 0);
            if (count > 1)
                return "GEN_07";
            if (scope.ScholarshipPayments)
            {
                return paymentRequest switch
                {
                    PaymentRequestKind.PRIMA_RATA => "PAG_17",
                    PaymentRequestKind.SALDO => "PAG_18",
                    PaymentRequestKind.INTEGRAZIONE => "PAG_19",
                    _ => "PAG_15"
                };
            }
            if (scope.ResidencePermitDocuments)
                return "DOC_05";
            return "BLO_01";
        }

        private static OperationalDecision EvaluateDecision(
            DataRow source,
            TicketRecordSelection selection,
            string topicCode,
            TicketIntentAssessment intent,
            ApplicationState applicationState,
            BlockAssessment blockAssessment,
            IReadOnlyList<string> contradictions,
            ResolutionAssessment resolution)
        {
            TicketOfficeRecord? record = selection.Record;

            // Una chiusura automatica non può precedere la verifica dell'argomento.
            if (IsYes(source, "CLASSIFICAZIONE_DA_VERIFICARE") || string.IsNullOrWhiteSpace(topicCode))
            {
                return Decision(Verify,
                    "Leggere messaggio e oggetto; correggere l'argomento prima della chiusura.",
                    "La classificazione automatica non è abbastanza affidabile per proporre una chiusura.",
                    "GEN_02");
            }

            if (resolution.IsResolved)
            {
                return Decision(
                    CloseResolved,
                    resolution.RequiredAction,
                    resolution.Reason,
                    resolution.ResponseCode);
            }

            if (intent.Intent == TicketIntent.PRE_DOMANDA && record == null)
            {
                return Decision(ClosePersonalized,
                    "Predisporre un riscontro informativo senza richiedere una domanda esistente.",
                    "Il ticket è una richiesta informativa o pre-domanda e non richiede dati individuali per essere trattato.",
                    "GEN_03");
            }

            if (record == null)
            {
                return Decision(Verify,
                    "Verificare codice fiscale, identità studente e presenza di una domanda.",
                    "Non è stata trovata una domanda operativa associabile al ticket.",
                    "GEN_01");
            }

            if (resolution.HasRequestedConditions && !selection.IsExactAcademicYear)
            {
                return Decision(
                    Verify,
                    "Individuare nel ticket l'anno accademico e verificare il record dello stesso anno prima della chiusura.",
                    "La chiusura automatica richiede una corrispondenza esatta fra anno accademico del ticket e record operativo.",
                    "GEN_06");
            }

            if (intent.Intent == TicketIntent.CONTESTAZIONE ||
                intent.Intent == TicketIntent.RINUNCIA_O_RECESSO ||
                intent.Intent == TicketIntent.ERRORE_TECNICO ||
                intent.Intent == TicketIntent.ALTRO_DA_VERIFICARE)
            {
                if (intent.Intent == TicketIntent.RINUNCIA_O_RECESSO &&
                    string.Equals(topicCode, "ALLOGGIO", StringComparison.OrdinalIgnoreCase))
                {
                    return Decision(ActionRequired,
                        "Applicare la procedura di rinuncia, cessazione o check-out.",
                        "La richiesta riguarda una rinuncia o un check-out e richiede una lavorazione amministrativa dedicata.",
                        "ALL_05");
                }

                if (intent.Intent == TicketIntent.ERRORE_TECNICO ||
                    string.Equals(topicCode, "PORTALE_E_ACCESSO", StringComparison.OrdinalIgnoreCase))
                {
                    return Decision(Verify,
                        "Verificare il problema tecnico descritto e lo stato della domanda.",
                        "Il ticket riguarda un accesso o una funzionalità del portale e richiede verifica puntuale.",
                        "POR_01");
                }

                return Decision(Verify,
                    "Confrontare il testo del ticket con i dati disponibili e applicare la procedura dedicata.",
                    "Il ticket contiene una contestazione, una rinuncia oppure un intento non automatizzabile.",
                    "GEN_04");
            }

            if (resolution.HasRequestedConditions)
            {
                return Decision(
                    ActionRequired,
                    resolution.RequiredAction,
                    resolution.Reason,
                    resolution.ResponseCode);
            }

            if (blockAssessment.HasRelevantBlocks)
            {
                return Decision(ActionRequired,
                    "Individuare e gestire la causa del blocco pertinente al ticket.",
                    "La domanda presenta uno o più blocchi rilevanti per l'argomento trattato.",
                    "BLO_01");
            }

            if (applicationState != ApplicationState.TRASMESSA_O_COMPLETA &&
                RequiresSubmittedApplication(topicCode))
            {
                return Decision(ActionRequired,
                    "Verificare compilazione, trasmissione e stato effettivo della domanda.",
                    "Lo stato disponibile della domanda non consente una chiusura automatica.",
                    "DOM_01");
            }

            if (contradictions.Count > 0)
            {
                if (intent.Intent == TicketIntent.SOLLECITO &&
                    (string.Equals(topicCode, "PAGAMENTI_E_TASSE", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(topicCode, "BENEFICI_E_IMPORTI", StringComparison.OrdinalIgnoreCase)))
                {
                    return Decision(Verify,
                        "Verificare data del mandato, canale di accredito e causale prima della chiusura.",
                        "Il ticket segnala una mancata ricezione mentre risultano pagamento e mandato.",
                        "PAG_09");
                }

                return Decision(Verify,
                    "Verificare la discordanza indicata prima di predisporre o inviare il riscontro.",
                    "Il testo del ticket e i dati operativi non sono pienamente coerenti.",
                    "GEN_05");
            }

            if (intent.Intent == TicketIntent.AGGIORNAMENTO_DATI &&
                string.Equals(topicCode, "IBAN", StringComparison.OrdinalIgnoreCase))
            {
                return Decision(ActionRequired,
                    "Verificare l'autorizzazione alla variazione e i dati bancari aggiornati.",
                    "La richiesta riguarda una modifica delle coordinate di pagamento e richiede una lavorazione dedicata.",
                    "IBAN_02");
            }

            if (string.Equals(topicCode, "PAGAMENTI_E_TASSE", StringComparison.OrdinalIgnoreCase))
            {
                return Decision(
                    Verify,
                    "Rileggere il ticket e distinguere erogazioni della borsa da tasse o pagamenti effettuati dallo studente.",
                    "Il testo non contiene una richiesta riconoscibile di erogazione della borsa.",
                    "PAG_16");
            }

            return topicCode.ToUpperInvariant() switch
            {
                "BENEFICI_E_IMPORTI" => EvaluateBenefits(record),
                "ALLOGGIO" => EvaluateHousing(record),
                "MENSA" => EvaluateCanteen(record),
                "DOCUMENTI_E_PERMESSI" => EvaluateDocuments(record),
                "IBAN" => EvaluateIban(record),
                "GRADUATORIE" => EvaluateRankings(record),
                "MOBILITA" => EvaluateMobility(record),
                "ISCRIZIONE_E_CARRIERA" => Decision(Verify,
                    "Verificare carriera, anno di corso, crediti e precedenti partecipazioni.",
                    "La richiesta riguarda dati di carriera che richiedono una verifica puntuale.",
                    "CAR_01"),
                _ => Decision(Verify,
                    "Leggere il ticket e assegnare l'ufficio o argomento corretto.",
                    "L'argomento non rientra nelle regole operative automatiche.",
                    "ALT_01")
            };
        }

        private static OperationalDecision EvaluatePayments(TicketOfficeRecord record)
        {
            decimal assignedAmount = record.SpecificheAmount > 0m ? record.SpecificheAmount : record.BenefitAmount;
            decimal residual = CalculateResidual(record, assignedAmount);

            if (record.BsOutcome == "0")
                return Decision(ClosePersonalized, "Predisporre riscontro con l'esito disponibile.", "La domanda risulta esclusa dalla borsa.", "PAG_07");

            if (record.HasUnclassifiedBsPaymentCodes)
            {
                return Decision(Verify,
                    "Verificare i codici BS non classificati prima di calcolare importi o residui.",
                    "Sono presenti movimenti BS con codici non inclusi nella mappa BSP/BSS/BSI; tali importi non entrano nelle somme automatiche.",
                    "PAG_11");
            }

            if (record.HasBsStornedPayments && record.BsPaidAmount <= 0m)
            {
                return Decision(ActionRequired,
                    "Verificare la causa dello storno e l'eventuale riemissione del pagamento.",
                    "Sono presenti pagamenti BS ritirati dall'azienda: risultano stornati e non devono essere considerati accreditati allo studente.",
                    "PAG_10");
            }

            if (record.BenefitAmount > 0m && record.SpecificheAmount > 0m &&
                Math.Abs(record.BenefitAmount - record.SpecificheAmount) >= 0.01m)
            {
                return Decision(ActionRequired, "Verificare coerenza tra esito e impegni contabili.", "L'importo dell'esito differisce dalle specifiche degli impegni.", "BEN_02");
            }

            if (string.IsNullOrWhiteSpace(record.Iban) &&
                (record.BsOutcome == "2" || assignedAmount > record.BsPaidAmount + 0.01m))
            {
                return Decision(DataMissing, "Richiedere o verificare l'IBAN e la modalità di pagamento.", "Non risulta un IBAN per una pratica con pagamento potenzialmente dovuto.", "PAG_04");
            }

            if (record.BsOutcome == "2" && record.BsPaidAmount <= 0m)
                return Decision(ActionRequired, "Verificare iter contabile, impegni e mandati.", "La domanda risulta vincitrice ma non emergono pagamenti BS.", "PAG_05");

            if (assignedAmount > 0m &&
                residual <= 0.01m &&
                !string.IsNullOrWhiteSpace(record.BsMandates))
            {
                return Decision(
                    CloseResolved,
                    "Confermare mandato e importo e chiudere il ticket.",
                    "L'importo assegnato risulta interamente pagato, al netto di reversali e detrazioni.",
                    "PAG_01");
            }

            if (record.BsPaidAmount > 0m && residual > 0.01m)
                return Decision(ActionRequired, "Verificare rate, residuo, reversali e detrazioni.", "Risulta un pagamento parziale con residuo stimato.", "PAG_06");

            return Decision(Verify, "Confrontare la richiesta con esito, importi e pagamenti BS disponibili.", "I dati contabili non consentono una proposta di chiusura automatica.", "PAG_08");
        }

        private static OperationalDecision EvaluateBenefits(TicketOfficeRecord record)
        {
            if (record.BsOutcome == "0")
                return Decision(ClosePersonalized, "Predisporre riscontro con l'esito disponibile.", "La domanda risulta esclusa dalla borsa.", "PAG_07");

            if (record.BenefitAmount > 0m && record.SpecificheAmount > 0m &&
                Math.Abs(record.BenefitAmount - record.SpecificheAmount) >= 0.01m)
            {
                return Decision(ActionRequired, "Verificare coerenza tra esito e impegni contabili.", "L'importo dell'esito differisce dalle specifiche degli impegni.", "BEN_02");
            }

            if (record.BsOutcome == "2" && record.BsPaidAmount <= 0m && record.BenefitAmount > 0m)
                return Decision(ActionRequired, "Verificare iter contabile, impegni e mandati.", "La domanda risulta vincitrice senza pagamenti BS registrati.", "PAG_05");

            return Decision(ClosePersonalized, "Confrontare testo del ticket con esito e importi estratti.", "Sono disponibili dati su esito o importi della domanda.", "BEN_01");
        }

        private static OperationalDecision EvaluateHousing(TicketOfficeRecord record)
        {
            if (record.HasOpenDomicileRequest)
                return Decision(ActionRequired, "Verificare lavorazione dell'istanza di domicilio.", "Risulta un'istanza di domicilio ancora aperta.", "ALL_01");
            if (string.IsNullOrWhiteSpace(record.ContractSeries))
                return Decision(DataMissing, "Verificare presenza, validità o integrazione del contratto.", "Non risulta un contratto di domicilio associato alla domanda.", "ALL_02");
            if (record.PaOutcome == "0")
                return Decision(ClosePersonalized, "Predisporre riscontro con esito alloggio disponibile.", "La domanda risulta esclusa dal posto alloggio.", "ALL_03");
            return Decision(ClosePersonalized, "Confrontare richiesta, esito alloggio e dati di domicilio.", "Sono disponibili dati su alloggio, domicilio o contratto.", "ALL_04");
        }

        private static OperationalDecision EvaluateCanteen(TicketOfficeRecord record) => record.CanteenMonetizationGranted
            ? Decision(ClosePersonalized, "Confrontare richiesta con monetizzazione e pagamenti BS disponibili.", "La monetizzazione mensa risulta concessa.", "MEN_01")
            : Decision(ClosePersonalized, "Predisporre riscontro sulla monetizzazione non concessa.", "La monetizzazione mensa non risulta concessa per la domanda selezionata.", "MEN_02");

        private static OperationalDecision EvaluateDocuments(TicketOfficeRecord record)
        {
            if (string.IsNullOrWhiteSpace(record.ResidencePermitDocuments))
                return Decision(DataMissing, "Verificare allegati e richiedere eventuale integrazione.", "Non risultano documenti del permesso di soggiorno.", "DOC_01");
            if (record.Isee <= 0m)
                return Decision(DataMissing, "Verificare DSU, acquisizione ISEE e possibili integrazioni.", "L'ISEE DSU non risulta valorizzato.", "DOC_02");
            return Decision(ClosePersonalized, "Controllare stato dei documenti e dati economici dichiarati.", "I documenti e i dati economici risultano disponibili per la domanda selezionata.", "DOC_03");
        }

        private static OperationalDecision EvaluateIban(TicketOfficeRecord record) => string.IsNullOrWhiteSpace(record.Iban)
            ? Decision(DataMissing, "Richiedere o verificare l'IBAN e la modalità di pagamento.", "Non risulta un IBAN associato alla domanda.", "PAG_04")
            : Decision(ClosePersonalized, "Verificare eventuali blocchi e mandati prima dell'invio.", "L'IBAN risulta presente nei dati operativi.", "IBAN_01");

        private static OperationalDecision EvaluateRankings(TicketOfficeRecord record) => string.IsNullOrWhiteSpace(record.FinalRankings)
            ? Decision(ActionRequired, "Verificare pubblicazione, caricamento o stato del procedimento.", "Non risulta una graduatoria definitiva per la domanda selezionata.", "GRA_02")
            : Decision(ClosePersonalized, "Confrontare beneficio richiesto, esito e graduatoria definitiva.", "È disponibile almeno una graduatoria definitiva.", "GRA_01");

        private static OperationalDecision EvaluateMobility(TicketOfficeRecord record)
        {
            if (!record.MobilityBenefitRequested)
                return Decision(ClosePersonalized, "Confrontare richiesta dello studente con i benefici registrati.", "Il contributo di mobilità non risulta tra i benefici richiesti.", "MOB_01");
            if (string.IsNullOrWhiteSpace(record.CiOutcome) && record.CiAmount <= 0m)
                return Decision(Verify, "Verificare richiesta, esito CI e documentazione collegata.", "Il contributo di mobilità risulta richiesto ma non emergono esito o importo CI.", "MOB_02");
            return Decision(ClosePersonalized, "Confrontare esito e importo CI con quanto dichiarato nel ticket.", "Sono disponibili dati sul contributo mobilità richiesto.", "MOB_03");
        }

        private static OperationalDecision Decision(string decision, string action, string reason, string responseCode) => new()
        {
            Decision = decision,
            RequiredAction = action,
            Reason = reason,
            ResponseCode = responseCode,
            ResponseText = GetResponseText(responseCode)
        };

        private static string GetResponseText(string code) =>
            ResponseTexts.Value.TryGetValue(code, out string? response)
                ? response
                : string.Empty;

        private static bool RequiresSubmittedApplication(string topicCode)
        {
            string topic = topicCode?.ToUpperInvariant() ?? string.Empty;
            return topic != "PORTALE_E_ACCESSO" && topic != "ALTRO";
        }

        private static string GetClosureStatus(
            OperationalDecision decision,
            ResolutionAssessment resolution,
            TicketRecordSelection selection)
        {
            if (resolution.IsResolved && decision.Decision.StartsWith(CloseResolved, StringComparison.OrdinalIgnoreCase))
                return "CHIUDIBILE_EVIDENZA_FORTE";
            if (resolution.HasRequestedConditions && !selection.IsExactAcademicYear)
                return "NON_VALUTABILE_AA";
            if (resolution.HasRequestedConditions && !resolution.IsResolved)
                return "NON_RISOLTO";
            if (decision.Decision.StartsWith(ClosePersonalized, StringComparison.OrdinalIgnoreCase))
                return "FUORI_PERIMETRO_RISCONTRO_ASSISTITO";
            if (decision.Decision.StartsWith(ActionRequired, StringComparison.OrdinalIgnoreCase) ||
                decision.Decision.StartsWith(DataMissing, StringComparison.OrdinalIgnoreCase))
                return "NON_CHIUDIBILE";
            return "DA_VERIFICARE";
        }

        private static string GetRequestedObject(
            TicketResolutionScope scope,
            PaymentRequestKind paymentRequest)
        {
            var values = new List<string>();
            if (scope.ScholarshipPayments)
                values.Add($"Pagamento borsa {TicketOperationalAnalysis.FormatPaymentRequestKind(paymentRequest)}");
            if (scope.ResidencePermitDocuments)
                values.Add("Documenti permesso di soggiorno");
            if (scope.ApplicationBlocks)
                values.Add("Blocco amministrativo della domanda");
            return values.Count == 0
                ? "Nessun oggetto di chiusura automatica rilevato"
                : string.Join(" + ", values);
        }

        private static string GetAcademicYearConsistency(TicketRecordSelection selection)
        {
            if (!selection.HasDeclaredAcademicYear)
                return "AA_NON_IDENTIFICATO_NEL_TICKET";
            if (!selection.HasRecord)
                return "RECORD_OPERATIVO_ASSENTE";
            return selection.IsExactAcademicYear
                ? "AA_COINCIDENTE"
                : "AA_NON_COINCIDENTE";
        }

        private static string GetNonClosureReason(
            OperationalDecision decision,
            ResolutionAssessment resolution)
        {
            if (resolution.IsResolved && decision.Decision.StartsWith(CloseResolved, StringComparison.OrdinalIgnoreCase))
                return string.Empty;
            if (!string.IsNullOrWhiteSpace(resolution.UnresolvedConditions))
                return resolution.UnresolvedConditions;
            return decision.Reason;
        }

        private static string GetClosableLabel(OperationalDecision decision)
        {
            if (decision.Decision.StartsWith(CloseResolved, StringComparison.OrdinalIgnoreCase))
                return "SI";
            if (decision.Decision.StartsWith(CloseStandard, StringComparison.OrdinalIgnoreCase))
                return "DA_VERIFICARE";
            if (decision.Decision.StartsWith(Verify, StringComparison.OrdinalIgnoreCase))
                return "DA_VERIFICARE";
            return "NO";
        }

        private static string GetPriority(OperationalDecision decision)
        {
            if (decision.Decision.StartsWith(CloseResolved, StringComparison.OrdinalIgnoreCase))
                return "P1";
            if (decision.Decision.StartsWith(CloseStandard, StringComparison.OrdinalIgnoreCase))
                return "P2";
            if (decision.Decision.StartsWith(ActionRequired, StringComparison.OrdinalIgnoreCase) ||
                decision.Decision.StartsWith(DataMissing, StringComparison.OrdinalIgnoreCase))
                return "P3";
            return "P4";
        }

        private static string GetPriorityReason(
            OperationalDecision decision,
            ResolutionAssessment resolution)
        {
            if (resolution.IsResolved)
                return $"Situazione già risolta sullo stesso anno: {resolution.Condition}";
            if (decision.Decision.StartsWith(CloseStandard, StringComparison.OrdinalIgnoreCase))
                return "Controllo rapido prima della chiusura";
            if (decision.Decision.StartsWith(ClosePersonalized, StringComparison.OrdinalIgnoreCase))
                return "Riscontro assistito: non è una chiusura automatica";
            if (decision.Decision.StartsWith(ActionRequired, StringComparison.OrdinalIgnoreCase))
                return "Ticket non chiudibile: azione operativa necessaria";
            if (decision.Decision.StartsWith(DataMissing, StringComparison.OrdinalIgnoreCase))
                return "Ticket non chiudibile: dato o documento mancante";
            return "Classificazione, anno accademico o situazione da verificare manualmente";
        }

        private static int GetPriorityOrder(string priority) => priority switch
        {
            "P1" => 1,
            "P2" => 2,
            "P3" => 3,
            _ => 4
        };

        private static string GetTopicConfidence(DataRow row, string topicCode)
        {
            if (IsYes(row, "CLASSIFICAZIONE_DA_VERIFICARE") || string.IsNullOrWhiteSpace(topicCode))
                return "BASSA";
            return "ORDINARIA";
        }

        private static string GetOperationalDataConfidence(TicketRecordSelection selection, ApplicationState applicationState)
        {
            if (!selection.HasRecord || applicationState == ApplicationState.SCONOSCIUTO)
                return "BASSA";
            if (!selection.IsExactAcademicYear)
                return "BASSA";
            return "ALTA";
        }

        private static string GetDecisionConfidence(
            OperationalDecision decision,
            string topicConfidence,
            string intentConfidence,
            string operationalDataConfidence,
            IReadOnlyCollection<string> contradictions,
            BlockAssessment blocks,
            ResolutionAssessment resolution)
        {
            if (resolution.IsResolved &&
                contradictions.Count == 0 &&
                !string.Equals(operationalDataConfidence, "BASSA", StringComparison.OrdinalIgnoreCase))
            {
                return string.Equals(topicConfidence, "BASSA", StringComparison.OrdinalIgnoreCase)
                    ? "MEDIA"
                    : "ALTA";
            }

            if (contradictions.Count > 0 ||
                string.Equals(topicConfidence, "BASSA", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(intentConfidence, "BASSA", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(operationalDataConfidence, "BASSA", StringComparison.OrdinalIgnoreCase))
            {
                return "BASSA";
            }

            if ((decision.Decision.StartsWith(CloseResolved, StringComparison.OrdinalIgnoreCase) ||
                 decision.Decision.StartsWith(CloseStandard, StringComparison.OrdinalIgnoreCase)) &&
                !blocks.HasRelevantBlocks &&
                !string.Equals(intentConfidence, "BASSA", StringComparison.OrdinalIgnoreCase) &&
                string.Equals(operationalDataConfidence, "ALTA", StringComparison.OrdinalIgnoreCase))
            {
                return "ALTA";
            }

            return "MEDIA";
        }

        private static string BuildEvidence(TicketOfficeRecord? record, string topicCode, string operationalAcademicYear)
        {
            if (record == null)
                return "Nessuna domanda operativa trovata per il codice fiscale.";

            var values = new List<string>();
            if (!string.IsNullOrWhiteSpace(operationalAcademicYear))
                values.Add($"AA record {operationalAcademicYear}");
            if (!string.IsNullOrWhiteSpace(record.ApplicationNumber))
                values.Add($"domanda {record.ApplicationNumber}");

            switch (topicCode.ToUpperInvariant())
            {
                case "PAGAMENTI_E_TASSE":
                case "BENEFICI_E_IMPORTI":
                    AddIfNotEmpty(values, "esito BS", FormatOutcome(record.BsOutcome));
                    values.Add($"assegnato {FormatAmount(record.BenefitAmount)}");
                    values.Add($"pagato BS valido {FormatAmount(record.BsPaidAmount)}");
                    values.Add($"BSP prima rata {FormatAmount(record.BsFirstInstallmentOriginalAmount + record.BsFirstInstallmentReissueAmount)}");
                    values.Add($"BSS saldo {FormatAmount(record.BsBalanceOriginalAmount + record.BsBalanceReissueAmount)}");
                    values.Add($"BSI integrazioni {FormatAmount(record.BsIntegrationFirstInstallmentOriginalAmount + record.BsIntegrationFirstInstallmentReissueAmount + record.BsIntegrationBalanceOriginalAmount + record.BsIntegrationBalanceReissueAmount)}");
                    if (record.HasBsStornedPayments)
                        values.Add($"BS stornati/non accreditati {FormatAmount(record.BsStornedAmount)}");
                    if (record.HasUnclassifiedBsPaymentCodes)
                        AddIfNotEmpty(values, "codici BS non classificati", record.BsUnclassifiedPaymentTypes);
                    if (record.SpecificheAmount > 0m)
                        values.Add($"impegni {FormatAmount(record.SpecificheAmount)}");
                    AddIfNotEmpty(values, "mandati BS validi", record.BsMandates);
                    break;
                case "ALLOGGIO":
                    AddIfNotEmpty(values, "esito PA", FormatOutcome(record.PaOutcome));
                    AddIfNotEmpty(values, "domicilio", record.DomicileMunicipality);
                    if (record.HasOpenDomicileRequest)
                        values.Add("istanza domicilio aperta");
                    break;
                case "DOCUMENTI_E_PERMESSI":
                    AddIfNotEmpty(values, "documenti", record.ResidencePermitDocuments);
                    values.Add($"ISEE {FormatAmount(record.Isee)}");
                    break;
                case "IBAN":
                    AddIfNotEmpty(values, "IBAN", record.Iban);
                    AddIfNotEmpty(values, "mandati BS", record.BsMandates);
                    break;
                case "GRADUATORIE":
                    AddIfNotEmpty(values, "graduatorie definitive", record.FinalRankings);
                    break;
                case "MOBILITA":
                    values.Add(record.MobilityBenefitRequested ? "contributo mobilità richiesto" : "contributo mobilità non richiesto");
                    AddIfNotEmpty(values, "esito CI", FormatOutcome(record.CiOutcome));
                    break;
                case "MENSA":
                    values.Add(record.CanteenMonetizationGranted ? "monetizzazione concessa" : "monetizzazione non concessa");
                    break;
                default:
                    AddIfNotEmpty(values, "sede", record.StudyLocation);
                    AddIfNotEmpty(values, "esito BS", FormatOutcome(record.BsOutcome));
                    break;
            }

            if (!string.IsNullOrWhiteSpace(record.Blocks))
                AddIfNotEmpty(values, "blocchi", Truncate(record.Blocks, 120));

            return string.Join("; ", values.Where(value => !string.IsNullOrWhiteSpace(value)));
        }

        private static IEnumerable<(DataRow Row, int Index)> GetDistinctTicketRows(DataTable source)
        {
            if (!source.Columns.Contains("ID_TICKET"))
                return source.AsEnumerable().Select((row, index) => (row, index));

            return source.AsEnumerable()
                .Select((row, index) => (Row: row, Index: index))
                .GroupBy(item =>
                {
                    string ticketId = ReadString(item.Row, "ID_TICKET");
                    return string.IsNullOrWhiteSpace(ticketId) ? $"__ROW__{item.Index}" : ticketId;
                }, StringComparer.OrdinalIgnoreCase)
                .Select(group => group.First());
        }

        private static DataTable CreateStudentCategorySummaryTable()
        {
            var result = new DataTable();
            result.Columns.Add("CATEGORIA_DOMANDE_STUDENTE", typeof(string));
            result.Columns.Add("CODFISC", typeof(string));
            result.Columns.Add("CODSTUD", typeof(string));
            result.Columns.Add("ANNI_DOMANDE_RILEVATI", typeof(string));
            result.Columns.Add("NUMERO_TICKET", typeof(int));
            result.Columns.Add("TICKET_P1", typeof(int));
            result.Columns.Add("TICKET_CHIUDIBILI", typeof(int));
            result.Columns.Add("TICKET_DA_VERIFICARE", typeof(int));
            result.Columns.Add("TICKET_AZIONE_OPERATIVA", typeof(int));
            result.Columns.Add("ALMENO_UN_TICKET_RIGUARDA_BLOCCHI", typeof(string));
            result.Columns.Add("STUDENTE_HA_BLOCCHI", typeof(string));
            result.Columns.Add("PRIORITA_MASSIMA", typeof(string));
            result.Columns.Add("ID_TICKET_PRIORITARIO", typeof(string));
            result.Columns.Add("OGGETTO_TICKET_PRIORITARIO", typeof(string));
            result.Columns.Add("DECISIONE_PROPOSTA_TICKET_PRIORITARIO", typeof(string));
            result.Columns.Add("FOGLIO_DETTAGLIO", typeof(string));
            result.Columns.Add("DATA_APERTURA_PIU_VECCHIA", typeof(DateTime));
            return result;
        }

        private static int? ReadNullableInt(DataRow row, string columnName)
        {
            if (!row.Table.Columns.Contains(columnName) || row[columnName] == DBNull.Value)
                return null;
            return int.TryParse(ReadString(row, columnName), NumberStyles.Integer, ItalianCulture, out int value)
                ? value
                : null;
        }

        private static DateTime? ReadNullableDate(DataRow row, string columnName)
        {
            if (!row.Table.Columns.Contains(columnName))
                return null;
            object value = row[columnName];
            if (value == null || value == DBNull.Value)
                return null;
            if (value is DateTime date)
                return date;
            return DateTime.TryParse(Convert.ToString(value, ItalianCulture), ItalianCulture, DateTimeStyles.AllowWhiteSpaces, out DateTime parsed)
                ? parsed
                : null;
        }

        private static DataTable CreateQueueTable()
        {
            var result = new DataTable();
            result.Columns.Add("CHIUDIBILE", typeof(string));
            result.Columns.Add("STATO_CHIUDIBILITA", typeof(string));
            result.Columns.Add("OGGETTO_RICHIESTO", typeof(string));
            result.Columns.Add("AA_COERENZA", typeof(string));
            result.Columns.Add("MOTIVO_NON_CHIUSURA", typeof(string));
            result.Columns.Add("AMBITI_RICHIESTI", typeof(string));
            result.Columns.Add("ESITO_CONTROLLI_CHIUSURA", typeof(string));
            result.Columns.Add("CONDIZIONE_RISOLTA", typeof(string));
            result.Columns.Add("PRIORITA", typeof(string));
            result.Columns.Add("MOTIVO_PRIORITA", typeof(string));
            result.Columns.Add("DECISIONE_PROPOSTA", typeof(string));
            result.Columns.Add("AZIONE_RICHIESTA", typeof(string));
            result.Columns.Add("MOTIVO_DECISIONE", typeof(string));
            result.Columns.Add("CODICE_RISPOSTA", typeof(string));
            result.Columns.Add("TESTO_RISCONTRO_BASE", typeof(string));
            result.Columns.Add("EVIDENZE_CHIAVE", typeof(string));
            result.Columns.Add("TICKET_RIGUARDA_BLOCCHI", typeof(string));
            result.Columns.Add("STUDENTE_HA_BLOCCHI", typeof(string));
            result.Columns.Add("BLOCCHI_RILEVANTI", typeof(string));
            result.Columns.Add("BLOCCHI_NON_PERTINENTI", typeof(string));
            result.Columns.Add("CONTRADDIZIONI_RILEVATE", typeof(string));
            result.Columns.Add("FOGLIO_DETTAGLIO", typeof(string));
            result.Columns.Add("ID_TICKET", typeof(string));
            result.Columns.Add("ETA_TICKET_GIORNI", typeof(int));
            result.Columns.Add("DATA_APERTURA", typeof(DateTime));
            result.Columns.Add("DATA_ULTIMO_MESSAGGIO", typeof(DateTime));
            result.Columns.Add("ARGOMENTO", typeof(string));
            result.Columns.Add("ARGOMENTI_SECONDARI", typeof(string));
            result.Columns.Add("INTENTO_RICHIESTA", typeof(string));
            result.Columns.Add("SEGNALI_INTENTO", typeof(string));
            result.Columns.Add("AA_DICHIARATO_TICKET", typeof(string));
            result.Columns.Add("CATEGORIA_DOMANDE_STUDENTE", typeof(string));
            result.Columns.Add("ANNI_DOMANDE_RILEVATI", typeof(string));
            result.Columns.Add("AA_RECORD_OPERATIVO", typeof(string));
            result.Columns.Add("CRITERIO_SELEZIONE_RECORD", typeof(string));
            result.Columns.Add("STATO_DOMANDA_INTERPRETATO", typeof(string));
            result.Columns.Add("CONFIDENZA_ARGOMENTO", typeof(string));
            result.Columns.Add("CONFIDENZA_INTENTO", typeof(string));
            result.Columns.Add("CONFIDENZA_DATI_OPERATIVI", typeof(string));
            result.Columns.Add("CONFIDENZA_DECISIONE", typeof(string));
            result.Columns.Add("CODFISC", typeof(string));
            result.Columns.Add("CODSTUD", typeof(string));
            result.Columns.Add("OGGETTO", typeof(string));
            result.Columns.Add("PRIMO_MSG_STUDENTE", typeof(string));
            result.Columns.Add("STATO_LAVORAZIONE", typeof(string));
            result.Columns.Add("DECISIONE_OPERATORE", typeof(string));
            result.Columns.Add("ASSEGNATARIO", typeof(string));
            result.Columns.Add("NOTA_OPERATORE", typeof(string));
            result.Columns.Add("DATA_LAVORAZIONE", typeof(DateTime));
            result.Columns.Add("ESITO_INVIATO", typeof(string));
            return result;
        }

        private static void AddMetric(DataTable table, string section, string indicator, int value)
        {
            DataRow row = table.NewRow();
            row["SEZIONE"] = section;
            row["INDICATORE"] = indicator;
            row["VALORE"] = value;
            table.Rows.Add(row);
        }

        private static void AddRule(DataTable table, string code, string caseDescription, string decision, string action, string response)
        {
            DataRow row = table.NewRow();
            row["CODICE_RISPOSTA"] = code;
            row["CASO"] = caseDescription;
            row["DECISIONE_PROPOSTA"] = decision;
            row["AZIONE_RICHIESTA"] = action;
            row["RISCONTRO_BASE"] = response;
            table.Rows.Add(row);
        }

        private static int CountByPrefix(DataTable table, string columnName, string prefix) => table.AsEnumerable().Count(row =>
            ReadString(row, columnName).StartsWith(prefix, StringComparison.OrdinalIgnoreCase));

        private static int CountExact(DataTable table, string columnName, string expected) => table.AsEnumerable().Count(row =>
            string.Equals(ReadString(row, columnName), expected, StringComparison.OrdinalIgnoreCase));

        private static int CountNotEmpty(DataTable table, string columnName) => table.AsEnumerable().Count(row =>
            !string.IsNullOrWhiteSpace(ReadString(row, columnName)));

        private static int CountContains(DataTable table, string columnName, string expected) => table.AsEnumerable().Count(row =>
            ReadString(row, columnName).IndexOf(expected, StringComparison.OrdinalIgnoreCase) >= 0);

        private static int CountPaymentResolved(DataTable table) => table.AsEnumerable().Count(row =>
        {
            string condition = ReadString(row, "CONDIZIONE_RISOLTA");
            return string.Equals(condition, "PAGAMENTO_COMPLETO_STESSO_AA", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(condition, "PRIMA_RATA_BORSA_PAGATA", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(condition, "SALDO_BORSA_PAGATO", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(condition, "INTEGRAZIONE_BORSA_PAGATA", StringComparison.OrdinalIgnoreCase);
        });

        private static void AddIfNotEmpty(List<string> values, string label, string value)
        {
            if (!string.IsNullOrWhiteSpace(value))
                values.Add($"{label}: {value}");
        }

        private static string JoinEvidence(params string[] values) =>
            string.Join(
                " | ",
                values.Where(value => !string.IsNullOrWhiteSpace(value))
                    .Select(value => value.Trim()));

        private static string FormatPermitDocumentState(string value) =>
            string.IsNullOrWhiteSpace(value)
                ? "documenti non rilevati"
                : $"stati rilevati: {value}";

        private static decimal CalculateResidual(TicketOfficeRecord record, decimal assignedAmount) => Math.Max(
            0m,
            assignedAmount - record.BsPaidAmount + record.BsReversalAmount - record.DeductionAmount);

        private static string GetTopicLabel(string topicCode) => topicCode.ToUpperInvariant() switch
        {
            "PAGAMENTI_E_TASSE" => "Pagamenti e tasse",
            "BENEFICI_E_IMPORTI" => "Benefici e importi",
            "ALLOGGIO" => "Alloggio",
            "MENSA" => "Mensa",
            "DOCUMENTI_E_PERMESSI" => "Documenti e permessi",
            "IBAN" => "IBAN",
            "GRADUATORIE" => "Graduatorie",
            "MOBILITA" => "Mobilità",
            "PORTALE_E_ACCESSO" => "Portale e accesso",
            "ISCRIZIONE_E_CARRIERA" => "Carriere",
            _ => "Altro da verificare"
        };

        private static string GetDetailSheet(
            string topicCode,
            string secondaryTopicCode,
            TicketResolutionScope scope)
        {
            if (scope.ResidencePermitDocuments)
                return "14_Documenti e permessi";

            if (scope.ScholarshipPayments)
                return "10_Pagamenti";

            if (scope.ApplicationBlocks)
            {
                if (string.Equals(topicCode, "DOCUMENTI_E_PERMESSI", StringComparison.OrdinalIgnoreCase) ||
                    SecondaryTopicContains(secondaryTopicCode, "PERMESSO"))
                    return "14_Documenti e permessi";

                if (string.Equals(topicCode, "PAGAMENTI_E_TASSE", StringComparison.OrdinalIgnoreCase))
                    return "10_Pagamenti";
                if (string.Equals(topicCode, "BENEFICI_E_IMPORTI", StringComparison.OrdinalIgnoreCase))
                    return "11_Benefici e importi";
                if (string.Equals(topicCode, "ISCRIZIONE_E_CARRIERA", StringComparison.OrdinalIgnoreCase))
                    return "15_Carriere";
            }

            return topicCode.ToUpperInvariant() switch
            {
                "PAGAMENTI_E_TASSE" => "10_Pagamenti",
                "BENEFICI_E_IMPORTI" => "11_Benefici e importi",
                "ALLOGGIO" => "12_Alloggio",
                "MENSA" => "13_Mensa",
                "DOCUMENTI_E_PERMESSI" => "14_Documenti e permessi",
                "ISCRIZIONE_E_CARRIERA" => "15_Carriere",
                "GRADUATORIE" => "16_Graduatorie",
                "MOBILITA" => "17_Mobilita",
                "IBAN" => "18_IBAN",
                "PORTALE_E_ACCESSO" => "19_Portale e accesso",
                _ => "20_Altro da verificare"
            };
        }

        private static bool SecondaryTopicContains(string secondaryTopicCode, string expected)
        {
            if (string.IsNullOrWhiteSpace(secondaryTopicCode))
                return false;

            return secondaryTopicCode
                .Split('|', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Any(topic => string.Equals(topic, expected, StringComparison.OrdinalIgnoreCase));
        }

        private static string GetDetailSheet(string topicCode) => topicCode.ToUpperInvariant() switch
        {
            "PAGAMENTI_E_TASSE" => "10_Pagamenti",
            "BENEFICI_E_IMPORTI" => "11_Benefici e importi",
            "ALLOGGIO" => "12_Alloggio",
            "MENSA" => "13_Mensa",
            "DOCUMENTI_E_PERMESSI" => "14_Documenti e permessi",
            "ISCRIZIONE_E_CARRIERA" => "15_Carriere",
            "GRADUATORIE" => "16_Graduatorie",
            "MOBILITA" => "17_Mobilita",
            "IBAN" => "18_IBAN",
            "PORTALE_E_ACCESSO" => "19_Portale e accesso",
            _ => "20_Altro da verificare"
        };

        private static DateTime? ReadDate(DataRow row, params string[] candidates)
        {
            foreach (string columnName in candidates)
            {
                if (!row.Table.Columns.Contains(columnName))
                    continue;
                object value = row[columnName];
                if (value == null || value == DBNull.Value)
                    continue;
                if (value is DateTime dateValue)
                    return dateValue;
                string text = Convert.ToString(value, ItalianCulture)?.Trim() ?? string.Empty;
                if (DateTime.TryParse(text, ItalianCulture, DateTimeStyles.AllowWhiteSpaces, out DateTime parsed) ||
                    DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out parsed))
                {
                    return parsed;
                }
            }
            return null;
        }

        private static bool IsYes(DataRow row, string columnName)
        {
            string value = ReadString(row, columnName);
            return string.Equals(value, "SI", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(value, "TRUE", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(value, "1", StringComparison.OrdinalIgnoreCase);
        }

        private static string ReadString(DataRow row, string columnName)
        {
            if (!row.Table.Columns.Contains(columnName))
                return string.Empty;
            object value = row[columnName];
            return value == null || value == DBNull.Value
                ? string.Empty
                : Convert.ToString(value, ItalianCulture)?.Trim() ?? string.Empty;
        }

        private static string FormatAcademicYear(int? value)
        {
            if (!value.HasValue)
                return string.Empty;
            string raw = value.Value.ToString(CultureInfo.InvariantCulture);
            return raw.Length == 8 ? $"{raw[..4]}/{raw[4..]}" : raw;
        }

        private static string FormatOutcome(string outcome) => outcome switch
        {
            "0" => "Escluso",
            "1" => "Idoneo",
            "2" => "Vincitore",
            _ => outcome ?? string.Empty
        };

        private static string FormatAmount(decimal amount) => amount.ToString("N2", ItalianCulture);

        private static string Truncate(string value, int maxLength)
        {
            if (string.IsNullOrWhiteSpace(value) || value.Length <= maxLength)
                return value ?? string.Empty;
            return value[..Math.Max(0, maxLength - 3)] + "...";
        }

        private sealed class OperationalDecision
        {
            public string Decision { get; init; } = string.Empty;
            public string RequiredAction { get; init; } = string.Empty;
            public string Reason { get; init; } = string.Empty;
            public string ResponseCode { get; init; } = string.Empty;
            public string ResponseText { get; init; } = string.Empty;
        }

        private sealed class PaymentResolution
        {
            public bool IsResolved { get; init; }
            public string CheckSummary { get; init; } = string.Empty;
            public string Evidence { get; init; } = string.Empty;
            public string UnresolvedReason { get; init; } = string.Empty;
        }

        private sealed class ResolutionAssessment
        {
            public static ResolutionAssessment None { get; } = new();

            public bool HasRequestedConditions { get; init; }
            public bool IsResolved { get; init; }
            public string RequestedScopes { get; init; } = string.Empty;
            public string CheckSummary { get; init; } = string.Empty;
            public string UnresolvedConditions { get; init; } = string.Empty;
            public string Condition { get; init; } = string.Empty;
            public string ResponseCode { get; init; } = string.Empty;
            public string RequiredAction { get; init; } = string.Empty;
            public string Reason { get; init; } = string.Empty;
            public string Evidence { get; init; } = string.Empty;
        }

        private sealed class QueueItem
        {
            public string TicketId { get; init; } = string.Empty;
            public string FiscalCode { get; init; } = string.Empty;
            public string StudentCode { get; init; } = string.Empty;
            public string Subject { get; init; } = string.Empty;
            public string StudentMessage { get; init; } = string.Empty;
            public string Topic { get; init; } = string.Empty;
            public string SecondaryTopics { get; init; } = string.Empty;
            public string Intent { get; init; } = string.Empty;
            public string IntentSignals { get; init; } = string.Empty;
            public string DeclaredAcademicYear { get; init; } = string.Empty;
            public string StudentApplicationCategory { get; init; } = string.Empty;
            public string ParticipatedAcademicYears { get; init; } = string.Empty;
            public string OperationalAcademicYear { get; init; } = string.Empty;
            public string RecordSelectionCriterion { get; init; } = string.Empty;
            public string ApplicationState { get; init; } = string.Empty;
            public string TopicConfidence { get; init; } = string.Empty;
            public string IntentConfidence { get; init; } = string.Empty;
            public string OperationalDataConfidence { get; init; } = string.Empty;
            public string DecisionConfidence { get; init; } = string.Empty;
            public DateTime? CreationDate { get; init; }
            public DateTime? LastMessageDate { get; init; }
            public int? DaysOpen { get; init; }
            public string Closable { get; init; } = string.Empty;
            public string ClosureStatus { get; init; } = string.Empty;
            public string RequestedObject { get; init; } = string.Empty;
            public string AcademicYearConsistency { get; init; } = string.Empty;
            public string NonClosureReason { get; init; } = string.Empty;
            public string RequestedScopes { get; init; } = string.Empty;
            public string ClosureChecks { get; init; } = string.Empty;
            public string ResolvedCondition { get; init; } = string.Empty;
            public string Priority { get; init; } = string.Empty;
            public int PriorityOrder { get; init; }
            public string PriorityReason { get; init; } = string.Empty;
            public string Decision { get; init; } = string.Empty;
            public string RequiredAction { get; init; } = string.Empty;
            public string Reason { get; init; } = string.Empty;
            public string ResponseCode { get; init; } = string.Empty;
            public string ResponseText { get; init; } = string.Empty;
            public string Evidence { get; init; } = string.Empty;
            public bool TicketMentionsBlocks { get; init; }
            public bool StudentHasBlocks { get; init; }
            public string RelevantBlocks { get; init; } = string.Empty;
            public string NonRelevantBlocks { get; init; } = string.Empty;
            public string Contradictions { get; init; } = string.Empty;
            public string DetailSheet { get; init; } = string.Empty;
        }
    }
}
