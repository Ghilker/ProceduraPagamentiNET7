using System;
using System.Collections.Generic;
using System.Data;

namespace ProcedureNet7
{
    /*
       Implementazione storica rimossa dal percorso di produzione.
       La procedura usa PagamentiOperatoreTicketTopicSheet, che consuma
       TicketOfficeDataService senza eseguire una seconda estrazione SQL.
    */
    [Obsolete("Usare PagamentiOperatoreTicketTopicSheet. Questa classe e' mantenuta solo per compatibilita' interna.")]
    internal sealed class PagamentiTicketTopicSheet : TicketTopicSheetBase
    {
        public override int Order => 30;
        public override string SheetName => "Pagamenti";

        // Coerente con il foglio operativo: solo argomento primario.
        protected override bool Matches(DataRow row) =>
            PrimaryIs(row, PrimaryTopic.PAGAMENTI_E_TASSE);

        public override DataTable BuildSheet(TicketTopicSheetContext context)
        {
            return new PagamentiOperatoreTicketTopicSheet().BuildSheet(context);
        }
    }
}
